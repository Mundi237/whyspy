/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
    WebSocketGateway,
    SubscribeMessage,
    MessageBody,
    WebSocketServer,
    OnGatewayInit,
    OnGatewayConnection, 
    OnGatewayDisconnect, 
    ConnectedSocket
} from '@nestjs/websockets';
import { SocketIoService } from './socket_io.service';
import { BadRequestException, UseFilters } from "@nestjs/common";
import { Server, Socket } from "socket.io";
import { IUser } from "../../api/user_modules/user/entities/user.entity";
import { WsCatchAllFilter } from "../../core/exception_filter/ws-catch-all-filter";
import { SocketEventsType } from "../../core/utils/enums";
import { jsonDecoder } from "../../core/utils/app.validator";

/**
 * Extend Socket interface with user property
 */
declare module "socket.io" {
    interface Socket {
        user: IUser;
        typingTo?: string;
    }
}

/**
 * Interface for room data in message body
 */
interface RoomData {
    roomId: string;
}

/**
 * Interface for room status change data
 */
interface RoomStatusData extends RoomData {
    status: string;
}

/**
 * Interface for online user data
 */
interface OnlineUserData {
    peerId: string;
    extra?: any;
}

@UseFilters(new WsCatchAllFilter())
@WebSocketGateway({
    transports: ["websocket"],
    connectTimeout: 20000,
    pingInterval: 25000,
    pingTimeout: 20000,
    allowEIO3: true,
    cors: {
        origin: "*",
    },
})
export class SocketIoGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
    @WebSocketServer() io!: Server;

    constructor(private readonly socketIoService: SocketIoService) {}

    /**
     * Initialize the gateway
     * @param server - The server instance
     */
    afterInit(server: Server): void {
        this.socketIoService.initializeIo(this.io);
    }

    /**
     * Handle socket connection
     * @param client - The connected socket client
     */
    async handleConnection(client: Socket): Promise<void> {
        await this.socketIoService.handleConnection(client);
    }

    /**
     * Handle socket disconnection
     * @param client - The disconnected socket client
     */
    async handleDisconnect(client: Socket): Promise<void> {
        await this.socketIoService.handleDisconnect(client);
    }

    /**
     * Handle online status check for users
     * @param data - Message data
     * @param client - Socket client
     */
    @SubscribeMessage(SocketEventsType.v1MyOnline)
    async myOnline(
        @MessageBody() data: string,
        @ConnectedSocket() client: Socket
    ): Promise<void> {
        let decodedData: OnlineUserData[] = [];

        try {
            decodedData = jsonDecoder(data);
        } catch (e) {
            // Parsing failed, use original data
            decodedData = data as unknown as OnlineUserData[];
        }

        if (!Array.isArray(decodedData)) {
            throw new BadRequestException(`${decodedData} must be array of mongo ids`);
        }

        const result = await this.socketIoService.myOnline(decodedData);
        client.emit(SocketEventsType.v1OnMyOnline, JSON.stringify(result));
    }

    /**
     * Handle message delivery status update
     * @param data - Message data
     * @param client - Socket client
     */
    @SubscribeMessage(SocketEventsType.v1DeliverChatRoom)
    async updateRoomMessagesToDeliver(
        @MessageBody() data: string | RoomData,
        @ConnectedSocket() client: Socket
    ): Promise<void> {
        const myUser: IUser = client.user;
        let roomId: string | null = null;

        try {
            if (typeof data === 'string') {
                const dataMap = jsonDecoder(data);
                roomId = dataMap.roomId;
            } else {
                roomId = data.roomId;
            }
        } catch (err) {
            // Parsing failed, try to get roomId from data as object
            if (typeof data === 'object' && data !== null) {
                roomId = (data as RoomData).roomId;
            }
        }

        if (!roomId) {
            throw new BadRequestException(`while updateRoomMessagesToDeliver roomId is required ${data}`);
        }

        const needToNotify = await this.socketIoService.updateRoomMessagesToDeliver(roomId, myUser);

        if (needToNotify?.isUpdated && needToNotify.pId) {
            this.io.to(needToNotify.pId.toString()).emit(
                SocketEventsType.v1OnDeliverChatRoom,
                JSON.stringify({
                    roomId: roomId.toString(),
                    // Notify the other person I chat with
                    userId: needToNotify.pId.toString(),
                    date: new Date(),
                }),
            );
        }
    }

    /**
     * Handle message seen status update
     * @param data - Message data
     * @param client - Socket client
     */
    @SubscribeMessage(SocketEventsType.v1EnterChatRoom)
    async updateRoomMessagesToSeen(
        @MessageBody() data: string | RoomData,
        @ConnectedSocket() client: Socket
    ): Promise<void> {
        const myUser: IUser = client.user;
        let roomId: string | null = null;

        try {
            if (typeof data === 'string') {
                const dataMap = jsonDecoder(data);
                roomId = dataMap.roomId;
            } else {
                roomId = data.roomId;
            }
        } catch (err) {
            // Parsing failed, try to get roomId from data as object
            if (typeof data === 'object' && data !== null) {
                roomId = (data as RoomData).roomId;
            }
        }

        if (!roomId) {
            throw new BadRequestException(`while updateRoomMessagesToSeen roomId is required ${data}`);
        }

        const needToNotify = await this.socketIoService.updateRoomMessagesToSeen(roomId, myUser);

        if (needToNotify.isUpdated && needToNotify.pId) {
            this.io.to(needToNotify.pId.toString()).emit(
                SocketEventsType.v1OnEnterChatRoom,
                JSON.stringify({
                    roomId: roomId.toString(),
                    // Notify the other person I chat with
                    userId: needToNotify.pId.toString(),
                    date: new Date(),
                }),
            );
        }
    }

    /**
     * Handle WebRTC ICE candidate exchange
     * @param data - Message data
     * @param client - Socket client
     */
    @SubscribeMessage(SocketEventsType.v1IceCandidate)
    async iceRtc(
        @MessageBody() data: any,
        @ConnectedSocket() client: Socket
    ): Promise<void> {
        // Implementation removed as it was commented out in the original code
    }

    /**
     * Handle room status change (typing indicators)
     * @param data - Message data
     * @param client - Socket client
     */
    @SubscribeMessage(SocketEventsType.v1RoomStatusChange)
    async roomStatusChanged(
        @MessageBody() data: string | RoomStatusData,
        @ConnectedSocket() client: Socket
    ): Promise<void> {
        const myUser = client.user;
        let roomId: string | null = null;
        let status: string | null = null;

        try {
            if (typeof data === 'string') {
                const decodedData = jsonDecoder(data);
                roomId = decodedData.roomId;
                status = decodedData.status;
            } else {
                roomId = data.roomId;
                status = data.status;
            }
        } catch (e) {
            // Parsing failed, try to get data from object
            if (typeof data === 'object' && data !== null) {
                const roomData = data as RoomStatusData;
                roomId = roomData.roomId;
                status = roomData.status;
            }
        }

        if (!roomId || !status) {
            throw new BadRequestException(`Room ID and status are required for room status change`);
        }

        const statusData = {
            roomId: roomId,
            status: status,
            name: myUser.fullName,
            userId: myUser._id
        };

        if (status !== "stop") {
            client.typingTo = roomId;
        }

        this.io
            .to(roomId.toString())
            .emit(
                SocketEventsType.v1OnRoomStatusChange,
                JSON.stringify(statusData),
            );
    }
}
