/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { SocketIoService } from "./socket_io.service";
import { SocketIoGateway } from "./socket_io.gateway";
import { DashboardGateway } from "./dashboard.gateway";
import { CallMemberModule } from "../call_modules/call_member/call_member.module";
import { UserModule } from "../../api/user_modules/user/user.module";
import { RoomMemberModule } from "../room_member/room_member.module";
import { MessageModule } from "../message/message.module";
import { RoomMiddlewareModule } from "../room_middleware/room_middleware.module";
import { UserDeviceModule } from "../../api/user_modules/user_device/user_device.module";
import { CallHistoryModule } from "../call_modules/call_history/call_history.module";
import { JwtModule } from "../../modules/jwt/jwt.module";

/**
 * Socket.IO Module
 *
 * This module provides the Socket.IO gateway and service for real-time communication.
 * It imports all the necessary modules for chat functionality.
 */
@Module({
  providers: [SocketIoGateway, DashboardGateway, SocketIoService],
  imports: [
    ConfigModule,
    UserModule,
    RoomMemberModule,
    JwtModule, // Import JwtModule directly instead of AuthModule
    MessageModule,
    RoomMiddlewareModule,
    CallHistoryModule,
    CallMemberModule,
    UserDeviceModule,
  ],
  exports: [SocketIoService, DashboardGateway],
})
export class SocketIoModule {}
