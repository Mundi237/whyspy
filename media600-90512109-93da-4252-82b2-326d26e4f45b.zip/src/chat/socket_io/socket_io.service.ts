/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { Injectable, Inject, forwardRef } from '@nestjs/common';
import { Server, Socket } from "socket.io";
import { RemoteSocket } from "socket.io/dist/broadcast-operator";
import { CallMemberService } from "../call_modules/call_member/call_member.service";
import { RoomMemberService } from "../room_member/room_member.service";
import { MessageService } from "../message/message.service";
import { UserService } from "../../api/user_modules/user/user.service";
import { RoomMiddlewareService } from "../room_middleware/room_middleware.service";
import { CallStatus, Platform, RoomType, SocketEventsType } from "../../core/utils/enums";
import { IUser } from "../../api/user_modules/user/entities/user.entity";
import { IRoomMember } from "../room_member/entities/room_member.entity";
import { newMongoObjId } from "../../core/utils/utils";
import { UserDeviceService } from "../../api/user_modules/user_device/user_device.service";
import { UserGlobalCallStatus } from "../call_modules/utils/user-global-call-status.model";
import { DashboardGateway } from './dashboard.gateway';

/**
 * Extended Socket interface with custom properties
 */
interface ExtendedSocket extends Socket {
  user: IUser;
  typingTo?: string;
}

/**
 * Interface for room message update result
 */
interface RoomMessageUpdateResult {
  isUpdated: boolean;
  pId: string | null;
}

/**
 * Interface for online user data
 */
interface OnlineUserData {
  peerId: string;
  isOnline: boolean;
  extra?: any;
}

/**
 * Interface for join/leave room arguments
 */
interface RoomOperationArgs {
  usersIds: string[];
  roomId: string;
}

/**
 * Interface for room status change data
 */
interface RoomStatusChangeData {
  roomId: string;
  status: string;
  name: string;
  userId: string;
}

/**
 * Interface for deliver/seen notification data
 */
interface MessageNotificationData {
  roomId: string;
  userId: string;
  date: Date;
}

@Injectable()
export class SocketIoService {
  public io!: Server;

  constructor(
    private readonly roomMemberService: RoomMemberService,
    private readonly messageService: MessageService,
    private readonly userService: UserService,
    private readonly deviceService: UserDeviceService,
    private readonly callMemberService: CallMemberService,
    private readonly middlewareService: RoomMiddlewareService,
    private readonly userDeviceService: UserDeviceService,
    @Inject(forwardRef(() => DashboardGateway))
    private readonly dashboardGateway: DashboardGateway,
  ) {}

  /**
   * Initialize the io property and override the emit method
   * @param server - The server instance
   */
  public initializeIo(server: Server): void {
    this.io = server;

    // Store the original emit method of BroadcastOperator
    const originalTo = this.io.to;

    // Override the to method to return a proxy that intercepts emit calls
    this.io.to = (room: string | string[]) => {
      const broadcastOperator = originalTo.call(this.io, room);
      const originalEmit = broadcastOperator.emit;

      // Override the emit method to intercept events
      broadcastOperator.emit = (event: string, data: any) => {
        // Call original emit
        originalEmit.call(broadcastOperator, event, data);

        // If this is a new message event, notify the dashboard
        if (event === SocketEventsType.v1OnNewMessage) {
          try {
            const messageData = JSON.parse(data);
            if (messageData && messageData.sId && messageData.rId) {
              this.dashboardGateway.notifyNewMessage(messageData.rId, messageData.sId);
            }
          } catch (error) {
            console.error('Error parsing message data:', error);
          }
        }

        return broadcastOperator;
      };

      return broadcastOperator;
    };
  }


  /**
   * Handle socket connection
   * @param client - The connected socket client
   */
  public async handleConnection(client: ExtendedSocket): Promise<void> {
    // Get user's chat rooms and join them
    const roomsIds = await this.roomMemberService.findAll({
      uId: client.user._id,
      bId: { $eq: null }
    }, "rT rId pId", { limit: 700 });

    // Join all room IDs
    client.join(roomsIds.map(value => value.rId.toString()));
    client.join(client.user._id.toString());

    // Process each room
    for (const room of roomsIds) {
      if (room.rT === RoomType.Single || room.rT === RoomType.Order) {
        const res = await this.messageService.setMessageDeliverForSingleChat(client.user._id, room.rId);
        const isUpdated = res["modifiedCount"] !== 0;

        if (isUpdated) {
          const notificationData: MessageNotificationData = {
            roomId: room.rId.toString(),
            userId: room.pId.toString(),
            date: new Date()
          };

          this.io.to(room.rId.toString()).emit(
            SocketEventsType.v1OnDeliverChatRoom, 
            JSON.stringify(notificationData)
          );
        }
      } else if (room.rT === RoomType.GroupChat) {
        await this.messageService.setMessageDeliverForGroupChat(client.user._id, room.rId);
      }
    }

    // Update dashboard with new online users count
    await this.dashboardGateway.updateAllDashboards();
  }

  /**
   * Join users to a room
   * @param args - Room operation arguments
   * @returns Number of sockets that joined
   */
  public async joinRoom(args: RoomOperationArgs): Promise<number> {
    const sockets = await this.getSockets(args.usersIds);

    for (const socket of sockets) {
      socket.join(args.roomId.toString());
    }

    return sockets.length;
  }

  /**
   * Remove users from a room
   * @param args - Room operation arguments
   * @returns Number of sockets that left
   */
  public async leaveRooms(args: RoomOperationArgs): Promise<number> {
    const sockets = await this.getSockets(args.usersIds);

    for (const socket of sockets) {
      await socket.leave(args.roomId.toString());
    }

    return sockets.length;
  }

  /**
   * Get the number of online sockets
   * @returns Number of online sockets
   */
  public async getOnlineSocketsNumber(): Promise<number> {
    const allSockets = await this.io.fetchSockets();
    return allSockets.length;
  }

  /**
   * Get sockets for specific user IDs
   * @param usersIds - Array of user IDs
   * @returns Array of sockets
   */
  public async getSockets(usersIds: string[]): Promise<ExtendedSocket[]> {
    const allSockets = await this.io.fetchSockets();
    const sockets: ExtendedSocket[] = [];

    allSockets.forEach((socket) => {
      const socketWithUser = socket as unknown as ExtendedSocket;
      if (socketWithUser.user && usersIds.includes(socketWithUser.user._id.toString())) {
        sockets.push(socketWithUser);
      }
    });

    return sockets;
  }

  /**
   * Get socket by device ID
   * @param deviceId - Device ID
   * @returns Socket or null if not found
   */
  public async getSocketByDeviceId(deviceId: string): Promise<RemoteSocket<any, any> | null> {
    const allSockets = await this.io.fetchSockets();
    let foundSocket: RemoteSocket<any, any> | null = null;

    allSockets.forEach((socket) => {
      const socketWithUser = socket as unknown as { user: IUser };
      if (socketWithUser.user?.currentDevice?._id?.toString() === deviceId) {
        foundSocket = socket;
      }
    });

    return foundSocket;
  }

  /**
   * Get number of online users in a room
   * @param roomId - Room ID
   * @returns Number of online users
   */
  public async getOnlineRoomId(roomId: string): Promise<number> {
    const allSockets = await this.io.in(roomId).fetchSockets();
    return allSockets.length;
  }

  /**
   * Get online users from a list of user IDs
   * @param usersIds - Array of user IDs
   * @returns Array of online user IDs
   */
  public async getOnlineFromList(usersIds: string[]): Promise<string[]> {
    const allSockets = await this.io.fetchSockets();
    const onlineIds: string[] = [];

    for (const socket of allSockets) {
      const socketWithUser = socket as unknown as { user: IUser };

      for (const id of usersIds) {
        if (id.toString() === socketWithUser.user?._id?.toString()) {
          onlineIds.push(socketWithUser.user._id.toString());
        }
      }
    }

    return onlineIds;
  }

  /**
   * Check if a user is online
   * @param userId - User ID
   * @returns True if user is online, false otherwise
   */
  public async checkIfUserOnline(userId: string): Promise<boolean> {
    const allSockets = await this.io.fetchSockets();

    for (const socket of allSockets) {
      const socketWithUser = socket as unknown as { user: IUser };
      if (userId.toString() === socketWithUser.user?._id?.toString()) {
        return true;
      }
    }

    return false;
  }

  /**
   * Remove a user from a room
   * @param roomId - Room ID
   * @param uId - User ID
   */
  public async leaveRoom(roomId: string, uId: string): Promise<void> {
    const sockets = await this.getSockets([uId]);

    for (const socket of sockets) {
      await socket.leave(roomId.toString());
    }
  }

  /**
   * Get online status for a list of users
   * @param decodedList - Array of user data with peerId and extra info
   * @returns Array of online user data
   */
  public async myOnline(decodedList: Array<{ peerId: string; extra?: any }>): Promise<OnlineUserData[]> {
    const onlineSockets = await this.getOnlineFromList(decodedList.map(data => data.peerId));
    const result: OnlineUserData[] = [];

    for (const item of decodedList) {
      result.push({
        peerId: item.peerId,
        isOnline: onlineSockets.includes(item.peerId),
        extra: item.extra
      });
    }

    return result;
  }

  /**
   * Update room messages to delivered status
   * @param roomId - Room ID
   * @param myUser - User
   * @returns Update result
   */
  public async updateRoomMessagesToDeliver(roomId: string, myUser: IUser): Promise<RoomMessageUpdateResult | undefined> {
    const rMember: IRoomMember = await this.middlewareService.isThereRoomMember(
      roomId,
      myUser._id,
    );

    if (!rMember) return undefined;

    if (rMember.rT === RoomType.Single || rMember.rT === RoomType.Order) {
      const res = await this.messageService.setMessageDeliverForSingleChat(
        myUser._id,
        roomId,
      );
      const isUpdated = res['modifiedCount'] !== 0;
      return { isUpdated, pId: rMember.pId };
    }

    if (rMember.rT === RoomType.GroupChat) {
      await this.messageService.setMessageDeliverForGroupChat(
        myUser._id,
        roomId,
      );
    }

    return { isUpdated: false, pId: null };
  }

  /**
   * Update room messages to seen status
   * @param roomId - Room ID
   * @param myUser - User
   * @returns Update result
   */
  public async updateRoomMessagesToSeen(roomId: string, myUser: IUser): Promise<RoomMessageUpdateResult> {
    const rMember: IRoomMember = await this.middlewareService.isThereRoomMember(
      roomId,
      myUser._id,
    );

    if (!rMember) return { isUpdated: false, pId: null };

    await this.roomMemberService.findOneAndUpdate({
      uId: myUser._id,
      rId: roomId.toString(),
    }, { lSMId: newMongoObjId().toString() });

    if (rMember.rT === RoomType.Single || rMember.rT === RoomType.Order) {
      const res = await this.messageService.setMessageSeenForSingleChat(
        myUser._id,
        roomId.toString(),
      );
      const isUpdated = res['modifiedCount'] !== 0;
      return { isUpdated, pId: rMember.pId?.toString() || null };
    } else if (rMember.rT === RoomType.GroupChat) {
      await this.messageService.setMessageSeenForGroupChat(
        myUser._id,
        roomId,
      );
    }

    return { isUpdated: false, pId: null };
  }

  /**
   * Handle socket disconnection
   * @param client - The disconnected socket client
   */
  public async handleDisconnect(client: ExtendedSocket): Promise<void> {
    await this._setLastSeenAt(client.user);
    const rId = client.typingTo;

    if (rId) {
      const statusData: RoomStatusChangeData = {
        roomId: rId,
        status: "stop",
        name: "",
        userId: client.user._id
      };

      this.io
        .to(rId.toString())
        .emit(
          SocketEventsType.v1OnRoomStatusChange,
          JSON.stringify(statusData),
        );
    }

    await this._checkIfThisDeviceInCall(client.user._id, client.user.currentDevice._id);

    // Update dashboard with new online users count
    await this.dashboardGateway.updateAllDashboards();
  }

  /**
   * Notify group members about a member being kicked
   * @param gId - Group ID
   * @param peerId - User ID of the kicked member
   */
  public async kickGroupMember(gId: string, peerId: string): Promise<void> {
    this.io
      .to(gId.toString())
      .emit(
        SocketEventsType.v1OnKickGroupMember,
        JSON.stringify({
          roomId: gId,
          userId: peerId
        }),
      );
  }

  /**
   * Check if device is in a call and reset call status if needed
   * @param userId - User ID
   * @param deviceId - Device ID
   */
  private async _checkIfThisDeviceInCall(userId: string, deviceId: string): Promise<void> {
    const device = await this.userDeviceService.findById(deviceId);

    if (device.platform === Platform.Android || device.platform === Platform.Ios) {
      const theUser = await this.userService.findById(userId, "userGlobalCallStatus");

      if (theUser.userGlobalCallStatus?.callId) {
        await this.userService.findByIdAndUpdate(theUser._id, {
          userGlobalCallStatus: UserGlobalCallStatus.createEmpty()
        });
      }
    }
  }

  /**
   * Handle WebRTC ICE candidate exchange
   * @param meetId - Meeting ID
   * @param client - Socket client
   * @returns Peer ID
   */
  public async iceRtc(meetId: string, client: Socket): Promise<string | undefined> {
    // Implementation removed as it was commented out in the original code
    return undefined;
  }

  /**
   * Update last seen timestamp for user and device
   * @param user - User
   */
  private async _setLastSeenAt(user: IUser): Promise<void> {
    await this.userService.setLastSeenAt(user._id);
    await this.deviceService.setLastSeenAt(user.currentDevice._id);
  }
}
