/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  WebSocketServer,
  OnGatewayInit,
  OnGatewayConnection,
  OnGatewayDisconnect,
  ConnectedSocket,
} from "@nestjs/websockets";
import { SocketIoService } from "./socket_io.service";
import { Injectable, UseFilters, Inject, forwardRef } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { Server, Socket } from "socket.io";
import { IUser } from "../../api/user_modules/user/entities/user.entity";
import { WsCatchAllFilter } from "../../core/exception_filter/ws-catch-all-filter";
import { SocketEventsType } from "../../core/utils/enums";

/**
 * Dashboard Gateway
 *
 * This gateway provides real-time updates for the dashboard, including:
 * - Number of online users
 * - User registrations in real-time
 * - Message sends
 */
@Injectable()
@UseFilters(new WsCatchAllFilter())
@WebSocketGateway({
  namespace: "dashboard",
  transports: ["websocket"],
  connectTimeout: 20000,
  pingInterval: 25000,
  pingTimeout: 20000,
  allowEIO3: true,
  cors: {
    origin: "*",
  },
})
export class DashboardGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer() io!: Server;
  private connectedClients: number = 0;

  constructor(
    @Inject(forwardRef(() => SocketIoService))
    private readonly socketIoService: SocketIoService,
    private readonly configService: ConfigService
  ) {}

  /**
   * Initialize the gateway
   * @param server - The server instance
   */
  afterInit(server: Server): void {
    console.log("Dashboard Gateway initialized");
  }

  /**
   * Handle socket connection
   * @param client - The connected socket client
   */
  async handleConnection(client: Socket): Promise<void> {
    try {
      // Authenticate the client
      await this.authenticateClient(client);

      this.connectedClients++;
      console.log(`Dashboard client connected: ${client.id}`);

      // Send initial stats
      await this.sendDashboardStats(client);
    } catch (error) {
      console.log(
        `Dashboard client authentication failed: ${client.id} - ${error.message}`
      );
      client.emit("error", { message: "Authentication failed" });
      client.disconnect(true);
    }
  }

  /**
   * Handle socket disconnection
   * @param client - The disconnected socket client
   */
  async handleDisconnect(client: Socket): Promise<void> {
    this.connectedClients--;
    console.log(`Dashboard client disconnected: ${client.id}`);
  }

  /**
   * Send dashboard statistics to the client
   * @param client - The socket client
   */
  private async sendDashboardStats(client: Socket): Promise<void> {
    const onlineUsers = await this.socketIoService.getOnlineSocketsNumber();

    client.emit(SocketEventsType.dashboardStats, {
      onlineUsers,
      connectedDashboards: this.connectedClients,
    });
  }

  /**
   * Update all connected dashboard clients with the latest stats
   */
  public async updateAllDashboards(): Promise<void> {
    const onlineUsers = await this.socketIoService.getOnlineSocketsNumber();

    this.io.emit(SocketEventsType.dashboardStats, {
      onlineUsers,
      connectedDashboards: this.connectedClients,
    });
  }

  /**
   * Notify dashboard about a new user registration
   * @param user - The newly registered user
   */
  public notifyNewUserRegistration(user: IUser): void {
    this.io.emit(SocketEventsType.newUserRegistration, {
      userId: user._id,
      fullName: user.fullName,
      email: user.email,
      registeredAt: new Date(),
    });
  }

  /**
   * Notify dashboard about a new message
   * @param roomId - The room ID where the message was sent
   * @param userId - The user ID who sent the message
   */
  public notifyNewMessage(roomId: string, userId: string): void {
    this.io.emit(SocketEventsType.newMessage, {
      roomId,
      userId,
      timestamp: new Date(),
    });
  }

  /**
   * Authenticate the client using the admin key from headers
   * @param client - The socket client to authenticate
   * @throws Error if authentication fails
   */
  private async authenticateClient(client: Socket): Promise<void> {
    const adminKey = client.handshake.headers["admin-key"] as string;
    const expectedKey = this.configService.getOrThrow<string>(
      "ControlPanelAdminPassword"
    );

    if (!adminKey) {
      throw new Error("Admin key header is required");
    }

    if (adminKey !== expectedKey) {
      throw new Error("Invalid admin key");
    }
  }
}
