/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { IoAdapter } from "@nestjs/platform-socket.io";
import { Server, ServerOptions, Socket } from "socket.io";
import { INestApplicationContext, UnauthorizedException } from "@nestjs/common";
import { JwtTokenService } from "../../modules/jwt/services/jwt.service";
import { JwtStrategy } from "../../modules/jwt/strategies/jwt.strategy";
import { IUser } from "../../api/user_modules/user/entities/user.entity";

/**
 * Interface for JWT payload
 */
interface JwtPayload {
  userId: string;
  deviceId: string;
  [key: string]: any;
}

/**
 * Extended Socket interface with user property
 */
interface AuthenticatedSocket extends Socket {
  user: IUser;
  typingTo?: string;
}

/**
 * Redis Socket.IO Adapter
 * 
 * This adapter extends the IoAdapter from NestJS and is used to create
 * Socket.IO servers. Authentication is handled by the WsJwtAuthGuard.
 */
export class RedisIoAdapter extends IoAdapter {
  /**
   * Constructor
   * @param app NestJS application context
   */
  constructor(
    private readonly app: INestApplicationContext
  ) {
    super(app);
  }

  /**
   * Create a Socket.IO server
   * @param port The port to listen on
   * @param options Server options
   * @returns The Socket.IO server
   */
  createIOServer(port: number, options?: ServerOptions): Server {
    // Create the server with the provided options
    const server: Server = super.createIOServer(port, options);

    // Add middleware to authenticate socket connections
    server.use(async (socket: AuthenticatedSocket, next) => {
      try {
        let authToken: string | undefined;

        // Get token from authorization header or query parameter
        if (socket.handshake.headers.authorization) {
          authToken = socket.handshake.headers.authorization.split(" ")[1];
        } else if (socket.handshake.query && socket.handshake.query.auth) {
          const authQuery = socket.handshake.query.auth;
          authToken = (typeof authQuery === 'string' ? authQuery : authQuery[0]).split(" ")[1];
        }

        if (!authToken) {
          return next(new Error("Authentication token not found"));
        }

        // Get the JWT service and strategy from the application context
        const jwtTokenService = this.app.get(JwtTokenService);
        const jwtStrategy = this.app.get(JwtStrategy);

        // Verify the token and get the payload
        const jwtPayload: JwtPayload = jwtTokenService.verifyJwt(authToken);

        // Use the JWT strategy to validate the payload and get the user
        socket.user = await jwtStrategy.validate({
          id: jwtPayload.userId,
          deviceId: jwtPayload.deviceId
        });

        next();
      } catch (e: any) {
        console.log("Socket authentication error:", e.message);
        next(e instanceof UnauthorizedException ? 
          new Error(e.message) : 
          new Error("Unauthorized access"));
      }
    });

    return server;
  }
}
