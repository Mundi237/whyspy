/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {BadRequestException, Injectable, NotFoundException} from '@nestjs/common';
import {InjectModel} from "@nestjs/mongoose";
import {FilterQuery, PaginateModel, QueryOptions, UpdateQuery} from "mongoose";
import {IMeetMember} from "./entities/call_member.entity";
import {BaseRepository} from "../../../core/common/base.service";


@Injectable()
export class CallMemberService extends BaseRepository<IMeetMember> {
    constructor(
        @InjectModel("meet_member")   readonly model: PaginateModel<IMeetMember>,
    ) {
        super(model)
    }



    findByRoomId(roomId: string, select?: string | null | undefined, options?: QueryOptions<IMeetMember> | null | undefined) {
        return Promise.resolve(this.findAll({rId: roomId}, select, options));
    }

    findByRoomIdAndDelete(roomId: string,): Promise<any> {
        return Promise.resolve(this.model.findOneAndDelete({rId: roomId}));
    }

    findByRoomIdAndUpdate(roomId: string, update: Partial<IMeetMember>): Promise<any> {
        return Promise.resolve(this.updateMany({
            rId: roomId
        }, update));
    }




}
