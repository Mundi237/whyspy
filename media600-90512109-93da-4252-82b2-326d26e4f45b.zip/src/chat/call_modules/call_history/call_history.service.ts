import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel, FilterQuery, UpdateQuery, QueryOptions } from 'mongoose';
 import {isValidMongoId} from "../../../core/utils/utils";
import {ICallHistory} from "./call.history.entity";
import {BaseRepository} from "../../../core/common/base.service";

@Injectable()
export class CallHistoryService extends BaseRepository<ICallHistory> {
    constructor(
        @InjectModel('call_history')   readonly model: PaginateModel<ICallHistory>
    ) {
        super(model);
    }


}
