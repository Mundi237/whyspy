/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
    ForbiddenException,
    Injectable,
    NotFoundException,
} from "@nestjs/common";
import {InjectModel} from "@nestjs/mongoose";
import mongoose, {
    ClientSession,
    FilterQuery,
    mongo,
    PaginateModel,
    QueryOptions,
    UpdateResult,
} from "mongoose";
import {IMessage} from "./entities/message.entity";
import {GroupMessageStatusService} from "../group_message_status/group_message_status.service";
import {SendMessageDto} from "../channel/dto/send.message.dto";
import {MessagesSearchDto} from "./dto/messages_search_dto";
import {BaseRepository} from "../../core/common/base.service";

@Injectable()
export class MessageService  extends BaseRepository<IMessage>{
    constructor(
        @InjectModel("message") readonly messageModel: PaginateModel<IMessage>,
        readonly groupMessageStatusService: GroupMessageStatusService
    ) {
        super(messageModel);
    }

    async getByIdOrFail(messageId: any, select?: string) {
        let msg = await this.messageModel.findById(messageId, select).lean();
        if (!msg) {
            throw new NotFoundException("message not found " + messageId);
        }
        return msg;
    }

    async findOne(filter: FilterQuery<IMessage>) {
        let m = await this.messageModel.findOne(filter);
        return this.prepareTheMessageModel(m);
    }

    async create(
        dto: any,
        session?: mongoose.mongo.ClientSession
    ) {
        let x = await this.messageModel.create([dto.toJson()], {session});
        return this.prepareTheMessageModel(x[0]);
    }

    async createOneFromJson(dto: {}) {
        return this.messageModel.create(dto);
    }

    async createMany(
        data: Partial<any>[],
        session?: ClientSession

    ) {
        return this.messageModel.create(
            data.map((value) => value.toJson()),
            {session}
        );
    }

    async findAllMessagesAggregation(
        myId: any,
        roomId: any,
        dto: MessagesSearchDto
    ) {
        let sortDirection = dto.isAsc === "true" ? 1 : -1;
        let limit = parseInt(dto.getLimit().toString(), 10);

        let pipeline: any[] = [
            {
                $match: {
                    rId: roomId,
                    dF: {$ne: myId},
                    ...dto.getFilter(),
                },
            },
            {
                $sort: {
                    _id: sortDirection,
                },
            },
            {
                $limit: limit,
            },
            {
                $addFields: {
                    isStared: {
                        $in: [myId, {$ifNull: ["$stars", []]}],
                    },
                    isOneSeenByMe: {
                        $in: [myId, {$ifNull: ["$oneSeenBy", []]}],
                    },
                    isDeletedFromMe: {
                        $in: [myId, {$ifNull: ["$dF", []]}],
                    },
                },
            },
            {
                $unset: ["oneSeenBy", "dF", "stars", "mentions"],
            },
        ];
        return this.messageModel.aggregate(pipeline).exec();
    }

    async paginated(dto: any[]) {
        return this.messageModel.paginate(...dto);
    }


    private prepareTheMessageModel(msg: IMessage) {
        if (!msg) {
            return null;
        }
        msg["isStared"] = false;
        return msg;
    }

    async getUnReadCount(lastMessageSeenId: string, roomId: string, myId: any) {
        return this.messageModel
            .countDocuments({
                $and: [
                    {_id: {$gt: lastMessageSeenId}},
                    {rId: roomId},
                    {sId: {$ne: myId}},
                ],
            })
            .lean();
    }

    async setMessageSeenForSingleChat(
        userId: string,
        roomId: string
    ): Promise<any> {
        const roomObjectId = new mongoose.Types.ObjectId(roomId);
        const userObjectId = new mongoose.Types.ObjectId(userId);

        return this.messageModel.updateMany(
            {
                rId: roomObjectId,
                sId: {$ne: userObjectId},
                sAt: null,
            },
            {
                $set: {sAt: new Date()},
            }
        );
    }

    async setMessageSeenForGroupChat(userId: string, roomId: string) {
        await this.setMessageDeliverForGroupChat(userId, roomId);
        return this.groupMessageStatusService.updateMany(
            {
                rId: roomId,
                uId: userId,
                sAt: null,
            },
            {
                sAt: new Date(),
            }
        );
    }

    async setMessageDeliverForSingleChat(
        userId: string,
        roomId: string
    ): Promise<UpdateResult> {
        try {
            const roomObjectId = new mongoose.Types.ObjectId(roomId);
            const userObjectId = new mongoose.Types.ObjectId(userId);
            return await this.messageModel.updateMany(
                {
                    rId: roomObjectId,
                    sId: {$ne: userObjectId},
                    dAt: null,
                },
                {
                    dAt: new Date(),
                }
            );
        } catch (error) {
            if (error instanceof mongoose.Error.CastError) {
                throw new ForbiddenException("Invalid ID format");
            }
            throw error;
        }
    }

    async setMessageDeliverForGroupChat(
        myId: string,
        roomId: string
    ): Promise<UpdateResult> {
        try {
            return this.groupMessageStatusService.updateMany(
                {
                    rId: roomId,
                    uId: myId,
                    dAt: null,
                },
                {
                    dAt: new Date(),
                }
            );
        } catch (error) {
            if (error instanceof mongoose.Error.CastError) {
                throw new ForbiddenException("Invalid ID format");
            }
            throw error;
        }
    }

    async deleteMessageFromMe(myId: any, id: string) {
        await this.getByIdOrFail(id);
        return this.messageModel.findByIdAndUpdate(
            id,
            {
                $addToSet: {
                    dF: myId,
                },
            },
            {new: true}
        );
    }

    async isMeMessageSenderOrThrow(myId: any, id: string) {
        let msg = await this.getByIdOrFail(id);
        if (msg.sId != myId) throw new ForbiddenException("you dont have access");
        return msg;
    }

    async deleteAllRoomMessagesFromMe(userId, roomId: string) {
        await this.messageModel.updateMany(
            {
                rId: roomId,
            },
            {
                $addToSet: {
                    dF: userId,
                },
            }
        );
    }

    async deleteAll() {
        await this.messageModel.deleteMany();
    }

    async deleteOne(filter: FilterQuery<IMessage>) {
        await this.messageModel.deleteOne(filter);
    }

    async deleteWhere(filter: FilterQuery<IMessage>) {
        await this.messageModel.deleteMany(filter);
    }

    async isMessageExist(localId: string) {
        return this.messageModel.findOne({lId: localId});
    }

    async findByRoomIdAndUpdate(rId: string, param2: {}): Promise<any> {
        return this.messageModel.updateMany(
            {
                rId: rId,
            },
            param2
        );
    }

    async findByIdAndUpdate(mId: string, update: {}) {
        return this.messageModel.findByIdAndUpdate(mId, update, {new: true});
    }

    async findById(mId: string) {
        return this.messageModel.findById(mId);
    }

    async findWhere(
        filter: {},
        select?: string,
        options?: QueryOptions<IMessage>
    ) {
        return this.messageModel.find(filter, select, options);
    }

    async getById(id: string, select?: string) {
        return this.messageModel.findById(id, select).lean();
    }

    updateMany(
        filter: FilterQuery<IMessage>,
        update:
            | mongoose.UpdateQuery<IMessage>
            | mongoose.UpdateWithAggregationPipeline,
        options?: mongo.UpdateOptions | null | undefined
    ): Promise<any> {
        return Promise.resolve(
            this.messageModel.updateMany(filter, update, options)
        );
    }

    async findCount(filter?: FilterQuery<IMessage>) {
        return this.messageModel.countDocuments(filter);
    }

    async getByLocalId(lId: string, select?: string): Promise<IMessage | null> {
        return this.messageModel.findOne({lId: lId}, select).lean();
    }
}
