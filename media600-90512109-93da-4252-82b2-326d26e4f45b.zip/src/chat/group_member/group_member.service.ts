/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import {
  FilterQuery,
  Model,
  PaginateModel,
  QueryOptions,
  UpdateQuery,
  ClientSession,
  DeleteResult,
} from "mongoose";
import { IGroupMember } from "./entities/group_member.entity";
import { BaseRoomService } from "../../core/common/base.room.service";

@Injectable()
export class GroupMemberService extends BaseRoomService<IGroupMember> {
  constructor(
    @InjectModel("group_member")
    readonly model: PaginateModel<IGroupMember>
  ) {
    super(model);
  }

  async create(
    obj: Partial<IGroupMember>,
    session?: ClientSession
  ): Promise<IGroupMember> {
    const [created] = await this.model.create([obj], { session });
    return created;
  }

  deleteMany(filter: FilterQuery<IGroupMember>): Promise<DeleteResult> {
    return Promise.resolve(this.model.deleteMany(filter));
  }

  findAll(
    filter?: FilterQuery<IGroupMember> | undefined,
    select?: string | null | undefined,
    options?: QueryOptions<IGroupMember> | null | undefined
  ): Promise<IGroupMember[]> {
    return Promise.resolve(this.model.find(filter, select, options));
  }

  findById(
    id: string,
    select?: string | null | undefined
  ): Promise<IGroupMember | null> {
    return Promise.resolve(this.model.findById(id, select));
  }

  findByIdAndDelete(id: string): Promise<IGroupMember | null> {
    return Promise.resolve(this.model.findByIdAndDelete(id));
  }

  findByIdAndUpdate(
    id: string,
    update: Partial<IGroupMember> | null | undefined
  ): Promise<IGroupMember | null> {
    return Promise.resolve(this.model.findByIdAndUpdate(id, update));
  }

  updateMany(
    filter: FilterQuery<IGroupMember>,
    update: UpdateQuery<IGroupMember>
  ): Promise<any> {
    return Promise.resolve(this.model.updateMany(filter, update));
  }

  async findByIdOrThrow(
    id: string,
    select?: string | null | undefined
  ): Promise<IGroupMember> {
    let m = await this.findById(id, select);
    if (!m)
      throw new NotFoundException(
        "group member with id " + id + " not found in db"
      );
    return m;
  }

  findByRoomId(
    roomId: string,
    select?: string | null | undefined,
    options?: QueryOptions<IGroupMember> | null | undefined
  ): Promise<IGroupMember[]> {
    return Promise.resolve(this.findAll({ rId: roomId }, select, options));
  }

  findByRoomIdAndDelete(
    roomId: string,
    filter: FilterQuery<IGroupMember>
  ): Promise<DeleteResult> {
    return Promise.resolve(this.deleteMany({ rId: roomId }));
  }

  findByRoomIdAndUpdate(
    roomId: string,
    update: Partial<IGroupMember>
  ): Promise<any> {
    return Promise.resolve(
      this.updateMany(
        {
          rId: roomId,
        },
        update
      )
    );
  }

  findOne(
    filter: FilterQuery<IGroupMember>,
    select?: string | null | undefined
  ): Promise<IGroupMember | null> {
    return Promise.resolve(this.model.findOne(filter, select));
  }

  findByRoomIdAndUserIdAndUpdate(
    roomId: string,
    userId: string,
    update: Partial<IGroupMember>,
    session?: ClientSession
  ): Promise<IGroupMember | null> {
    return Promise.resolve(
      this.findOneAndUpdate({ rId: roomId, uId: userId }, update, session)
    );
  }

  createMany(
    obj: Array<Partial<IGroupMember>>,
    session?: ClientSession
  ): Promise<IGroupMember[]> {
    return Promise.resolve(this.model.create(obj, { session }));
  }

  findOneAndUpdate(
    filter: FilterQuery<IGroupMember>,
    update: Partial<IGroupMember>,
    session?: ClientSession,
    options?: QueryOptions<IGroupMember> | null | undefined
  ): Promise<IGroupMember | null> {
    return Promise.resolve(
      this.model.findOneAndUpdate(filter, update, options).session(session)
    );
  }

  async getMembersCount(rId: string): Promise<number> {
    return this.model.countDocuments({
      rId,
    });
  }

  async deleteOne(filter: FilterQuery<IGroupMember>): Promise<DeleteResult> {
    return this.model.deleteOne(filter);
  }

  async findCount(filter: FilterQuery<IGroupMember>): Promise<number> {
    return this.model.countDocuments(filter).lean();
  }

  paginate(paginationParameters: any[]): Promise<any> {
    return Promise.resolve(this.model.paginate(...paginationParameters));
  }
}
