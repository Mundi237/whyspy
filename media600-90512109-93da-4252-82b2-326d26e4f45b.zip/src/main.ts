/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {NestFactory} from "@nestjs/core";
import {AppModule} from "./app.module";

import path, {join} from "path";
import * as admin from "firebase-admin";
import root from "app-root-path";

// Polyfill fetch for link-preview-js and other packages that need it
import {fetch, Headers, Request, Response} from "undici";

global.fetch = fetch as any;
global.Headers = Headers as any;
global.Request = Request as any;
global.Response = Response as any;

import requestIp from "request-ip";
import bodyParser from "body-parser";
import helmet from "helmet";

import morgan from "morgan";
import {ValidationPipe, VersioningType} from "@nestjs/common";
import {NestExpressApplication} from "@nestjs/platform-express";
import {RedisIoAdapter} from "./chat/socket_io/redis-io.adapter";
import {DocumentBuilder, SwaggerModule} from '@nestjs/swagger';

/**
 * Initializes and starts the application. Configures the application with various middleware,
 * services, and providers based on environment variables. Sets up push notification providers,
 * initializes websocket adapters, and starts the server on the configured port.
 *
 * @return {Promise<void>} A promise that resolves once the application is successfully initialized and started.
 */
async function bootstrap() {
    console.log(process.env.NODE_ENV);
    if (process.env.isFirebaseFcmEnabled == "true") {
        console.log("You use firebase as  push notification provider");
        admin.initializeApp({
            credential: admin.credential.cert(
                path.join(root.path, "firebase-adminsdk.json")
            ),
        });
    }
    if (process.env.isOneSignalEnabled == "true") {
        console.log("You use  OneSignal as  push notification provider ");
    }
    const app = await NestFactory.create<NestExpressApplication>(AppModule, {
        cors: {
            origin: "*",
        },
        logger: ["error", "warn"],
    });
    let isDev = process.env.NODE_ENV == "development";
    app.use(
        morgan("tiny", {
            skip: function (req, res) {
                if (isDev) {
                    return false;
                }
                return res.statusCode < 400;
            },
        })
    );
    app.enableCors({
        origin: '*', // Allow only your frontend domain
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    });

    app.use(helmet({crossOriginResourcePolicy: false,}));
    app.use(bodyParser.json({limit: '50mb'}));
    app.use(bodyParser.urlencoded({extended: false, limit: '50mb'}));
    app.useGlobalPipes(
        new ValidationPipe({
            whitelist: true,
            // it case with i18n RangeError: Maximum call stack size exceeded
            validateCustomDecorators: false,
            stopAtFirstError: true,
            transform: true,
        })
    );
    app.use(requestIp.mw());
    const redisIoAdapter = new RedisIoAdapter(app);
    app.useWebSocketAdapter(redisIoAdapter);
    const port = process.env.PORT ?? 80;
    app.useStaticAssets(join(root.path, "public"));
    app.useStaticAssets(join(root.path, "public", "v-public"));
    app.useStaticAssets(join(root.path, "public", "media"));

    if (isDev) {
        // Setup Swagger
        const config = new DocumentBuilder()
            .setTitle('Super Up API')
            .setDescription('The Super Up API documentation')
            .setVersion('1.0')
            .addBearerAuth()
            .build();
        const document = SwaggerModule.createDocument(app, config);
        SwaggerModule.setup('api/docs', app, document);

    }

    await app.listen(port);

    console.log("app run on port " + port);
    console.log(`Swagger documentation is available at http://localhost:${port}/api/docs`);
}

bootstrap();
