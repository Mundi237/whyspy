/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {Injectable, NotFoundException} from '@nestjs/common';
import {BaseRepository} from "../../core/common/base.service";
import {ICountry} from "./countries.entity";
import {InjectModel} from "@nestjs/mongoose";
import {FilterQuery, PaginateModel, QueryOptions, UpdateQuery} from "mongoose";
import { ClientSession } from 'mongoose';

@Injectable()
export class CountriesService extends BaseRepository<ICountry> {

    constructor(
        @InjectModel("countries") readonly model: PaginateModel<ICountry>,
    ) {
        super(model)
    }


    estimatedDocumentCount(): Promise<any> {
        return Promise.resolve(this.model.estimatedDocumentCount());
    }


    async findByIdOrThrow(
        id: string,
        select?: string | null | undefined,
    ): Promise<ICountry> {
        let m = await this.findById(id, select);
        if (!m)
            throw new NotFoundException(
                'country with id ' + id + ' not found in db',
            );
        return m;
    }


    findCount(filter: FilterQuery<ICountry>, session?: ClientSession): Promise<any> {
        return Promise.resolve(this.model.estimatedDocumentCount(filter).session(session),);
    }
}
