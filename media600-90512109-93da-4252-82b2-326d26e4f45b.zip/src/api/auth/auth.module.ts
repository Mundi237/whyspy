/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { Module, forwardRef } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { AuthController } from "./auth.controller";
import { ConfigModule } from "@nestjs/config";
import { UserModule } from "../user_modules/user/user.module";
import { UserDeviceModule } from "../user_modules/user_device/user_device.module";
import { AppConfigModule } from "../app_config/app_config.module";
import { UserCountryModule } from "../user_modules/user_country/user_country.module";
import { FileUploaderModule } from "../../common/file_uploader/file_uploader.module";
import { NotificationEmitterModule } from "../../common/notification_emitter/notification_emitter.module";
import { MailEmitterModule } from "../mail/mail.emitter.module";
import { APP_GUARD } from "@nestjs/core";
import { RolesGuard } from "../../core/guards/roles.guard";
import { JwtModule } from "../../modules/jwt/jwt.module";
import { SocketIoModule } from "../../chat/socket_io/socket_io.module";

@Module({
  controllers: [AuthController],
  providers: [
    AuthService,
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
  ],
  exports: [AuthService],
  imports: [
    JwtModule,
    FileUploaderModule,
    UserModule,
    UserCountryModule,
    AppConfigModule,
    UserDeviceModule,
    NotificationEmitterModule,
    MailEmitterModule,
    forwardRef(() => SocketIoModule),
  ],
})
export class AuthModule {}
