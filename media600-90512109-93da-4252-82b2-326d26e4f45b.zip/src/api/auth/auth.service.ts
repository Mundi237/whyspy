/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
    BadRequestException,
    ForbiddenException,
    HttpException,
    Injectable,
    UnauthorizedException,
    Inject,
    forwardRef,
} from "@nestjs/common";
import bcrypt from "bcrypt";
import date from "date-and-time";
import geoIp from "geoip-lite";
import {remove} from "remove-accents";
import {isUUID} from "class-validator";
import {ConfigService} from "@nestjs/config";

import {UserService} from "../user_modules/user/user.service";
import {UserDeviceService} from "../user_modules/user_device/user_device.service";
import {AppConfigService} from "../app_config/app_config.service";
import {UserCountryService} from "../user_modules/user_country/user_country.service";
import {FileUploaderService} from "../../common/file_uploader/file_uploader.service";
import {NotificationEmitterService} from "../../common/notification_emitter/notification_emitter.service";
import {MailEmitterService} from "../mail/mail.emitter.service";
import {JwtTokenService} from "../../modules/jwt/services/jwt.service";
import {DashboardGateway} from "../../chat/socket_io/dashboard.gateway";

import {IUser} from "../user_modules/user/entities/user.entity";
import {JwtDecodeRes} from "../../modules/jwt/interfaces/jwt-decode-res.interface";

import LoginDto from "./dto/login.dto";
import RegisterDto from "./dto/register.dto";
import ResetPasswordDto from "./dto/reset.password.dto";
import LogoutDto from "./dto/logout.dto";

import {
    MailType,
    Platform,
    PushTopics,
    VPushProvider,
    UserRole,
} from "../../core/utils/enums";
import {resOK, i18nApi} from "../../core/utils/res.helpers";
import {newMongoObjId} from "../../core/utils/utils";
import {IAppConfig} from "../app_config/entities/app_config.entity";


interface AuthResponse {
    accessToken: string;
    tokenType: string;

    status: string;
}

@Injectable()
export class AuthService {

    constructor(
        private readonly uploaderService: FileUploaderService,
        private readonly jwtTokenService: JwtTokenService,
        private readonly userService: UserService,
        private readonly appConfigService: AppConfigService,
        private readonly configService: ConfigService,
        private readonly userDeviceService: UserDeviceService,
        private readonly mailEmitterService: MailEmitterService,
        private readonly userCountryService: UserCountryService,
        private readonly notificationEmitterService: NotificationEmitterService,
        @Inject(forwardRef(() => DashboardGateway))
        private readonly dashboardGateway: DashboardGateway
    ) {
    }

    /**
     * Authenticate user with email and password
     * @param loginDto Login data transfer object
     * @param isDev Development mode flag
     * @returns Login response with access token
     */
    async login(loginDto: LoginDto, isDev: boolean): Promise<AuthResponse> {
        const user = await this.validateUserCredentials(
            loginDto.email,
            loginDto.password
        );
        this.validateUserStatus(user);

        await this.updateUserLocationData(
            user._id,
            loginDto.ip
        );
        const device = await this.handleUserDevice(user._id, loginDto);

        const accessToken = this.generateAccessToken(
            user._id,
            device._id,
            user.roles
        );

        return {
            accessToken,
            tokenType: "Bearer",

            status: user.registerStatus,
        };
    }

    /**
     * Register a new user
     * @param registerDto Registration data transfer object
     * @returns Authentication response with access token
     */
    async register(registerDto: RegisterDto): Promise<AuthResponse> {
        await this.validateEmailAvailability(registerDto.email);

        const uniqueCode = await this.generateUniqueCode();
        const appConfig = await this.appConfigService.getConfig();
        const countryData = geoIp.lookup(registerDto.ip);

        const userData = this.buildUserData(
            registerDto,
            uniqueCode,
            countryData,
            appConfig
        );
        const createdUser = await this.userService.create(userData);

        await this.updateUserCountryData(createdUser._id, countryData);
        const device = await this.createUserDevice(createdUser._id, registerDto);

        if (registerDto.imageBuffer) {
            await this.updateUserImage(createdUser._id, registerDto.imageBuffer);
        }

        await this.subscribeToPushNotifications(
            registerDto.pushKey,
            registerDto.platform
        );

        const accessToken = this.generateAccessToken(createdUser._id, device._id, []);

        // Notify dashboard about new user registration
        this.dashboardGateway.notifyNewUserRegistration(createdUser);

        return {
            accessToken,
            tokenType: "Bearer",
            status: appConfig.userRegisterStatus,
        };
    }

    /**
     * Send OTP for password reset
     * @param email User email
     * @param isDev Development mode flag
     * @returns Success message
     */
    async sendOtpResetPassword(email: string, isDev: boolean): Promise<string> {
        const user = await this.userService.findOneByEmailOrThrow(
            email.toLowerCase(),
            "email fullName userImages verifiedAt lastMail"
        );

        const code = await this.mailEmitterService.sendConfirmEmail(
            user,
            MailType.ResetPassword,
            isDev
        );

        await this.updateUserLastMail(user._id, MailType.ResetPassword, code);

        return isDev
            ? `Password reset code has been sent to your email: ${code}`
            : "Password reset code has been sent to your email";
    }

    /**
     * Verify OTP and reset password
     * @param resetPasswordDto Reset password data transfer object
     * @returns Success message
     */
    async verifyOtpResetPassword(
        resetPasswordDto: ResetPasswordDto
    ): Promise<string> {
        const user = await this.userService.findOneByEmailOrThrow(
            resetPasswordDto.email,
            "lastMail"
        );

        this.validateResetPasswordCode(user, resetPasswordDto.code);

        await this.userService.findByIdAndUpdate(user._id, {
            "lastMail.expired": true,
            password: resetPasswordDto.newPassword,
        });

        return "Password has been reset successfully";
    }

    /**
     * Get verified user from access token
     * @param accessToken JWT access token
     * @returns Verified user data
     */
    async getVerifiedUser(accessToken: string): Promise<IUser> {
        const jwtDecodeRes = this.verifyJwtToken(accessToken);

        const user = await this.userService.findById(
            jwtDecodeRes.userId,
            "fullName fullNameEn verifiedAt userImage roles banTo deletedAt registerStatus"
        );

        if (!user) {
            throw new ForbiddenException(i18nApi.whileAuthCanFindYouString);
        }

        this.validateUserLoginStatus(user);

        const device = await this.userDeviceService.findById(
            jwtDecodeRes.deviceId,
            "_id platform"
        );

        if (!device) {
            throw new HttpException(
                i18nApi.userDeviceSessionEndDeviceDeletedString,
                450
            );
        }

        user._id = user._id.toString();
        user.currentDevice = device;

        return user;
    }

    /**
     * Logout user from current device or all devices
     * @param logoutDto Logout data transfer object
     * @returns Success message
     */
    async logOut(logoutDto: LogoutDto): Promise<string> {
        if (logoutDto.logoutFromAll) {
            return await this.logoutFromAllDevices(logoutDto);
        }

        await this.userDeviceService.findByIdAndDelete(
            logoutDto.myUser.currentDevice._id
        );
        return "Device has been logged out";
    }

    /**
     * Generate unique code for user
     * @returns Unique 6-digit code
     */
    async generateUniqueCode(): Promise<number> {
        let uniqueCode: number;
        let isUnique = false;

        while (!isUnique) {
            uniqueCode = Math.floor(100000 + Math.random() * 900000);

            const existingUser = await this.userService.findOne(
                {uniqueCode},
                "uniqueCode"
            );

            if (!existingUser) {
                isUnique = true;
            }
        }

        return uniqueCode;
    }

    // Private helper methods

    /**
     * Validate user credentials
     * @param email User email
     * @param password User password
     * @returns User data if valid
     */
    private async validateUserCredentials(
        email: string,
        password: string
    ): Promise<IUser> {
        const user = await this.userService.findOneByEmailOrThrow(
            email,
            "+password userDevice lastMail banTo email registerStatus deletedAt roles"
        );

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            throw new BadRequestException(i18nApi.invalidLoginDataString);
        }

        return user;
    }

    /**
     * Validate user status for login
     * @param user User data
     */
    private validateUserStatus(user: IUser): void {
        if (user.banTo) {
            throw new BadRequestException(i18nApi.yourAccountBlockedString);
        }

        if (user.deletedAt) {
            throw new HttpException(i18nApi.yourAccountDeletedString, 450);
        }
    }

    /**
     * Update user location data based on IP
     * @param userId User ID
     * @param ip IP address
     * @returns Country data
     */
    private async updateUserLocationData(
        userId: string,
        ip: string
    ): Promise<any> {
        const countryData = geoIp.lookup(ip);

        if (countryData) {
            const countryId = await this.userCountryService.setUserCountry(
                userId,
                countryData.country
            );

            await this.userService.findByIdAndUpdate(userId, {
                address: countryData,
                countryId,
            });
        }

        return countryData;
    }

    /**
     * Handle user device login/creation
     * @param userId User ID
     * @param loginDto Login data
     * @returns Device data
     */
    private async handleUserDevice(
        userId: string,
        loginDto: LoginDto
    ): Promise<any> {
        const existingDevice = await this.userDeviceService.findOne({
            uId: userId,
            userDeviceId: loginDto.deviceId,
        });

        if (existingDevice) {
            await this.userDeviceService.findByIdAndUpdate(existingDevice._id, {
                pushProvider: this.getVPushProvider(loginDto.pushKey),
                pushKey: loginDto.pushKey,
            });

            return existingDevice;
        }

        return await this.createNewDevice(userId, loginDto);
    }

    /**
     * Create new device for user
     * @param userId User ID
     * @param deviceData Device data
     * @returns Created device
     */
    private async createNewDevice(userId: string, deviceData: any): Promise<any> {
        const deviceId = newMongoObjId().toString();

        const device = await this.userDeviceService.create({
            _id: deviceId,
            userDeviceId: deviceData.deviceId,
            uId: userId,
            language: deviceData.language,
            platform: deviceData.platform,
            pushProvider: this.getVPushProvider(deviceData.pushKey),
            dIp: deviceData.ip,
            deviceInfo: deviceData.deviceInfo,
            pushKey: deviceData.pushKey,
        });

        await this.subscribeToPushNotifications(
            deviceData.pushKey,
            deviceData.platform
        );

        return device;
    }

    /**
     * Validate email availability for registration
     * @param email Email to check
     */
    private async validateEmailAvailability(email: string): Promise<void> {
        const existingUser = await this.userService.findOneByEmail(email, "email");

        if (existingUser) {
            throw new BadRequestException(i18nApi.userAlreadyRegisterString);
        }
    }

    /**
     * Build user data for creation
     * @param registerDto Registration data
     * @param uniqueCode Generated unique code
     * @param countryData Country information
     * @param appConfig Application config
     * @returns User creation data
     */
    private buildUserData(
        registerDto: RegisterDto,
        uniqueCode: number,
        countryData: any,
        appConfig: IAppConfig
    ): any {
        return {
            email: registerDto.email,
            fullName: registerDto.fullName,
            registerStatus: appConfig.userRegisterStatus,
            bio: null,
            uniqueCode,
            fullNameEn: remove(registerDto.fullName),
            registerMethod: registerDto.method,
            address: countryData,
            password: registerDto.password,
            lastSeenAt: new Date(),
            lastMail: {},
            userImage: appConfig.userIcon,
            roles: [],
        };
    }

    /**
     * Update user country data
     * @param userId User ID
     * @param countryData Country information
     */
    private async updateUserCountryData(
        userId: string,
        countryData: any
    ): Promise<void> {
        if (countryData) {
            const countryId = await this.userCountryService.setUserCountry(
                userId,
                countryData.country
            );

            await this.userService.findByIdAndUpdate(userId, {countryId});
        }
    }

    /**
     * Create user device for registration
     * @param userId User ID
     * @param registerDto Registration data
     * @returns Created device
     */
    private async createUserDevice(
        userId: string,
        registerDto: RegisterDto
    ): Promise<any> {
        const deviceId = newMongoObjId().toString();

        return await this.userDeviceService.create({
            _id: deviceId,
            userDeviceId: registerDto.deviceId,
            uId: userId,
            language: registerDto.language,
            platform: registerDto.platform,
            pushProvider: this.getVPushProvider(registerDto.pushKey),
            dIp: registerDto.ip,
            deviceInfo: registerDto.deviceInfo,
            pushKey: registerDto.pushKey,
            lastSeenAt: new Date(),
        });
    }

    /**
     * Update user profile image
     * @param userId User ID
     * @param imageBuffer Image buffer
     */
    private async updateUserImage(
        userId: string,
        imageBuffer: Buffer
    ): Promise<void> {
        const imageResult = await this.uploaderService.putImageCropped(
            imageBuffer,
            userId
        );
        await this.userService.findByIdAndUpdate(userId, {
            userImage: imageResult,
        });
    }

    /**
     * Update user last mail information
     * @param userId User ID
     * @param mailType Mail type
     * @param code Generated code
     */
    private async updateUserLastMail(
        userId: string,
        mailType: MailType,
        code: number
    ): Promise<void> {
        await this.userService.findByIdAndUpdate(userId, {
            lastMail: {
                type: mailType,
                sendAt: new Date(),
                code,
                expired: false,
            },
        });
    }

    /**
     * Validate reset password code
     * @param user User data
     * @param code Reset code
     */
    private validateResetPasswordCode(user: IUser, code: number): void {
        if (!user.lastMail || !user.lastMail.code) {
            throw new BadRequestException(
                i18nApi.noCodeHasBeenSendToYouToVerifyYourEmailString
            );
        }

        const appConfig = this.appConfigService.getConfig();
        const minutesSinceMailSent = parseInt(
            date.subtract(new Date(), user.lastMail.sendAt).toMinutes().toString(),
            10
        );

        if (
            user.lastMail.expired ||
            minutesSinceMailSent > (appConfig as any).maxExpireEmailTime
        ) {
            throw new BadRequestException(i18nApi.codeHasBeenExpiredString);
        }

        if (user.lastMail.type !== MailType.ResetPassword) {
            throw new BadRequestException("Cannot process with the mail type");
        }

        if (user.lastMail.code !== code) {
            throw new BadRequestException(i18nApi.invalidCodeString);
        }
    }

    /**
     * Validate user login status
     * @param user User data
     */
    private validateUserLoginStatus(user: IUser): void {
        if (user.banTo) {
            throw new HttpException(i18nApi.yourAccountBlockedString, 450);
        }

        if (user.deletedAt) {
            throw new HttpException(i18nApi.yourAccountDeletedString, 450);
        }
    }

    /**
     * Logout user from all devices
     * @param logoutDto Logout data
     * @returns Success message
     */
    private async logoutFromAllDevices(logoutDto: LogoutDto): Promise<string> {
        const user = await this.userService.findById(
            logoutDto.myUser._id,
            "+password userDevice verifiedAt lastMail banTo email registerStatus"
        );

        const isPasswordValid = await bcrypt.compare(
            logoutDto.password,
            user.password
        );
        if (!isPasswordValid) {
            throw new BadRequestException(i18nApi.invalidLoginDataString);
        }

        await this.userDeviceService.deleteMany({uId: logoutDto.myUser._id});

        return i18nApi.deviceHasBeenLogoutFromAllDevicesString;
    }

    /**
     * Generate access token
     * @param userId User ID
     * @param deviceId Device ID
     * @param roles User roles
     * @returns JWT access token
     */
    private generateAccessToken(
        userId: string,
        deviceId: string,
        roles: string[]
    ): string {
        return this.jwtTokenService.signJwt(
            userId.toString(),
            deviceId.toString(),
            roles
        );
    }


    /**
     * Verify JWT token
     * @param token JWT token
     * @returns Decoded token data
     */
    private verifyJwtToken(token: string): JwtDecodeRes {
        try {
            return this.jwtTokenService.verifyJwt(token);
        } catch (error) {
            throw new BadRequestException(`JWT access token not valid: ${token}`);
        }
    }

    /**
     * Get push provider based on push key format
     * @param pushKey Push key
     * @returns Push provider type
     */
    private getVPushProvider(pushKey?: string): VPushProvider | null {
        if (!pushKey) return null;

        const isOneSignal = isUUID(pushKey.toString());
        return isOneSignal ? VPushProvider.onesignal : VPushProvider.fcm;
    }

    /**
     * Subscribe to push notification topics
     * @param pushKey Push key
     * @param platform Device platform
     */
    private async subscribeToPushNotifications(
        pushKey: string,
        platform: Platform
    ): Promise<void> {
        if (!pushKey) return;

        const pushProvider = this.getVPushProvider(pushKey);
        const topic =
            platform === Platform.Android
                ? PushTopics.AdminAndroid
                : PushTopics.AdminIos;

        if (pushProvider === VPushProvider.fcm) {
            await this.notificationEmitterService.subscribeFcmTopic(pushKey, topic);
        } else {
            await this.notificationEmitterService.subscribeOnesignalTopic(
                pushKey,
                topic
            );
        }
    }
}
