/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
  BadRequestException,
  Body,
  Controller,
  HttpCode,
  Patch,
  Post,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { AuthService } from "./auth.service";
import RegisterDto from "./dto/register.dto";
import LoginDto from "./dto/login.dto";
import { IpAddress } from "../../core/custom.decorator/request.ip";
import { IsDevelopment } from "../../core/custom.decorator/decorators";
import { jsonDecoder } from "../../core/utils/app.validator";
import { imageFileInterceptor } from "../../core/utils/upload_interceptors";
import { resOK } from "../../core/utils/res.helpers";
import LogoutDto from "./dto/logout.dto";
import { VerifiedAuthGuard } from "../../core/guards/verified.auth.guard";
import ResetPasswordDto from "./dto/reset.password.dto";
import { V1Controller } from "../../core/common/v1-controller.decorator";
import { ApiTags, ApiOperation, ApiResponse } from "@nestjs/swagger";

@V1Controller("auth")
@ApiTags("Authentication")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post("/login")
  @HttpCode(200)
  @ApiOperation({ summary: "User login" })
  @ApiResponse({
    status: 200,
    description: "Login successful, returns access token",
  })
  @ApiResponse({
    status: 400,
    description: "Invalid credentials",
  })
  async login(
    @Body() loginDto: LoginDto,
    @IpAddress() ipAddress: string,
    @IsDevelopment() isDev: boolean
  ) {
    loginDto.ip = ipAddress;
    try {
      loginDto.deviceInfo = jsonDecoder(loginDto.deviceInfo);
    } catch (error) {
      // Ignore JSON parsing errors for deviceInfo
    }
    return resOK(await this.authService.login(loginDto, isDev));
  }

  @Post("/register")
  @UseInterceptors(imageFileInterceptor)
  @ApiOperation({ summary: "User registration" })
  @ApiResponse({
    status: 201,
    description: "Registration successful, returns access token",
  })
  @ApiResponse({
    status: 400,
    description: "User already exists or invalid data",
  })
  async registerUser(
    @Body() registerDto: RegisterDto,
    @IpAddress() ipAddress: string,
    @UploadedFile() file?: any
  ) {
    if (file) {
      registerDto.imageBuffer = file.buffer;
    }
    try {
      registerDto.deviceInfo = jsonDecoder(registerDto.deviceInfo);
    } catch (error) {
      // Ignore JSON parsing errors for deviceInfo
    }
    registerDto.ip = ipAddress;
    return resOK(await this.authService.register(registerDto));
  }

  @Post("/send-otp-reset-password")
  @HttpCode(200)
  @ApiOperation({ summary: "Send OTP for password reset" })
  @ApiResponse({
    status: 200,
    description: "OTP sent successfully",
  })
  @ApiResponse({
    status: 400,
    description: "Invalid email or user not found",
  })
  async sendOtpResetPassword(
    @Body("email") email: string,
    @IsDevelopment() isDev: boolean
  ) {
    if (!email) {
      throw new BadRequestException("Email is required");
    }
    return resOK(await this.authService.sendOtpResetPassword(email, isDev));
  }

  @Post("/verify-and-reset-password")
  @HttpCode(200)
  @ApiOperation({ summary: "Verify OTP and reset password" })
  @ApiResponse({
    status: 200,
    description: "Password reset successfully",
  })
  @ApiResponse({
    status: 400,
    description: "Invalid or expired OTP",
  })
  async verifyOtpResetPassword(@Body() resetPasswordDto: ResetPasswordDto) {
    return resOK(
      await this.authService.verifyOtpResetPassword(resetPasswordDto)
    );
  }

  @UseGuards(VerifiedAuthGuard)
  @Post("/logout")
  @HttpCode(200)
  @ApiOperation({ summary: "User logout" })
  @ApiResponse({
    status: 200,
    description: "Logout successful",
  })
  async logOut(@Body() logoutDto: LogoutDto, @Req() req: any) {
    logoutDto.myUser = req.user;
    return resOK(await this.authService.logOut(logoutDto));
  }
}
