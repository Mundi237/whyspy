/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
    FilterQuery,
    PaginateModel,
} from "mongoose";
import {Injectable} from '@nestjs/common';
import {InjectModel} from "@nestjs/mongoose";
import {BaseRepository,} from "../../core/common/base.service";
import {IBan} from "./entities/ban.entity";

@Injectable()
export class BanService extends BaseRepository<IBan> {
    constructor(
        @InjectModel('ban') readonly model: PaginateModel<IBan>,
    ) {
        super(model);
    }


    async getBan(myId: string, peerId: string) {
        return this.model.findOne({
            $or: [
                {$and: [{targetId: myId}, {bannerId: peerId}]},
                {$and: [{bannerId: myId}, {targetId: peerId}]}
            ]
        })
    }

    findCount(filter: FilterQuery<IBan>, session): any {
        return this.model.countDocuments(filter)
    }

    paginate(paginationParameters: any[]) {
        return Promise.resolve(this.model.paginate(...paginationParameters));
    }
}
