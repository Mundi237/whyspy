/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { ReportSystemService } from './report_system.service';
import { V1Controller } from "../../core/common/v1-controller.decorator";
import { Body, Get, Post, Query, Req } from '@nestjs/common';
import { CreateReportDto } from './dto/create-report.dto';
import { PaginationDto } from './dto/pagination.dto';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Auth } from '../../core/decorators/auth.decorator';
import {resOK} from "../../core/utils/res.helpers";

@ApiTags('Reports')
@Auth()
@V1Controller('report')
export class ReportSystemController {
  constructor(private readonly reportSystemService: ReportSystemService) {}

  /**
   * Create a new report
   */
  @Post()
  @ApiOperation({ summary: 'Create a new report' })
  async createReport(@Req() req, @Body() createReportDto: CreateReportDto) {
    createReportDto.myUser = req.user ; // Set the user ID from the request
    try {
      const report = await this.reportSystemService.createReport(req.user._id, createReportDto);
      return resOK(report);
    } catch (error) {
      if (error.message === 'A report with the same type, reason, and user already exists') {
        throw new Error('You have already submitted a similar report. Please wait for it to be processed.');
      }
      throw error;
    }
  }

  /**
   * Get reports created by the current user with pagination
   */
  @Get('my-reports')
  @ApiOperation({ summary: 'Get reports created by the current user' })
  async getMyReports(@Req() req, @Query() paginationDto: PaginationDto) {
    return resOK(await this.reportSystemService.getUserReports(req.user.id, paginationDto));
  }
}
