/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */
import { Transform, Type } from 'class-transformer';
import { IsEnum, IsInt, IsObject, IsOptional, Max, Min, ValidateNested } from 'class-validator';
import { SortOrder } from 'mongoose';
import { ApiProperty } from '@nestjs/swagger';
import { BadRequestException } from '@nestjs/common';

export class PaginationDto {
  @ApiProperty({
    description: 'Page number (starts from 1)',
    minimum: 1,
    default: 1,
    required: false,
    type: Number,
    example: 1
  })
  @IsInt()
  @Min(1)
  @IsOptional()
  @Type(() => Number)
  page?: number;

  @ApiProperty({
    description: 'Number of items per page',
    minimum: 1,
    maximum: 100,
    default: 10,
    required: false,
    type: Number,
    example: 10
  })
  @IsInt()
  @Min(1)
  @Max(100)
  @IsOptional()
  @Type(() => Number)
  limit?: number;

  @ApiProperty({
    description: 'Sorting criteria (field and direction). Pass as JSON string in query params.',
    required: false,
    type: 'string',
    example: '{"createdAt":-1}',
    additionalProperties: {
      type: 'number',
      enum: [-1, 1]
    }
  })
  @IsOptional()
  @Transform(({ value }) => {
    if (typeof value === 'string') {
      try {
        const parsed = JSON.parse(value);
        if (typeof parsed !== 'object' || parsed === null) {
          throw new BadRequestException('Sort must be an object');
        }
        return parsed;
      } catch {
        throw new BadRequestException('Invalid sort JSON format');
      }
    }
    return value;
  })
  @IsObject()
  sort?: Record<string, SortOrder>;

  // Method to get values with defaults
  getPage(): number {
    return this.page ?? 1;
  }

  getLimit(): number {
    return this.limit ?? 10;
  }
}