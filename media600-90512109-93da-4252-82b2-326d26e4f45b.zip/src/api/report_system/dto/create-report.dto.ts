/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import { IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { ReportReasonType, ReportType } from '../entities/report_system.entity';
import { ApiProperty } from '@nestjs/swagger';
import CommonDto from "../../../core/common/dto/common.dto";

export class CreateReportDto extends CommonDto{
  @ApiProperty({
    description: 'The type of report',
    enum: ReportType,
    example: Object.values(ReportType)[0]
  })
  @IsEnum(ReportType)
  @IsNotEmpty()
  type: ReportType;

  @ApiProperty({
    description: 'The reason for the report',
    enum: ReportReasonType,
    example: Object.values(ReportReasonType)[0]
  })
  @IsEnum(ReportReasonType)
  @IsNotEmpty()
  reasonType: ReportReasonType;

  @ApiProperty({
    description: 'Additional content or description for the report',
    required: false,
    maxLength: 500,
    example: 'This user is posting inappropriate content'
  })
  @IsString()
  @IsOptional()
  @MaxLength(500)
  content?: string;

  @ApiProperty({
    description: 'ID of the user being reported',
    required: false,
    example: '60d21b4667d0d8992e610c85'
  })
  @IsString()
  @IsOptional()
  userId?: string;

  @ApiProperty({
    description: 'ID of the chat being reported',
    required: false,
    example: '60d21b4667d0d8992e610c86'
  })
  @IsString()
  @IsOptional()
  chatId?: string;
}
