/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {Injectable, NotFoundException} from '@nestjs/common';
import {InjectModel} from "@nestjs/mongoose";
import {FilterQuery, PaginateModel, QueryOptions} from "mongoose";
import {IReport, ReportStatus} from "./entities/report_system.entity";
import {BaseRepository, PaginatedResult, PaginationOptions} from "../../core/common/base.service";
import {CreateReportDto} from './dto/create-report.dto';

@Injectable()
export class ReportSystemService extends BaseRepository<IReport> {
    constructor(
        @InjectModel('reports')
        readonly model: PaginateModel<IReport>,
    ) {
        super(model);
    }

    /**
     * Create a new report
     * @param uId User ID of the reporter
     * @param createReportDto Report data
     * @returns Created report
     * @throws Error if a report with the same type, reasonType and uId already exists
     */
    async createReport(uId: string, createReportDto: CreateReportDto): Promise<IReport> {
        // Check if report with same type, reasonType and uId already exists
        const existingReport = await this.findOne({
            uId,
            type: createReportDto.type,
            reasonType: createReportDto.reasonType
        });

        if (existingReport) {
            throw new Error('A report with the same type, reason, and user already exists');
        }

        return this.create({
            uId,
            ...createReportDto,
            status: ReportStatus.PENDING
        });
    }

    /**
     * Get reports created by a user with pagination
     * @param uId User ID
     * @param paginationOptions Pagination options
     * @returns Paginated reports
     */
    async getUserReports(uId: string, paginationOptions: PaginationOptions): Promise<PaginatedResult<IReport>> {
        return this.findWithPagination(
            { uId },
            paginationOptions,
            null
        );
    }

}
