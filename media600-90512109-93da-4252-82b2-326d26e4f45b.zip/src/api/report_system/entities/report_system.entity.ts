/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import mongoose, {Document, Schema} from "mongoose";
import {Platform} from "../../../core/utils/enums";
import pM from "mongoose-paginate-v2";

/**
 * Defines the types of reports that can be created
 */
export enum ReportType {
    USER = "user",
    CHAT = "chat"
}

/**
 * Defines the reason types for reports
 */
export enum ReportReasonType {
    SPAM = "spam",
    HARASSMENT = "harassment",
    INAPPROPRIATE_CONTENT = "inappropriate_content",
    HATE_SPEECH = "hate_speech",
    VIOLENCE = "violence"
}

/**
 * Defines the possible statuses of a report
 */
export enum ReportStatus {
    PENDING = "pending",
    APPROVED = "approved",
    REJECTED = "rejected"
}

/**
 * Interface representing a Report document
 */
export interface IReport extends Document {
    uId: string;
    content?: string;
    type: ReportType;
    reasonType: ReportReasonType;
    chatId?: string;
    userId?: string;
    status: ReportStatus;
    createdAt: Date;
    updatedAt: Date;
}

const reportSchemaFields = {
    uId: {
        type: String,
        required: true,
        ref: "user",
        index: true
    },
    userId: {
        type: String,
        required: false,
        ref: "user",
        sparse: true
    },
    content: {
        type: String,
        required: false,
        trim: true
    },
    type: {
        type: String,
        required: true,
        enum: Object.values(ReportType)
    },
    reasonType: {
        type: String,
        required: true,
        enum: Object.values(ReportReasonType)
    },
    chatId: {
        type: String,
        ref: "chats",
        sparse: true
    },
    status: {
        type: String,
        required: true,
        enum: Object.values(ReportStatus),
        default: ReportStatus.PENDING,
        index: true
    },

    resolvedAt: {
        type: Date
    },
};

export const ReportSchema = new Schema(reportSchemaFields, {
    timestamps: true,
    collection: 'reports'
});

// Add pagination plugin
ReportSchema.plugin(pM);