/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
    Controller,
    Get,
    Req,
    Param,
    Patch,
    Body,
    UseInterceptors,
    BadRequestException, UploadedFile, Post, Query, Delete, HttpCode, HttpStatus, Request,
} from "@nestjs/common";
import {ProfileService} from "./profile.service";

import {
    UpdateChatReqStatusDto,
    UpdateMyBioDto,
    UpdateMyNameDto,
    UpdateMyPasswordDto,
    UpdateMyPrivacyDto
} from "./dto/update.my.name.dto";
import UpdatePasswordDto from "./dto/update_password_dto";
import {resOK} from "../../core/utils/res.helpers";
import {imageFileInterceptor} from "../../core/utils/upload_interceptors";
import {MongoIdDto} from "../../core/common/dto/mongo.id.dto";
import CheckVersionDto from "./dto/check-version.dto";
import {V1Controller} from "../../core/common/v1-controller.decorator";
import {MongoPeerIdDto} from "../../core/common/dto/mongo.peer.id.dto";
import { Auth } from '../../core/decorators/auth.decorator';
import {Public} from "../../core/decorators/public.decorator";


@V1Controller("profile")
@Auth()
export class ProfileController {
    constructor(private readonly profileService: ProfileService) {
    }


    @Get("/")
    async getMyProfile(@Req() req: any) {
        return resOK(await this.profileService.getMyProfile(req.user));
    }


    @Public()
    @Get("/app-config")
    async getConfig(@Req() req: any) {
        return resOK(await this.profileService.getAppConfig(req.user));
    }

    @Get("/users")
    async getUsersAndSearch(@Req() req: any, @Query() dto: Object) {
        return resOK(await this.profileService.getUsersAndSearch(dto, req.user));
    }

    @Get("/admin-notifications")
    async getAdminNotification(@Req() req: any, @Query() dto: Object) {
        return resOK(await this.profileService.getAdminNotification(dto));
    }

    @Get("/device")
    async getMyDevice(@Req() req: any) {
        return resOK(await this.profileService.getMyDevices(req.user));
    }

    @Delete("/device/:id")
    async deleteDevice(
        @Req() req: any,
        @Param() dto: MongoIdDto,
        @Body('password') password: string
    ) {
        dto.myUser = req.user
        return resOK(await this.profileService.deleteDevice(dto, password));
    }

    @Patch("/name")
    async updateMyName(@Req() req: any, @Body() dto: UpdateMyNameDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updateMyName(dto));
    }


    @Patch("/privacy")
    async updateMyPrivacy(@Req() req: any, @Body() dto: UpdateMyPrivacyDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updateMyPrivacy(dto));
    }


    @Get("/blocked")
    async getMyBlocked(@Req() req: any, @Query() dto: Object) {
        return resOK(await this.profileService.getMyBlocked(req.user, dto));
    }

    @Patch("/bio")
    async updateMyBio(@Req() req: any, @Body() dto: UpdateMyBioDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updateMyBio(dto));
    }

    @Patch("/password")
    async updateMyPassword(@Req() req: any, @Body() dto: UpdateMyPasswordDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updateMyPassword(dto));
    }

    @UseInterceptors(imageFileInterceptor)
    @Patch("/image")
    async updateMyImage(@Req() req: any, @UploadedFile() file?: any) {
        if (!file) {
            throw new BadRequestException("Image is required!");
        }
        return resOK(await this.profileService.updateMyImage(file, req.user));
    }

    @Get("/chat-request")
    async getMyChatRequest(@Req() req: any,   @Query() dto: object) {
        return resOK(await this.profileService.getMyChatRequest(req.user,dto));
    }

    @Get("/:id")
    async getPeerProfile(@Req() req: any, @Param() dto: MongoIdDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.getPeerProfile(dto));
    }

    @Post("/:id/chat-request")
    async sendChatRequest(@Req() req: any, @Param() dto: MongoIdDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.sendChatRequest(dto));
    }

    @Patch("/:id/chat-request")
    async updateChatRequest(
        @Req() req: any,
        @Param() dto: MongoIdDto,
        @Body( ) status: UpdateChatReqStatusDto
    ) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updateChatRequest(dto,status));
    }


    @Delete("/push")
    async deleteFcm(@Req() req: any) {
        return resOK(await this.profileService.deleteFcmFor(req.user));
    }

    @Post("/push")
    async addFcm(
        @Req() req: any,
        @Body("pushKey") pushKey?: string,
        @Body("voipKey") voipKey?: string,

    ) {
        if (!pushKey && !voipKey) {
            throw new BadRequestException("pushKey or voipKey is required");
        }
        return resOK(await this.profileService.addPushKey(req.user, pushKey, voipKey));
    }

    @Patch("/push")
    async updateFcm(@Body("pushKey") pushKey: String, @Req() req: any) {
        if (!pushKey) {
            throw new BadRequestException("pushKey is required");
        }
        return resOK(await this.profileService.updateFcm(req.user, pushKey));
    }

    @Patch("/lang")
    async updateLanguage(@Body("lang") lang: String, @Req() req: any) {
        if (!lang) {
            throw new BadRequestException("lang is required");
        }
        return resOK(await this.profileService.updateLanguage(req.user, lang));
    }

    @Patch("/visit")
    async setVisit(@Req() req: any) {
        return resOK(await this.profileService.setVisit(req.user));
    }

    @Get("/users/:peerId/last-seen")
    async getUserLastSeenAt(
        @Req() req: any,
        @Param() dto: MongoPeerIdDto,
    ) {
        dto.myUser = req.user
        return resOK(await this.profileService.getUserLastSeenAt(dto));
    }

    @Patch("/password")
    async updatePassword(@Body() dto: UpdatePasswordDto, @Req() req: any) {
        dto.myUser = req.user;
        return resOK(await this.profileService.updatePassword(req.user, dto));
    }


    @Delete("/delete-my-account")
    async deleteMyAccount(@Req() req: any, @Body('password') password: string) {
        return resOK(await this.profileService.deleteMyAccount(req.user, password));
    }

    @Patch("/version")
    async checkVersion(@Req() req: any, @Body() dto: CheckVersionDto) {
        dto.myUser = req.user;
        return resOK(await this.profileService.checkVersion(dto));
    }


}
