import { Module } from "@nestjs/common";
import { DashboardController } from "./dashboard.controller";
import { DashboardService } from "./dashboard.service";
import { AnalyticsService } from "./services/analytics.service";
import { UserAnalyticsService } from "./services/user-analytics.service";
import { ChatAnalyticsService } from "./services/chat-analytics.service";
import { CallAnalyticsService } from "./services/call-analytics.service";
import { SystemAnalyticsService } from "./services/system-analytics.service";

// Import required modules
import { UserModule } from "../user_modules/user/user.module";
import { MessageModule } from "../../chat/message/message.module";
import { GroupMemberModule } from "../../chat/group_member/group_member.module";
import { BroadcastMemberModule } from "../../chat/broadcast_member/broadcast_member.module";
import { GroupSettingsModule } from "../../chat/group_settings/group_settings.module";
import { BroadcastSettingsModule } from "../../chat/broadcast_settings/broadcast_settings.module";
import { CallHistoryModule } from "../../chat/call_modules/call_history/call_history.module";
import { UserDeviceModule } from "../user_modules/user_device/user_device.module";
import { UserCountryModule } from "../user_modules/user_country/user_country.module";
import { CountriesModule } from "../countries/countries.module";
import { ReportSystemModule } from "../report_system/report_system.module";
import { AppConfigModule } from "../app_config/app_config.module";
import { RoomMemberModule } from "../../chat/room_member/room_member.module";

// Additional modules for enhanced dashboard
import { StoryModule } from "../stories/story/story.module";
import { StoryAttachmentModule } from "../stories/story_attachment/story_attachment.module";
import { AdminNotificationModule } from "../admin_notification/admin_notification.module";
import { VersionsModule } from "../versions/versions.module";
import { CallModule } from "../../chat/call_modules/call/call.module";
import { CallMemberModule } from "../../chat/call_modules/call_member/call_member.module";
import { SocketIoModule } from "../../chat/socket_io/socket_io.module";
import { ChannelModule } from "../../chat/channel/channel.module";
import { SingleRoomSettingsModule } from "../../chat/single_room_settings/single_room_settings.module";
import { OrderRoomSettingsModule } from "../../chat/order_room_settings/order_room_settings.module";

@Module({
  imports: [
    UserModule,
    MessageModule,
    GroupMemberModule,
    BroadcastMemberModule,
    GroupSettingsModule,
    BroadcastSettingsModule,
    CallHistoryModule,
    UserDeviceModule,
    UserCountryModule,
    CountriesModule,
    ReportSystemModule,
    AppConfigModule,
    RoomMemberModule,

    // Enhanced dashboard modules
    StoryModule,
    StoryAttachmentModule,
    AdminNotificationModule,
    VersionsModule,
    CallModule,
    CallMemberModule,
    SocketIoModule,
    ChannelModule,
    SingleRoomSettingsModule,
    OrderRoomSettingsModule,
  ],
  controllers: [DashboardController],
  providers: [
    DashboardService,
    AnalyticsService,
    UserAnalyticsService,
    ChatAnalyticsService,
    CallAnalyticsService,
    SystemAnalyticsService,
  ],
  exports: [DashboardService],
})
export class DashboardModule {}
