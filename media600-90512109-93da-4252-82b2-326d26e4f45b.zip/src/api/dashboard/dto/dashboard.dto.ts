/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {
  IsEnum,
  IsDateString,
  IsOptional,
  IsNumberString,
  Allow,
  ValidateIf,
  IsString,
  IsNotEmpty,
  IsArray,
  IsMongoId,
  IsBoolean,
} from "class-validator";
import { DefaultPaginateParams } from "../../../core/common/dto/paginateDto";
import CommonDto from "../../../core/common/dto/common.dto";
import { Platform } from "../../../core/utils/enums";

// Global Search DTOs
export class GlobalSearchDto extends DefaultPaginateParams {
  @IsNotEmpty()
  @IsString()
  q: string;

  @Allow()
  @ValidateIf((object) => object["type"])
  @IsEnum([
    "users",
    "groups",
    "messages",
    "broadcasts",
    "stories",
    "notifications",
  ])
  type?:
    | "users"
    | "groups"
    | "messages"
    | "broadcasts"
    | "stories"
    | "notifications";
}

export class EnhancedGlobalSearchDto extends GlobalSearchDto {
  @Allow()
  @ValidateIf((object) => object["status"])
  @IsEnum(["active", "inactive", "all"])
  status?: "active" | "inactive" | "all";

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

// Stories Management DTOs
export class StoriesFilterDto extends DefaultPaginateParams {
  @Allow()
  @ValidateIf((object) => object["search"])
  @IsString()
  search?: string;

  @Allow()
  @ValidateIf((object) => object["storyType"])
  @IsEnum(["text", "image", "video"])
  storyType?: "text" | "image" | "video";

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;

  @Allow()
  @ValidateIf((object) => object["isExpired"])
  @IsString()
  isExpired?: string;
}

// Admin Notifications DTOs
export class AdminNotificationsFilterDto extends DefaultPaginateParams {
  @Allow()
  @ValidateIf((object) => object["search"])
  @IsString()
  search?: string;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

export class CreateAdminNotificationDto extends CommonDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  content: string;

  @Allow()
  @ValidateIf((object) => object["image"])
  @IsString()
  image?: string;

  @Allow()
  priority?: number;
}

// Versions Management DTOs
export class VersionsFilterDto extends DefaultPaginateParams {
  @Allow()
  @ValidateIf((object) => object["platform"])
  @IsEnum(Platform)
  platform?: Platform;

  @Allow()
  @ValidateIf((object) => object["critical"])
  @IsString()
  critical?: string;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

export class CreateVersionDto extends CommonDto {
  @IsNotEmpty()
  @IsString()
  version: string;

  @IsNotEmpty()
  @IsEnum(Platform)
  platform: Platform;

  @IsNotEmpty()
  @IsString()
  semVer: string;

  @Allow()
  @ValidateIf((object) => object["critical"])
  @IsBoolean()
  critical?: boolean;

  @Allow()
  @ValidateIf((object) => object["description"])
  @IsString()
  description?: string;

  @Allow()
  @ValidateIf((object) => object["downloadUrl"])
  @IsString()
  downloadUrl?: string;
}

export class UpdateVersionDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["version"])
  @IsString()
  version?: string;

  @Allow()
  @ValidateIf((object) => object["platform"])
  @IsEnum(Platform)
  platform?: Platform;

  @Allow()
  @ValidateIf((object) => object["semVer"])
  @IsString()
  semVer?: string;

  @Allow()
  @ValidateIf((object) => object["critical"])
  @IsBoolean()
  critical?: boolean;

  @Allow()
  @ValidateIf((object) => object["description"])
  @IsString()
  description?: string;

  @Allow()
  @ValidateIf((object) => object["downloadUrl"])
  @IsString()
  downloadUrl?: string;
}

// Calls Management DTOs
export class CallsFilterDto extends DefaultPaginateParams {
  @Allow()
  @ValidateIf((object) => object["callType"])
  @IsEnum(["audio", "video"])
  callType?: "audio" | "video";

  @Allow()
  @ValidateIf((object) => object["callStatus"])
  @IsEnum(["completed", "canceled", "timeout", "rejected"])
  callStatus?: "completed" | "canceled" | "timeout" | "rejected";

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

// Broadcasts Management DTOs
export class BroadcastsFilterDto extends DefaultPaginateParams {
  @Allow()
  @ValidateIf((object) => object["search"])
  @IsString()
  search?: string;

  @Allow()
  @ValidateIf((object) => object["minMembers"])
  @IsNumberString()
  minMembers?: string;

  @Allow()
  @ValidateIf((object) => object["maxMembers"])
  @IsNumberString()
  maxMembers?: string;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

// System Settings DTOs
export class UpdateSystemSettingDto extends CommonDto {
  @Allow()
  key?: string;

  @Allow()
  value?: any;

  @Allow()
  @ValidateIf((object) => object["description"])
  @IsString()
  description?: string;
}

// Bulk Operations DTOs
export class BulkDeleteDto extends CommonDto {
  @IsNotEmpty()
  @IsArray()
  @IsMongoId({ each: true })
  ids: string[];
}

// Activity Feed DTOs
export class ActivityFeedDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["limit"])
  @IsNumberString()
  limit?: string;

  getLimit(): number {
    const limit = parseInt(this.limit || "50", 10);
    return Math.min(limit, 100); // Max 100 items
  }
}

// Export Data DTOs
export class ExportDataDto extends CommonDto {
  @IsNotEmpty()
  @IsEnum(["users", "groups", "messages", "analytics", "reports"])
  type: "users" | "groups" | "messages" | "analytics" | "reports";

  @IsNotEmpty()
  @IsEnum(["csv", "json", "excel"])
  format: "csv" | "json" | "excel";

  @Allow()
  filters?: any;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;
}

// Recent Items DTOs
export class RecentItemsDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["limit"])
  @IsNumberString()
  limit?: string;

  getLimit(): number {
    const limit = parseInt(this.limit || "10", 10);
    return Math.min(limit, 50); // Max 50 items
  }
}
