import {
  IsEnum,
  IsDateString,
  IsOptional,
  IsNumberString,
  Allow,
  ValidateIf,
} from "class-validator";
import CommonDto from "../../../core/common/dto/common.dto";
import { Platform } from "../../../core/utils/enums";

export class AnalyticsDto extends CommonDto {
  @IsEnum(["daily", "weekly", "monthly", "yearly"])
  period: "daily" | "weekly" | "monthly" | "yearly";

  @IsDateString()
  startDate: string;

  @IsDateString()
  endDate: string;
}

export class UserGrowthAnalyticsDto extends AnalyticsDto {
  @Allow()
  @ValidateIf((object) => object["platform"])
  @IsEnum(Platform)
  platform?: Platform;

  @Allow()
  @ValidateIf((object) => object["countryId"])
  countryId?: string;
}

export class CallAnalyticsDto extends AnalyticsDto {
  @Allow()
  @ValidateIf((object) => object["callType"])
  @IsEnum(["audio", "video", "both"])
  callType?: "audio" | "video" | "both";

  @Allow()
  @ValidateIf((object) => object["callStatus"])
  @IsEnum(["completed", "canceled", "timeout", "rejected"])
  callStatus?: "completed" | "canceled" | "timeout" | "rejected";
}

export class PlatformAnalyticsDto extends AnalyticsDto {
  @Allow()
  @ValidateIf((object) => object["platform"])
  @IsEnum(Platform)
  platform?: Platform;
}

export class DashboardUsersFilterDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["page"])
  @IsNumberString()
  page?: string;

  @Allow()
  @ValidateIf((object) => object["limit"])
  @IsNumberString()
  limit?: string;

  @Allow()
  @ValidateIf((object) => object["search"])
  search?: string;

  @Allow()
  @ValidateIf((object) => object["country"])
  country?: string;

  @Allow()
  @ValidateIf((object) => object["platform"])
  @IsEnum(Platform)
  platform?: Platform;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;

  @Allow()
  @ValidateIf((object) => object["status"])
  @IsEnum(["accepted", "pending", "notAccepted"])
  status?: "accepted" | "pending" | "notAccepted";

  getPage(): number {
    return parseInt(this.page || "1", 10);
  }

  getLimit(): number {
    const limit = parseInt(this.limit || "20", 10);
    return Math.min(limit, 100); // Max 100 items per page
  }
}

export class DashboardGroupsFilterDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["page"])
  @IsNumberString()
  page?: string;

  @Allow()
  @ValidateIf((object) => object["limit"])
  @IsNumberString()
  limit?: string;

  @Allow()
  @ValidateIf((object) => object["search"])
  search?: string;

  @Allow()
  @ValidateIf((object) => object["minMembers"])
  @IsNumberString()
  minMembers?: string;

  @Allow()
  @ValidateIf((object) => object["maxMembers"])
  @IsNumberString()
  maxMembers?: string;

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;

  getPage(): number {
    return parseInt(this.page || "1", 10);
  }

  getLimit(): number {
    const limit = parseInt(this.limit || "20", 10);
    return Math.min(limit, 100);
  }
}

export class DashboardReportsFilterDto extends CommonDto {
  @Allow()
  @ValidateIf((object) => object["page"])
  @IsNumberString()
  page?: string;

  @Allow()
  @ValidateIf((object) => object["limit"])
  @IsNumberString()
  limit?: string;

  @Allow()
  @ValidateIf((object) => object["type"])
  type?: string;

  @Allow()
  @ValidateIf((object) => object["status"])
  @IsEnum(["pending", "resolved", "dismissed"])
  status?: "pending" | "resolved" | "dismissed";

  @Allow()
  @ValidateIf((object) => object["dateFrom"])
  @IsDateString()
  dateFrom?: string;

  @Allow()
  @ValidateIf((object) => object["dateTo"])
  @IsDateString()
  dateTo?: string;

  getPage(): number {
    return parseInt(this.page || "1", 10);
  }

  getLimit(): number {
    const limit = parseInt(this.limit || "20", 10);
    return Math.min(limit, 100);
  }
}
