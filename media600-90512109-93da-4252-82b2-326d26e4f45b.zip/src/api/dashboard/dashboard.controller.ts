import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Query,
  Param,
  Body,
  UseGuards,
  HttpCode,
  HttpStatus,
  Req,
} from "@nestjs/common";
import { DashboardService } from "./dashboard.service";
import { AnalyticsService } from "./services/analytics.service";
import { IsSuperAdminGuard } from "../../core/guards/is.admin.or.super.guard";
import {
  AnalyticsDto,
  UserGrowthAnalyticsDto,
  CallAnalyticsDto,
  PlatformAnalyticsDto,
  DashboardUsersFilterDto,
  DashboardGroupsFilterDto,
  DashboardReportsFilterDto,
} from "./dto/analytics.dto";
import {
  GlobalSearchDto,
  EnhancedGlobalSearchDto,
  StoriesFilterDto,
  AdminNotificationsFilterDto,
  CreateAdminNotificationDto,
  VersionsFilterDto,
  CreateVersionDto,
  UpdateVersionDto,
  CallsFilterDto,
  BroadcastsFilterDto,
  UpdateSystemSettingDto,
  BulkDeleteDto,
  ActivityFeedDto,
  ExportDataDto,
  RecentItemsDto,
} from "./dto/dashboard.dto";
import { MongoIdDto } from "../../core/common/dto/mongo.id.dto";
import { V1Controller } from "../../core/common/v1-controller.decorator";
import { resOK } from "../../core/utils/res.helpers";

@V1Controller("dashboard")
export class DashboardController {
  constructor(
    private readonly dashboardService: DashboardService,
    private readonly analyticsService: AnalyticsService
  ) {}

  /**
   * Get dashboard overview with key metrics
   * GET /api/v1/dashboard/overview
   */
  @Get("overview")
  async getDashboardOverview(@Req() req: any) {
    return resOK(await this.analyticsService.getDashboardOverview());
  }

  /**
   * Get user growth analytics
   * GET /api/v1/dashboard/analytics/user-growth
   */
  @Get("analytics/user-growth")
  async getUserGrowthAnalytics(
    @Query() dto: UserGrowthAnalyticsDto,
    @Req() req: any
  ) {
    dto.myUser = req.user;
    return resOK(await this.analyticsService.getUserGrowthAnalytics(dto));
  }

  /**
   * Get country-wise user distribution
   * GET /api/v1/dashboard/analytics/country-wise-users
   */
  @Get("analytics/country-wise-users")
  async getCountryWiseUsers(@Req() req: any) {
    return resOK(await this.analyticsService.getCountryWiseUsers());
  }

  /**
   * Get call analytics
   * GET /api/v1/dashboard/analytics/calls
   */
  @Get("analytics/calls")
  async getCallAnalytics(@Query() dto: CallAnalyticsDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.analyticsService.getCallAnalytics(dto));
  }

  /**
   * Get platform analytics
   * GET /api/v1/dashboard/analytics/platforms
   */
  @Get("analytics/platforms")
  async getPlatformAnalytics(
    @Query() dto: PlatformAnalyticsDto,
    @Req() req: any
  ) {
    dto.myUser = req.user;
    return resOK(await this.analyticsService.getPlatformAnalytics(dto));
  }

  /**
   * Get daily active users
   * GET /api/v1/dashboard/analytics/daily-active-users
   */
  @Get("analytics/daily-active-users")
  async getDailyActiveUsers(@Query() dto: AnalyticsDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.analyticsService.getDailyActiveUsers(dto));
  }

  /**
   * Get chat statistics
   * GET /api/v1/dashboard/analytics/chat-statistics
   */
  @Get("analytics/chat-statistics")
  async getChatStatistics(@Query() dto: AnalyticsDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.analyticsService.getChatStatistics(dto));
  }

  /**
   * Get paginated users with search and filters
   * GET /api/v1/dashboard/users
   */
  @Get("users")
  async getUsers(@Query() filterDto: DashboardUsersFilterDto, @Req() req: any) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getUsers(filterDto));
  }

  /**
   * Get user details by ID
   * GET /api/v1/dashboard/users/:id
   */
  @Get("users/:id")
  async getUserById(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.getUserById(dto.id));
  }

  /**
   * Get recent users
   * GET /api/v1/dashboard/users/recent
   */
  @Get("users/recent")
  async getRecentUsers(@Query() dto: RecentItemsDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.getRecentUsers(dto.getLimit()));
  }

  /**
   * Get paginated groups with search and filters
   * GET /api/v1/dashboard/groups
   */
  @Get("groups")
  async getGroups(
    @Query() filterDto: DashboardGroupsFilterDto,
    @Req() req: any
  ) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getGroups(filterDto));
  }

  /**
   * Get group details by ID
   * GET /api/v1/dashboard/groups/:id
   */
  @Get("groups/:id")
  async getGroupById(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.getGroupById(dto.id));
  }

  /**
   * Get paginated reports with filters
   * GET /api/v1/dashboard/reports
   */
  @Get("reports")
  async getReports(
    @Query() filterDto: DashboardReportsFilterDto,
    @Req() req: any
  ) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getReports(filterDto));
  }

  /**
   * Get system settings
   * GET /api/v1/dashboard/system/settings
   */
  @Get("system/settings")
  async getSystemSettings(@Req() req: any) {
    return resOK(await this.dashboardService.getSystemSettings());
  }

  /**
   * Update system setting
   * PUT /api/v1/dashboard/system/settings/:id
   */
  @Put("system/settings/:id")
  async updateSystemSetting(
    @Param() paramDto: MongoIdDto,
    @Body() updateDto: UpdateSystemSettingDto,
    @Req() req: any
  ) {
    paramDto.myUser = req.user;
    updateDto.myUser = req.user;
    return resOK(
      await this.dashboardService.updateSystemSetting(paramDto.id, updateDto)
    );
  }

  /**
   * Global search across users, groups, and messages
   * GET /api/v1/dashboard/search
   */
  @Get("search")
  async globalSearch(@Query() dto: GlobalSearchDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(
      await this.dashboardService.globalSearch(dto.q, dto.type as any)
    );
  }

  /**
   * Get detailed analytics for a specific time range
   * GET /api/v1/dashboard/analytics/detailed
   */
  @Get("analytics/detailed")
  async getDetailedAnalytics(@Query() dto: AnalyticsDto, @Req() req: any) {
    dto.myUser = req.user;
    const [userGrowth, callAnalytics, chatStats, platformActivity] =
      await Promise.all([
        this.analyticsService.getUserGrowthAnalytics(dto),
        this.analyticsService.getCallAnalytics(dto),
        this.analyticsService.getChatStatistics(dto),
        this.analyticsService.getPlatformAnalytics(dto),
      ]);

    return resOK({
      userGrowth,
      callAnalytics,
      chatStats,
      platformActivity,
    });
  }

  /**
   * Export dashboard data
   * POST /api/v1/dashboard/export
   */
  @Post("export")
  async exportData(@Body() exportDto: ExportDataDto, @Req() req: any) {
    exportDto.myUser = req.user;
    return resOK({
      message: "Export functionality - to be implemented",
      type: exportDto.type,
      format: exportDto.format,
      filters: exportDto.filters,
    });
  }

  /**
   * Get dashboard statistics summary
   * GET /api/v1/dashboard/stats
   */
  @Get("stats")
  async getDashboardStats(@Req() req: any) {
    const [overview, storyStats, versionStats, callStats, realTimeStats] =
      await Promise.all([
        this.analyticsService.getDashboardOverview(),
        this.dashboardService.getStoryStats(),
        this.dashboardService.getVersionStats(),
        this.dashboardService.getCallStats(),
        this.dashboardService.getRealTimeStats(),
      ]);

    return resOK({
      overview,
      stories: storyStats,
      versions: versionStats,
      calls: callStats,
      realTime: realTimeStats,
    });
  }

  /**
   * Get real-time activity feed
   * GET /api/v1/dashboard/activity-feed
   */
  @Get("activity-feed")
  async getActivityFeed(@Query() dto: ActivityFeedDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.getActivityFeed(dto.getLimit()));
  }

  /**
   * Get broadcasts
   * GET /api/v1/dashboard/broadcasts
   */
  @Get("broadcasts")
  async getBroadcasts(
    @Query() filterDto: BroadcastsFilterDto,
    @Req() req: any
  ) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getBroadcasts(filterDto));
  }

  /**
   * Get broadcast details by ID
   * GET /api/v1/dashboard/broadcasts/:id
   */
  @Get("broadcasts/:id")
  async getBroadcastById(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.getBroadcastById(dto.id));
  }

  /**
   * Delete broadcast
   * DELETE /api/v1/dashboard/broadcasts/:id
   */
  @Delete("broadcasts/:id")
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteBroadcast(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.deleteBroadcast(dto.id));
  }

  /**
   * Get stories
   * GET /api/v1/dashboard/stories
   */
  @Get("stories")
  async getStories(@Query() filterDto: StoriesFilterDto, @Req() req: any) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getStories(filterDto));
  }

  /**
   * Get story stats
   * GET /api/v1/dashboard/stories/stats
   */
  @Get("stories/stats")
  async getStoryStats(@Req() req: any) {
    return resOK(await this.dashboardService.getStoryStats());
  }

  /**
   * Delete story
   * DELETE /api/v1/dashboard/stories/:id
   */
  @Delete("stories/:id")
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteStory(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.deleteStory(dto.id));
  }

  /**
   * Get admin notifications
   * GET /api/v1/dashboard/admin-notifications
   */
  @Get("admin-notifications")
  async getAdminNotifications(
    @Query() filterDto: AdminNotificationsFilterDto,
    @Req() req: any
  ) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getAdminNotifications(filterDto));
  }

  /**
   * Create admin notification
   * POST /api/v1/dashboard/admin-notifications
   */
  @Post("admin-notifications")
  async createAdminNotification(
    @Body() createDto: CreateAdminNotificationDto,
    @Req() req: any
  ) {
    createDto.myUser = req.user;
    return resOK(
      await this.dashboardService.createAdminNotification(createDto)
    );
  }

  /**
   * Delete admin notification
   * DELETE /api/v1/dashboard/admin-notifications/:id
   */
  @Delete("admin-notifications/:id")
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteAdminNotification(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.deleteAdminNotification(dto.id));
  }

  /**
   * Get versions
   * GET /api/v1/dashboard/versions
   */
  @Get("versions")
  async getVersions(@Query() filterDto: VersionsFilterDto, @Req() req: any) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getVersions(filterDto));
  }

  /**
   * Get version stats
   * GET /api/v1/dashboard/versions/stats
   */
  @Get("versions/stats")
  async getVersionStats(@Req() req: any) {
    return resOK(await this.dashboardService.getVersionStats());
  }

  /**
   * Create version
   * POST /api/v1/dashboard/versions
   */
  @Post("versions")
  async createVersion(@Body() createDto: CreateVersionDto, @Req() req: any) {
    createDto.myUser = req.user;
    return resOK(await this.dashboardService.createVersion(createDto));
  }

  /**
   * Update version
   * PUT /api/v1/dashboard/versions/:id
   */
  @Put("versions/:id")
  async updateVersion(
    @Param() paramDto: MongoIdDto,
    @Body() updateDto: UpdateVersionDto,
    @Req() req: any
  ) {
    paramDto.myUser = req.user;
    updateDto.myUser = req.user;
    return resOK(
      await this.dashboardService.updateVersion(paramDto.id, updateDto)
    );
  }

  /**
   * Delete version
   * DELETE /api/v1/dashboard/versions/:id
   */
  @Delete("versions/:id")
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteVersion(@Param() dto: MongoIdDto, @Req() req: any) {
    dto.myUser = req.user;
    return resOK(await this.dashboardService.deleteVersion(dto.id));
  }

  /**
   * Get calls
   * GET /api/v1/dashboard/calls
   */
  @Get("calls")
  async getCalls(@Query() filterDto: CallsFilterDto, @Req() req: any) {
    filterDto.myUser = req.user;
    return resOK(await this.dashboardService.getCalls(filterDto));
  }

  /**
   * Get call stats
   * GET /api/v1/dashboard/calls/stats
   */
  @Get("calls/stats")
  async getCallStats(@Req() req: any) {
    return resOK(await this.dashboardService.getCallStats());
  }

  /**
   * Get real-time online users
   * GET /api/v1/dashboard/real-time/online-users
   */
  @Get("real-time/online-users")
  async getOnlineUsers(@Req() req: any) {
    return resOK(await this.dashboardService.getOnlineUsers());
  }

  /**
   * Get real-time stats
   * GET /api/v1/dashboard/real-time/stats
   */
  @Get("real-time/stats")
  async getRealTimeStats(@Req() req: any) {
    return resOK(await this.dashboardService.getRealTimeStats());
  }

  /**
   * Get enhanced global search
   * GET /api/v1/dashboard/search/enhanced
   */
  @Get("search/enhanced")
  async enhancedGlobalSearch(
    @Query() dto: EnhancedGlobalSearchDto,
    @Req() req: any
  ) {
    dto.myUser = req.user;
    return resOK(
      await this.dashboardService.enhancedGlobalSearch(dto.q, dto.type, dto)
    );
  }

  /**
   * Bulk delete stories
   * POST /api/v1/dashboard/bulk/delete-stories
   */
  @Post("bulk/delete-stories")
  async bulkDeleteStories(@Body() dto: BulkDeleteDto, @Req() req: any) {
    dto.myUser = req.user;
    const results = await Promise.allSettled(
      dto.ids.map((id) => this.dashboardService.deleteStory(id))
    );

    return resOK({
      successful: results.filter((r) => r.status === "fulfilled").length,
      failed: results.filter((r) => r.status === "rejected").length,
      total: dto.ids.length,
    });
  }

  /**
   * Bulk delete notifications
   * POST /api/v1/dashboard/bulk/delete-notifications
   */
  @Post("bulk/delete-notifications")
  async bulkDeleteNotifications(@Body() dto: BulkDeleteDto, @Req() req: any) {
    dto.myUser = req.user;
    const results = await Promise.allSettled(
      dto.ids.map((id) => this.dashboardService.deleteAdminNotification(id))
    );

    return resOK({
      successful: results.filter((r) => r.status === "fulfilled").length,
      failed: results.filter((r) => r.status === "rejected").length,
      total: dto.ids.length,
    });
  }

  /**
   * Get system health
   * GET /api/v1/dashboard/health
   */
  @Get("health")
  async getSystemHealth(@Req() req: any) {
    const overview = await this.analyticsService.getDashboardOverview();
    const realTimeStats = await this.dashboardService.getRealTimeStats();

    return resOK({
      status: "healthy",
      timestamp: new Date(),
      metrics: {
        totalUsers: overview.totalUsers,
        totalGroups: overview.totalGroups,
        totalBroadcasts: overview.totalBroadcasts,
        onlineUsers: realTimeStats.onlineCount,
        platformActivity: realTimeStats.platformStats,
      },
      uptime: process.uptime(),
      memory: process.memoryUsage(),
    });
  }
}
