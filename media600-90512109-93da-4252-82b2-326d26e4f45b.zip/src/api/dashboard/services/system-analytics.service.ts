import { Injectable } from "@nestjs/common";
import { UserDeviceService } from "../../user_modules/user_device/user_device.service";
import { AppConfigService } from "../../app_config/app_config.service";
import { PlatformAnalyticsDto } from "../dto/analytics.dto";
import { Platform } from "../../../core/utils/enums";
import {PipelineStage} from "mongoose";

@Injectable()
export class SystemAnalyticsService {
  constructor(
    private readonly userDeviceService: UserDeviceService,
    private readonly appConfigService: AppConfigService
  ) {}

  /**
   * Get platform activity distribution
   */
  async getPlatformActivity() {
    const pipeline: PipelineStage[] = [
      {
        $group: {
          _id: "$platform",
          activeUsers: { $addToSet: "$uId" },
          lastSeen: { $max: "$lastSeenAt" },
        },
      },
      {
        $project: {
          platform: "$_id",
          activeUsers: { $size: "$activeUsers" },
          lastSeen: 1,
          _id: 0,
        },
      },
      {
        $sort: { activeUsers: -1 },
      },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }

  /**
   * Get platform analytics with time series
   */
  async getPlatformAnalytics(dto: PlatformAnalyticsDto) {
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);

    let groupBy: any;
    let format: string;

    switch (dto.period) {
      case "daily":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          month: { $month: "$lastSeenAt" },
          day: { $dayOfMonth: "$lastSeenAt" },
        };
        format = "%Y-%m-%d";
        break;
      case "weekly":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          week: { $week: "$lastSeenAt" },
        };
        format = "%Y-W%U";
        break;
      case "monthly":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          month: { $month: "$lastSeenAt" },
        };
        format = "%Y-%m";
        break;
      case "yearly":
        groupBy = { year: { $year: "$lastSeenAt" } };
        format = "%Y";
        break;
    }

    let matchStage: any = {
      lastSeenAt: { $gte: startDate, $lte: endDate },
    };

    if (dto.platform) {
      matchStage.platform = dto.platform;
    }

    const pipeline: PipelineStage[] = [
      { $match: matchStage },
      {
        $group: {
          _id: {
            ...groupBy,
            platform: "$platform",
          },
          activeUsers: { $addToSet: "$uId" },
        },
      },
      {
        $group: {
          _id: {
            year: "$_id.year",
            month: "$_id.month",
            day: "$_id.day",
            week: "$_id.week",
          },
          platforms: {
            $push: {
              platform: "$_id.platform",
              activeUsers: { $size: "$activeUsers" },
            },
          },
          totalActiveUsers: { $sum: { $size: "$activeUsers" } },
          date: {
            $first: {
              $dateToString: {
                format,
                date: {
                  $dateFromParts: {
                    year: "$_id.year",
                    month: "$_id.month",
                    day: "$_id.day",
                  },
                },
              },
            },
          },
        },
      },
      { $sort: { _id: 1 } },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }

  /**
   * Get device information statistics
   */
  async getDeviceStatistics() {
    const pipeline: PipelineStage[] = [
      {
        $group: {
          _id: {
            platform: "$platform",
            deviceModel: "$deviceInfo.model",
            osVersion: "$deviceInfo.osVersion",
          },
          count: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: "$_id.platform",
          devices: {
            $push: {
              model: "$_id.deviceModel",
              osVersion: "$_id.osVersion",
              count: "$count",
            },
          },
          totalDevices: { $sum: "$count" },
        },
      },
      {
        $sort: { totalDevices: -1 },
      },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }

  /**
   * Get app configuration settings
   */
  async getAppConfigurations() {
    return this.appConfigService.findAll({}, "", { sort: { createdAt: -1 } });
  }

  /**
   * Get system health metrics
   */
  async getSystemHealthMetrics() {
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [activeLastHour, activeLastDay, activeLastWeek, totalDevices] =
      await Promise.all([
        this.userDeviceService.findCount({ lastSeenAt: { $gte: oneHourAgo } }),
        this.userDeviceService.findCount({ lastSeenAt: { $gte: oneDayAgo } }),
        this.userDeviceService.findCount({ lastSeenAt: { $gte: oneWeekAgo } }),
        this.userDeviceService.findCount({}),
      ]);

    return {
      activeUsersLastHour: activeLastHour,
      activeUsersLastDay: activeLastDay,
      activeUsersLastWeek: activeLastWeek,
      totalRegisteredDevices: totalDevices,
      healthScore: this.calculateHealthScore(activeLastDay, totalDevices),
    };
  }

  /**
   * Get user engagement metrics
   */
  async getUserEngagementMetrics() {
    const pipeline = [
      {
        $group: {
          _id: "$uId",
          sessionsCount: { $sum: 1 },
          firstSeen: { $min: "$createdAt" },
          lastSeen: { $max: "$lastSeenAt" },
          platforms: { $addToSet: "$platform" },
        },
      },
      {
        $project: {
          userId: "$_id",
          sessionsCount: 1,
          daysSinceFirstSeen: {
            $divide: [
              { $subtract: [new Date(), "$firstSeen"] },
              1000 * 60 * 60 * 24,
            ],
          },
          daysSinceLastSeen: {
            $divide: [
              { $subtract: [new Date(), "$lastSeen"] },
              1000 * 60 * 60 * 24,
            ],
          },
          platformCount: { $size: "$platforms" },
          platforms: 1,
        },
      },
      {
        $group: {
          _id: null,
          avgSessionsPerUser: { $avg: "$sessionsCount" },
          avgDaysSinceFirstSeen: { $avg: "$daysSinceFirstSeen" },
          avgDaysSinceLastSeen: { $avg: "$daysSinceLastSeen" },
          avgPlatformsPerUser: { $avg: "$platformCount" },
          totalUsers: { $sum: 1 },
        },
      },
    ];

    const result = await this.userDeviceService.aggregate(pipeline);
    return (
      result[0] || {
        avgSessionsPerUser: 0,
        avgDaysSinceFirstSeen: 0,
        avgDaysSinceLastSeen: 0,
        avgPlatformsPerUser: 0,
        totalUsers: 0,
      }
    );
  }

  /**
   * Calculate system health score based on activity
   */
  private calculateHealthScore(
    activeToday: number,
    totalUsers: number
  ): number {
    if (totalUsers === 0) return 0;

    const activityRate = activeToday / totalUsers;

    if (activityRate >= 0.8) return 100;
    if (activityRate >= 0.6) return 80;
    if (activityRate >= 0.4) return 60;
    if (activityRate >= 0.2) return 40;
    if (activityRate >= 0.1) return 20;
    return 0;
  }

  /**
   * Get platform version distribution
   */
  async getPlatformVersions() {
    const pipeline: PipelineStage[] = [
      {
        $group: {
          _id: {
            platform: "$platform",
            appVersion: "$appVersion",
          },
          userCount: { $addToSet: "$uId" },
        },
      },
      {
        $project: {
          platform: "$_id.platform",
          appVersion: "$_id.appVersion",
          userCount: { $size: "$userCount" },
          _id: 0,
        },
      },
      {
        $sort: { platform: 1, appVersion: -1 },
      },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }
}
