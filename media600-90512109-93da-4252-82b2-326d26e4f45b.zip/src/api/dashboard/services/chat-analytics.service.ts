import { Injectable } from "@nestjs/common";
import { MessageService } from "../../../chat/message/message.service";
import { GroupSettingsService } from "../../../chat/group_settings/group_settings.service";
import { BroadcastSettingsService } from "../../../chat/broadcast_settings/broadcast_settings.service";
import { GroupMemberService } from "../../../chat/group_member/group_member.service";
import { BroadcastMemberService } from "../../../chat/broadcast_member/broadcast_member.service";
import { RoomMemberService } from "../../../chat/room_member/room_member.service";
import { AnalyticsDto } from "../dto/analytics.dto";
import { RoomType, MessageType } from "../../../core/utils/enums";
import {PipelineStage} from "mongoose";

@Injectable()
export class ChatAnalyticsService {
  constructor(
    private readonly messageService: MessageService,
    private readonly groupSettingsService: GroupSettingsService,
    private readonly broadcastSettingsService: BroadcastSettingsService,
    private readonly groupMemberService: GroupMemberService,
    private readonly broadcastMemberService: BroadcastMemberService,
    private readonly roomMemberService: RoomMemberService
  ) {}

  /**
   * Get total number of groups
   */
  async getTotalGroups(): Promise<number> {
    return this.groupSettingsService.findCount({});
  }

  /**
   * Get total number of broadcasts
   */
  async getTotalBroadcasts(): Promise<number> {
    return this.broadcastSettingsService.findCount({});
  }

  /**
   * Get total messages count
   */
  async getTotalMessages(): Promise<number> {
    return this.messageService.findCount({});
  }

  /**
   * Get chat statistics with time series
   */
  async getChatStatistics(dto: AnalyticsDto) {
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);

    let groupBy: any;
    let format: string;

    switch (dto.period) {
      case "daily":
        groupBy = {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
          day: { $dayOfMonth: "$createdAt" },
        };
        format = "%Y-%m-%d";
        break;
      case "weekly":
        groupBy = {
          year: { $year: "$createdAt" },
          week: { $week: "$createdAt" },
        };
        format = "%Y-W%U";
        break;
      case "monthly":
        groupBy = {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
        };
        format = "%Y-%m";
        break;
      case "yearly":
        groupBy = { year: { $year: "$createdAt" } };
        format = "%Y";
        break;
    }

    const messagesPipeline: PipelineStage[] = [
      {
        $match: {
          createdAt: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: groupBy,
          messageCount: { $sum: 1 },
          date: { $first: { $dateToString: { format, date: "$createdAt" } } },
        },
      },
      { $sort: { _id: 1 } },
    ];

    const groupsPipeline: PipelineStage[] = [
      {
        $match: {
          createdAt: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: groupBy,
          groupCount: { $sum: 1 },
          date: { $first: { $dateToString: { format, date: "$createdAt" } } },
        },
      },
      { $sort: { _id: 1 } },
    ];

    const [messagesData, groupsData] = await Promise.all([
      this.messageService.aggregate(messagesPipeline),
      this.groupSettingsService.aggregate(groupsPipeline),
    ]);

    return {
      messages: messagesData,
      groups: groupsData,
    };
  }

  /**
   * Get message type distribution
   */
  async getMessageTypeDistribution() {
    const pipeline: PipelineStage[] = [
      {
        $group: {
          _id: "$mT",
          count: { $sum: 1 },
        },
      },
      {
        $sort: { count: -1 },
      },
    ];

    return this.messageService.aggregate(pipeline);
  }

  /**
   * Get most active groups by message count
   */
  async getMostActiveGroups(limit = 10) {
    const pipeline: PipelineStage[] = [
      {
        $match: {
          mT: { $ne: MessageType.Info }, // Exclude info messages
        },
      },
      {
        $lookup: {
          from: "room_members",
          localField: "rId",
          foreignField: "rId",
          as: "roomInfo",
        },
      },
      {
        $match: {
          "roomInfo.rT": RoomType.GroupChat,
        },
      },
      {
        $group: {
          _id: "$rId",
          messageCount: { $sum: 1 },
          lastActivity: { $max: "$createdAt" },
        },
      },
      {
        $lookup: {
          from: "group_settings",
          localField: "_id",
          foreignField: "_id",
          as: "groupInfo",
        },
      },
      {
        $unwind: "$groupInfo",
      },
      {
        $lookup: {
          from: "group_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $project: {
          roomId: "$_id",
          groupName: "$groupInfo.gName",
          groupImage: "$groupInfo.gImg",
          messageCount: 1,
          memberCount: { $size: "$members" },
          lastActivity: 1,
        },
      },
      {
        $sort: { messageCount: -1 },
      },
      {
        $limit: limit,
      },
    ];

    return this.messageService.aggregate(pipeline);
  }

  /**
   * Get group size distribution
   */
  async getGroupSizeDistribution() {
    const pipeline: PipelineStage[] = [
      {
        $lookup: {
          from: "group_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $project: {
          memberCount: { $size: "$members" },
        },
      },
      {
        $group: {
          _id: {
            $switch: {
              branches: [
                { case: { $lte: ["$memberCount", 5] }, then: "1-5 members" },
                { case: { $lte: ["$memberCount", 10] }, then: "6-10 members" },
                { case: { $lte: ["$memberCount", 25] }, then: "11-25 members" },
                { case: { $lte: ["$memberCount", 50] }, then: "26-50 members" },
                {
                  case: { $lte: ["$memberCount", 100] },
                  then: "51-100 members",
                },
              ],
              default: "100+ members",
            },
          },
          count: { $sum: 1 },
        },
      },
      {
        $sort: { _id: 1 },
      },
    ];

    return this.groupSettingsService.aggregate(pipeline);
  }

  /**
   * Get broadcast statistics
   */
  async getBroadcastStatistics() {
    const pipeline : PipelineStage[]= [
      {
        $lookup: {
          from: "broadcast_members",
          localField: "_id",
          foreignField: "bId",
          as: "members",
        },
      },
      {
        $project: {
          broadcastName: "$bName",
          broadcastImage: "$bImg",
          memberCount: { $size: "$members" },
          createdAt: 1,
        },
      },
      {
        $sort: { memberCount: -1 },
      },
      {
        $limit: 20,
      },
    ];

    return this.broadcastSettingsService.aggregate(pipeline);
  }

  /**
   * Get chat room statistics
   */
  async getChatRoomStatistics() {
    const pipeline = [
      {
        $group: {
          _id: "$rT",
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          roomType: {
            $switch: {
              branches: [
                {
                  case: { $eq: ["$_id", RoomType.Single] },
                  then: "Single Chat",
                },
                {
                  case: { $eq: ["$_id", RoomType.GroupChat] },
                  then: "Group Chat",
                },
                {
                  case: { $eq: ["$_id", RoomType.Broadcast] },
                  then: "Broadcast",
                },
                { case: { $eq: ["$_id", RoomType.Order] }, then: "Order Chat" },
              ],
              default: "Unknown",
            },
          },
          count: 1,
        },
      },
    ];

    return this.roomMemberService.aggregate(pipeline);
  }

  /**
   * Get recent chat activity
   */
  async getRecentChatActivity(limit = 50) {
    const pipeline: PipelineStage[] = [
      {
        $lookup: {
          from: "room_members",
          localField: "rId",
          foreignField: "rId",
          as: "roomInfo",
        },
      },
      {
        $unwind: "$roomInfo",
      },
      {
        $project: {
          roomId: "$rId",
          roomTitle: "$roomInfo.t",
          roomType: "$roomInfo.rT",
          senderName: "$sName",
          messageContent: {
            $cond: {
              if: { $eq: ["$mT", MessageType.Text] },
              then: "$c",
              else: { $concat: ["[", "$mT", "]"] },
            },
          },
          messageType: "$mT",
          createdAt: 1,
        },
      },
      {
        $sort: { createdAt: -1 },
      },
      {
        $limit: limit,
      },
    ];

    return this.messageService.aggregate(pipeline);
  }
}
