import { Injectable } from "@nestjs/common";
import { UserService } from "../../user_modules/user/user.service";
import { UserDeviceService } from "../../user_modules/user_device/user_device.service";
import { UserCountryService } from "../../user_modules/user_country/user_country.service";
import { CountriesService } from "../../countries/countries.service";
import { UserGrowthAnalyticsDto, AnalyticsDto } from "../dto/analytics.dto";
import { Platform } from "../../../core/utils/enums";
import {PipelineStage} from "mongoose";

@Injectable()
export class UserAnalyticsService {
  constructor(
    private readonly userService: UserService,
    private readonly userDeviceService: UserDeviceService,
    private readonly userCountryService: UserCountryService,
    private readonly countriesService: CountriesService
  ) {}

  /**
   * Get total number of users
   */
  async getTotalUsers(): Promise<number> {
    return this.userService.findCount({ deletedAt: { $exists: false } });
  }

  /**
   * Get active users today
   */
  async getActiveUsersToday(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return this.userDeviceService.findCount({
      lastSeenAt: { $gte: today },
    });
  }

  /**
   * Get new users this week
   */
  async getNewUsersThisWeek(): Promise<number> {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    return this.userService.findCount({
      createdAt: { $gte: weekAgo },
      deletedAt: { $exists: false },
    });
  }

  /**
   * Get user growth analytics with time series data
   */
  async getUserGrowth(dto: UserGrowthAnalyticsDto) {
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);

    let groupBy: any;
    let format: string;

    switch (dto.period) {
      case "daily":
        groupBy = {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
          day: { $dayOfMonth: "$createdAt" },
        };
        format = "%Y-%m-%d";
        break;
      case "weekly":
        groupBy = {
          year: { $year: "$createdAt" },
          week: { $week: "$createdAt" },
        };
        format = "%Y-W%U";
        break;
      case "monthly":
        groupBy = {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
        };
        format = "%Y-%m";
        break;
      case "yearly":
        groupBy = { year: { $year: "$createdAt" } };
        format = "%Y";
        break;
    }

    const matchStage: any = {
      createdAt: { $gte: startDate, $lte: endDate },
      deletedAt: { $exists: false },
    };

    if (dto.platform) {
      // We need to join with user devices to filter by platform
      const pipeline:PipelineStage[] = [
        { $match: matchStage },
        {
          $lookup: {
            from: "user_devices",
            localField: "_id",
            foreignField: "uId",
            as: "devices",
          },
        },
        {
          $match: {
            "devices.platform": dto.platform,
          },
        },
        {
          $group: {
            _id: groupBy,
            count: { $sum: 1 },
            date: { $first: { $dateToString: { format, date: "$createdAt" } } },
          },
        },
        { $sort: { _id: 1 } },
      ];

      return this.userService.aggregate(pipeline);
    }

    if (dto.countryId) {
      matchStage["countryId"] = dto.countryId;
    }

    const pipeline:PipelineStage[] = [
      { $match: matchStage },
      {
        $group: {
          _id: groupBy,
          count: { $sum: 1 },
          date: { $first: { $dateToString: { format, date: "$createdAt" } } },
        },
      },
      { $sort: { _id: 1 } },
    ];

    return this.userService.aggregate(pipeline);
  }

  /**
   * Get country-wise user distribution
   */
  async getCountryWiseUsers() {
    const pipeline:PipelineStage[] = [
      {
        $lookup: {
          from: "countries",
          localField: "countryId",
          foreignField: "_id",
          as: "country",
        },
      },
      {
        $unwind: {
          path: "$country",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $group: {
          _id: "$countryId",
          countryName: { $first: "$country.name" },
          countryCode: { $first: "$country.code" },
          countryEmoji: { $first: "$country.emoji" },
          userCount: { $sum: 1 },
        },
      },
      {
        $sort: { userCount: -1 },
      },
      {
        $limit: 20, // Top 20 countries
      },
    ];

    const results = await this.userService.aggregate(pipeline);
    const totalUsers = await this.getTotalUsers();

    return results.map((result) => ({
      countryId: result._id,
      countryName: result.countryName || "Unknown",
      countryCode: result.countryCode || "UN",
      countryEmoji: result.countryEmoji || "🌍",
      userCount: result.userCount,
      percentage:
        totalUsers > 0 ? ((result.userCount / totalUsers) * 100).toFixed(2) : 0,
    }));
  }

  /**
   * Get daily active users with time series
   */
  async getDailyActiveUsers(dto: AnalyticsDto) {
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);

    let groupBy: any;
    let format: string;

    switch (dto.period) {
      case "daily":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          month: { $month: "$lastSeenAt" },
          day: { $dayOfMonth: "$lastSeenAt" },
        };
        format = "%Y-%m-%d";
        break;
      case "weekly":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          week: { $week: "$lastSeenAt" },
        };
        format = "%Y-W%U";
        break;
      case "monthly":
        groupBy = {
          year: { $year: "$lastSeenAt" },
          month: { $month: "$lastSeenAt" },
        };
        format = "%Y-%m";
        break;
      case "yearly":
        groupBy = { year: { $year: "$lastSeenAt" } };
        format = "%Y";
        break;
    }

    const pipeline: PipelineStage[] = [
      {
        $match: {
          lastSeenAt: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: {
            ...groupBy,
            userId: "$uId",
          },
        },
      },
      {
        $group: {
          _id: {
            year: "$_id.year",
            month: "$_id.month",
            day: "$_id.day",
            week: "$_id.week",
          },
          activeUsers: { $sum: 1 },
          date: {
            $first: {
              $dateToString: {
                format,
                date: {
                  $dateFromParts: {
                    year: "$_id.year",
                    month: "$_id.month",
                    day: "$_id.day",
                  },
                },
              },
            },
          },
        },
      },
      { $sort: { _id: 1 } },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }

  /**
   * Get platform-wise user distribution
   */
  async getPlatformUsers() {
    const pipeline: PipelineStage[] = [
      {
        $group: {
          _id: "$platform",
          userCount: { $addToSet: "$uId" },
        },
      },
      {
        $project: {
          platform: "$_id",
          userCount: { $size: "$userCount" },
        },
      },
      {
        $sort: { userCount: -1 },
      },
    ];

    return this.userDeviceService.aggregate(pipeline);
  }

  /**
   * Get recent users with pagination
   */
  async getRecentUsers(limit = 10) {
    return this.userService.findAll(
      { deletedAt: { $exists: false } },
      "fullName email userImage createdAt lastSeenAt registerStatus",
      { sort: { createdAt: -1 }, limit }
    );
  }
}
