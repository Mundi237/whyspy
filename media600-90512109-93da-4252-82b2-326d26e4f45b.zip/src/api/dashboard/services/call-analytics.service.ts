import {Injectable} from "@nestjs/common";
import {CallHistoryService} from "../../../chat/call_modules/call_history/call_history.service";
import {CallAnalyticsDto} from "../dto/analytics.dto";
import {PipelineStage} from "mongoose";

@Injectable()
export class CallAnalyticsService {
    constructor(private readonly callHistoryService: CallHistoryService) {
    }

    /**
     * Get total number of calls
     */
    async getTotalCalls(): Promise<number> {
        return this.callHistoryService.findCount({});
    }

    /**
     * Get calls by type
     */
    async getCallsByType(type: "audio" | "video"): Promise<number> {
        return this.callHistoryService.findCount({
            isVideo: type === "video",
        });
    }

    /**
     * Get call analytics with time series
     */
    async getCallAnalytics(dto: CallAnalyticsDto) {
        const startDate = new Date(dto.startDate);
        const endDate = new Date(dto.endDate);

        let groupBy: any;
        let format: string;

        switch (dto.period) {
            case "daily":
                groupBy = {
                    year: {$year: "$createdAt"},
                    month: {$month: "$createdAt"},
                    day: {$dayOfMonth: "$createdAt"},
                };
                format = "%Y-%m-%d";
                break;
            case "weekly":
                groupBy = {
                    year: {$year: "$createdAt"},
                    week: {$week: "$createdAt"},
                };
                format = "%Y-W%U";
                break;
            case "monthly":
                groupBy = {
                    year: {$year: "$createdAt"},
                    month: {$month: "$createdAt"},
                };
                format = "%Y-%m";
                break;
            case "yearly":
                groupBy = {year: {$year: "$createdAt"}};
                format = "%Y";
                break;
        }

        let matchStage: any = {
            createdAt: {$gte: startDate, $lte: endDate},
        };

        if (dto.callType && dto.callType !== "both") {
            matchStage.isVideo = dto.callType === "video";
        }

        if (dto.callStatus) {
            matchStage.callStatus = dto.callStatus;
        }

        const pipeline: PipelineStage[] = [
            {$match: matchStage},
            {
                $group: {
                    _id: groupBy,
                    totalCalls: {$sum: 1},
                    audioCalls: {
                        $sum: {
                            $cond: [{$eq: ["$isVideo", false]}, 1, 0],
                        },
                    },
                    videoCalls: {
                        $sum: {
                            $cond: [{$eq: ["$isVideo", true]}, 1, 0],
                        },
                    },
                    avgDuration: {$avg: "$duration"},
                    date: {$first: {$dateToString: {format, date: "$createdAt"}}},
                },
            },
            {$sort: {_id: 1}},
        ];

        return this.callHistoryService.aggregate(pipeline);
    }

    /**
     * Get call status distribution
     */
    async getCallStatusDistribution() {
        const pipeline: PipelineStage[] = [
            {
                $group: {
                    _id: "$callStatus",
                    count: {$sum: 1},
                },
            },
            {
                $sort: {count: -1},
            },
        ];

        return this.callHistoryService.aggregate(pipeline);
    }

    /**
     * Get call duration statistics
     */
    async getCallDurationStats() {
        const pipeline : PipelineStage[]= [
            {
                $group: {
                    _id: null,
                    avgDuration: {$avg: "$duration"},
                    maxDuration: {$max: "$duration"},
                    minDuration: {$min: "$duration"},
                    totalDuration: {$sum: "$duration"},
                    totalCalls: {$sum: 1},
                },
            },
        ];

        return this.callHistoryService.aggregate(pipeline);
    }

    /**
     * Get busiest call hours
     */
    async getBusiestCallHours() {
        const pipeline: PipelineStage[] = [
            {
                $group: {
                    _id: {$hour: "$createdAt"},
                    callCount: {$sum: 1},
                },
            },
            {
                $sort: {callCount: -1},
            },
            {
                $project: {
                    hour: "$_id",
                    callCount: 1,
                    _id: 0,
                },
            },
        ];

        return this.callHistoryService.aggregate(pipeline);
    }

    /**
     * Get call failure rate
     */
    async getCallFailureRate() {
        const pipeline: PipelineStage[] = [
            {
                $group: {
                    _id: null,
                    totalCalls: {$sum: 1},
                    failedCalls: {
                        $sum: {
                            $cond: [
                                {
                                    $in: ["$callStatus", ["canceled", "timeout", "rejected"]],
                                },
                                1,
                                0,
                            ],
                        },
                    },
                    completedCalls: {
                        $sum: {
                            $cond: [{$eq: ["$callStatus", "completed"]}, 1, 0],
                        },
                    },
                },
            },
            {
                $project: {
                    totalCalls: 1,
                    failedCalls: 1,
                    completedCalls: 1,
                    failureRate: {
                        $multiply: [{$divide: ["$failedCalls", "$totalCalls"]}, 100],
                    },
                    successRate: {
                        $multiply: [{$divide: ["$completedCalls", "$totalCalls"]}, 100],
                    },
                },
            },
        ];

        const result = await this.callHistoryService.aggregate(pipeline);
        return (
            result[0] || {
                totalCalls: 0,
                failedCalls: 0,
                completedCalls: 0,
                failureRate: 0,
                successRate: 0,
            }
        );
    }

    /**
     * Get recent calls
     */
    async getRecentCalls(limit = 20) {
        return this.callHistoryService.findAll(
            {},
            "callerName receiverName isVideo duration callStatus createdAt",
            {sort: {createdAt: -1}, limit}
        );
    }

    /**
     * Get top callers
     */
    async getTopCallers(limit = 10) {
        const pipeline: PipelineStage[] = [
            {
                $group: {
                    _id: "$callerId",
                    callerName: {$first: "$callerName"},
                    totalCalls: {$sum: 1},
                    totalDuration: {$sum: "$duration"},
                    avgDuration: {$avg: "$duration"},
                },
            },
            {
                $sort: {totalCalls: -1},
            },
            {
                $limit: limit,
            },
        ];

        return this.callHistoryService.aggregate(pipeline);
    }
}
