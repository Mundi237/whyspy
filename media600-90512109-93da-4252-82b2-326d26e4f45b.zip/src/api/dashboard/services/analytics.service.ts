import { Injectable } from "@nestjs/common";
import { UserAnalyticsService } from "./user-analytics.service";
import { ChatAnalyticsService } from "./chat-analytics.service";
import { CallAnalyticsService } from "./call-analytics.service";
import { SystemAnalyticsService } from "./system-analytics.service";
import {
  AnalyticsDto,
  UserGrowthAnalyticsDto,
  CallAnalyticsDto,
  PlatformAnalyticsDto,
} from "../dto/analytics.dto";

@Injectable()
export class AnalyticsService {
  constructor(
    private readonly userAnalytics: UserAnalyticsService,
    private readonly chatAnalytics: ChatAnalyticsService,
    private readonly callAnalytics: CallAnalyticsService,
    private readonly systemAnalytics: SystemAnalyticsService
  ) {}

  /**
   * Get dashboard overview with key metrics
   */
  async getDashboardOverview() {
    const [
      totalUsers,
      totalGroups,
      totalBroadcasts,
      totalCalls,
      activeUsersToday,
      newUsersThisWeek,
      platformActivity,
    ] = await Promise.all([
      this.userAnalytics.getTotalUsers(),
      this.chatAnalytics.getTotalGroups(),
      this.chatAnalytics.getTotalBroadcasts(),
      this.callAnalytics.getTotalCalls(),
      this.userAnalytics.getActiveUsersToday(),
      this.userAnalytics.getNewUsersThisWeek(),
      this.systemAnalytics.getPlatformActivity(),
    ]);

    const audioCalls = await this.callAnalytics.getCallsByType("audio");
    const videoCalls = await this.callAnalytics.getCallsByType("video");

    return {
      totalUsers,
      totalGroups,
      totalBroadcasts,
      totalAudioCalls: audioCalls,
      totalVideoCalls: videoCalls,
      activeUsersToday,
      newUsersThisWeek,
      platformActivity,
    };
  }

  /**
   * Get user growth analytics
   */
  async getUserGrowthAnalytics(dto: UserGrowthAnalyticsDto) {
    return this.userAnalytics.getUserGrowth(dto);
  }

  /**
   * Get country-wise user distribution
   */
  async getCountryWiseUsers() {
    return this.userAnalytics.getCountryWiseUsers();
  }

  /**
   * Get call analytics
   */
  async getCallAnalytics(dto: CallAnalyticsDto) {
    return this.callAnalytics.getCallAnalytics(dto);
  }

  /**
   * Get platform activity analytics
   */
  async getPlatformAnalytics(dto: PlatformAnalyticsDto) {
    return this.systemAnalytics.getPlatformAnalytics(dto);
  }

  /**
   * Get daily active users
   */
  async getDailyActiveUsers(dto: AnalyticsDto) {
    return this.userAnalytics.getDailyActiveUsers(dto);
  }

  /**
   * Get chat statistics
   */
  async getChatStatistics(dto: AnalyticsDto) {
    return this.chatAnalytics.getChatStatistics(dto);
  }
}
