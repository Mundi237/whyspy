import { Injectable } from "@nestjs/common";
import { UserService } from "../user_modules/user/user.service";
import { GroupSettingsService } from "../../chat/group_settings/group_settings.service";
import { BroadcastSettingsService } from "../../chat/broadcast_settings/broadcast_settings.service";
import { MessageService } from "../../chat/message/message.service";
import { ReportSystemService } from "../report_system/report_system.service";
import { AppConfigService } from "../app_config/app_config.service";
import {
  DashboardUsersFilterDto,
  DashboardGroupsFilterDto,
  DashboardReportsFilterDto,
} from "./dto/analytics.dto";
import { newMongoObjId } from "../../core/utils/utils";

// Additional service imports for enhanced dashboard
import { StoryService } from "../stories/story/story.service";
import { StoryAttachmentService } from "../stories/story_attachment/story_attachment.service";
import { AdminNotificationService } from "../admin_notification/admin_notification.service";
import { VersionsService } from "../versions/versions.service";
import { CallHistoryService } from "../../chat/call_modules/call_history/call_history.service";
import { SocketIoService } from "../../chat/socket_io/socket_io.service";
import { ChannelService } from "../../chat/channel/services/channel.service";
import { UserDeviceService } from "../user_modules/user_device/user_device.service";
import { BroadcastMemberService } from "../../chat/broadcast_member/broadcast_member.service";
import { RoomMemberService } from "../../chat/room_member/room_member.service";
import {PipelineStage} from "mongoose";

@Injectable()
export class DashboardService {
  constructor(
    private readonly userService: UserService,
    private readonly groupSettingsService: GroupSettingsService,
    private readonly broadcastSettingsService: BroadcastSettingsService,
    private readonly messageService: MessageService,
    private readonly reportSystemService: ReportSystemService,
    private readonly appConfigService: AppConfigService,

    // Enhanced dashboard services
    private readonly storyService: StoryService,
    private readonly storyAttachmentService: StoryAttachmentService,
    private readonly adminNotificationService: AdminNotificationService,
    private readonly versionsService: VersionsService,
    private readonly callHistoryService: CallHistoryService,
    private readonly socketIoService: SocketIoService,
    private readonly channelService: ChannelService,
    private readonly userDeviceService: UserDeviceService,
    private readonly broadcastMemberService: BroadcastMemberService,
    private readonly roomMemberService: RoomMemberService
  ) {}

  /**
   * Get paginated users with filters
   */
  async getUsers(filterDto: DashboardUsersFilterDto) {
    const page = filterDto.getPage();
    const limit = filterDto.getLimit();
    const skip = (page - 1) * limit;

    // Build filter query
    const filter: any = { deletedAt: { $eq: null } };

    if (filterDto.search) {
      filter.$or = [
        { fullName: { $regex: filterDto.search, $options: "i" } },
        { email: { $regex: filterDto.search, $options: "i" } },
        { phoneNumber: { $regex: filterDto.search, $options: "i" } },
      ];
    }

    if (filterDto.country) {
      filter.countryId = filterDto.country;
    }

    if (filterDto.status) {
      filter.registerStatus = filterDto.status;
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    // If platform filter is provided, we need to join with user devices
    let pipeline: any[] = [];
    if (filterDto.platform) {
      pipeline = [
        { $match: filter },
        {
          $lookup: {
            from: "user_devices",
            localField: "_id",
            foreignField: "uId",
            as: "devices",
          },
        },
        {
          $match: {
            "devices.platform": filterDto.platform,
          },
        },
        {
          $lookup: {
            from: "countries",
            localField: "countryId",
            foreignField: "_id",
            as: "country",
          },
        },
        {
          $project: {
            fullName: 1,
            email: 1,
            phoneNumber: 1,
            userImage: 1,
            registerStatus: 1,
            createdAt: 1,
            lastSeenAt: 1,
            country: { $arrayElemAt: ["$country", 0] },
            deviceCount: { $size: "$devices" },
          },
        },
        { $sort: { createdAt: -1 as const } },
        { $skip: skip },
        { $limit: limit },
      ];

      const [users, totalCount] = await Promise.all([
        this.userService.aggregate(pipeline),
        this.userService.aggregate([
          { $match: filter },
          {
            $lookup: {
              from: "user_devices",
              localField: "_id",
              foreignField: "uId",
              as: "devices",
            },
          },
          {
            $match: {
              "devices.platform": filterDto.platform,
            },
          },
          { $count: "total" },
        ]),
      ]);

      return {
        users,
        totalCount: totalCount[0]?.total || 0,
        page,
        limit,
        totalPages: Math.ceil((totalCount[0]?.total || 0) / limit),
      };
    }

    // Regular query without platform filter - use aggregation for consistency
    const userPipeline: any[] = [
      { $match: filter },
      {
        $lookup: {
          from: "countries",
          localField: "countryId",
          foreignField: "_id",
          as: "country",
        },
      },
      {
        $project: {
          fullName: 1,
          email: 1,
          phoneNumber: 1,
          userImage: 1,
          registerStatus: 1,
          createdAt: 1,
          lastSeenAt: 1,
          country: { $arrayElemAt: ["$country", 0] },
        },
      },
      { $sort: { createdAt: -1 as const } },
      { $skip: skip },
      { $limit: limit },
    ];

    const [users, totalCount] = await Promise.all([
      this.userService.aggregate(userPipeline),
      this.userService.findCount(filter),
    ]);

    return {
      users,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Get paginated groups with filters
   */
  async getGroups(filterDto: DashboardGroupsFilterDto) {
    const page = filterDto.getPage();
    const limit = filterDto.getLimit();
    const skip = (page - 1) * limit;

    // Build base pipeline
    const pipeline: any[] = [
      {
        $lookup: {
          from: "group_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $addFields: {
          memberCount: { $size: "$members" },
        },
      },
    ];

    // Build filter stage
    const matchStage: any = {};

    if (filterDto.search) {
      matchStage.gName = { $regex: filterDto.search, $options: "i" };
    }

    if (filterDto.minMembers) {
      matchStage.memberCount = { $gte: parseInt(filterDto.minMembers) };
    }

    if (filterDto.maxMembers) {
      if (matchStage.memberCount) {
        matchStage.memberCount.$lte = parseInt(filterDto.maxMembers);
      } else {
        matchStage.memberCount = { $lte: parseInt(filterDto.maxMembers) };
      }
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      matchStage.createdAt = {};
      if (filterDto.dateFrom) {
        matchStage.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        matchStage.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    if (Object.keys(matchStage).length > 0) {
      pipeline.push({ $match: matchStage });
    }

    // Add pagination
    const dataPipeline = [
      ...pipeline,
      {
        $project: {
          gName: 1,
          gImg: 1,
          gDes: 1,
          createdAt: 1,
          memberCount: 1,
          isPrivate: 1,
        },
      },
      { $sort: { createdAt: -1 as const } },
      { $skip: skip },
      { $limit: limit },
    ];

    const countPipeline = [...pipeline, { $count: "total" }];

    const [groups, totalCount] = await Promise.all([
      this.groupSettingsService.aggregate(dataPipeline),
      this.groupSettingsService.aggregate(countPipeline),
    ]);

    return {
      groups,
      totalCount: totalCount[0]?.total || 0,
      page,
      limit,
      totalPages: Math.ceil((totalCount[0]?.total || 0) / limit),
    };
  }

  /**
   * Get paginated reports with filters
   */
  async getReports(filterDto: DashboardReportsFilterDto) {
    const page = filterDto.getPage();
    const limit = filterDto.getLimit();
    const skip = (page - 1) * limit;

    // Build filter query
    const filter: any = {};

    if (filterDto.type) {
      filter.type = { $regex: filterDto.type, $options: "i" };
    }

    if (filterDto.status) {
      filter.status = filterDto.status;
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    const [reports, totalCount] = await Promise.all([
      this.reportSystemService.findAll(filter, "", {
        sort: { createdAt: -1 },
        skip,
        limit,
      }),
      this.reportSystemService.findCount(filter),
    ]);

    return {
      reports,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Get recent users activity
   */
  async getRecentUsers(limit = 10) {
    return this.userService.findAll(
      { deletedAt: { $exists: false } },
      "fullName email userImage createdAt lastSeenAt registerStatus",
      { sort: { createdAt: -1 }, limit }
    );
  }

  /**
   * Get system settings from app config
   */
  async getSystemSettings() {
    return this.appConfigService.findAll({}, "", { sort: { createdAt: -1 } });
  }

  /**
   * Update system setting
   */
  async updateSystemSetting(settingId: string, updateData: any) {
    return this.appConfigService.findOneAndUpdate(
      { _id: settingId },
      updateData,
      { new: true }
    );
  }

  /**
   * Get user details by ID
   */
  async getUserById(userId: string) {
    const pipeline = [
      { $match: { _id: newMongoObjId(userId) } },
      {
        $lookup: {
          from: "user_devices",
          localField: "_id",
          foreignField: "uId",
          as: "devices",
        },
      },
      {
        $lookup: {
          from: "countries",
          localField: "countryId",
          foreignField: "_id",
          as: "country",
        },
      },
      {
        $lookup: {
          from: "room_members",
          localField: "_id",
          foreignField: "uId",
          as: "roomMemberships",
        },
      },
      {
        $project: {
          fullName: 1,
          email: 1,
          phoneNumber: 1,
          userImage: 1,
          registerStatus: 1,
          createdAt: 1,
          lastSeenAt: 1,
          country: { $arrayElemAt: ["$country", 0] },
          devices: 1,
          totalRooms: { $size: "$roomMemberships" },
        },
      },
    ];

    const result = await this.userService.aggregate(pipeline);
    return result[0] || null;
  }

  /**
   * Get group details by ID
   */
  async getGroupById(groupId: string) {
    const pipeline = [
      { $match: { _id: groupId } },
      {
        $lookup: {
          from: "group_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $lookup: {
          from: "messages",
          localField: "_id",
          foreignField: "rId",
          as: "messages",
        },
      },
      {
        $project: {
          gName: 1,
          gImg: 1,
          gDes: 1,
          createdAt: 1,
          isPrivate: 1,
          members: 1,
          memberCount: { $size: "$members" },
          messageCount: { $size: "$messages" },
          lastActivity: { $max: "$messages.createdAt" },
        },
      },
    ];

    const result = await this.groupSettingsService.aggregate(pipeline);
    return result[0] || null;
  }

  /**
   * Search across different entities
   */
  async globalSearch(query: string, type?: "users" | "groups" | "messages") {
    const results: any = {};

    if (!type || type === "users") {
      results.users = await this.userService.findAll(
        {
          $or: [
            { fullName: { $regex: query, $options: "i" } },
            { email: { $regex: query, $options: "i" } },
          ],
          deletedAt: { $eq: null },
        },
        "fullName email userImage",
        { limit: 10 }
      );
    }

    if (!type || type === "groups") {
      results.groups = await this.groupSettingsService.findAll(
        { gName: { $regex: query, $options: "i" } },
        "gName gImg",
        { limit: 10 }
      );
    }

    if (!type || type === "messages") {
      results.messages = await this.messageService.findAll(
        { c: { $regex: query, $options: "i" } },
        "c sName rId createdAt",
        { limit: 10, sort: { createdAt: -1 } }
      );
    }

    return results;
  }

  /**
   * STORIES MANAGEMENT
   */

  /**
   * Get paginated stories with filters
   */
  async getStories(filterDto: any) {
    const page = parseInt(filterDto.page || "1", 10);
    const limit = Math.min(parseInt(filterDto.limit || "20", 10), 100);
    const skip = (page - 1) * limit;

    const filter: any = {};

    if (filterDto.search) {
      filter.$or = [
        { content: { $regex: filterDto.search, $options: "i" } },
        { caption: { $regex: filterDto.search, $options: "i" } },
      ];
    }

    if (filterDto.storyType) {
      filter.storyType = filterDto.storyType;
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    if (filterDto.isExpired !== undefined) {
      if (filterDto.isExpired === "true") {
        filter.expireAt = { $lt: new Date() };
      } else {
        filter.expireAt = { $gte: new Date() };
      }
    }

    const pipeline = [
      { $match: filter },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $lookup: {
          from: "story_attachments",
          localField: "_id",
          foreignField: "storyId",
          as: "attachment",
        },
      },
      {
        $project: {
          _id: 1,
          userId: 1,
          storyType: 1,
          content: 1,
          caption: 1,
          att: 1,
          backgroundColor: 1,
          textColor: 1,
          fontType: 1,
          createdAt: 1,
          expireAt: 1,
          views: { $size: { $ifNull: ["$views", []] } },
          user: { $arrayElemAt: ["$user", 0] },
          attachment: { $arrayElemAt: ["$attachment", 0] },
        },
      },
      {
        $project: {
          _id: 1,
          userId: 1,
          storyType: 1,
          content: 1,
          caption: 1,
          att: 1,
          backgroundColor: 1,
          textColor: 1,
          fontType: 1,
          createdAt: 1,
          expireAt: 1,
          views: 1,
          isExpired: { $lt: ["$expireAt", new Date()] },
          "user.fullName": 1,
          "user.email": 1,
          "user.userImage": 1,
          "attachment.likes": { $size: { $ifNull: ["$attachment.likes", []] } },
          "attachment.shares": {
            $size: { $ifNull: ["$attachment.shares", []] },
          },
          "attachment.reply": { $size: { $ifNull: ["$attachment.reply", []] } },
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: skip },
      { $limit: limit },
    ];

    const [stories, totalCount] = await Promise.all([
      this.storyService.aggregate(pipeline),
      this.storyService.findCount(filter),
    ]);

    return {
      stories,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Delete story by ID
   */
  async deleteStory(storyId: string) {
    await this.storyService.findByIdAndDelete(storyId);
    await this.storyAttachmentService.deleteMany({ storyId });
    return { message: "Story deleted successfully" };
  }

  /**
   * Get story statistics
   */
  async getStoryStats() {
    const totalStories = await this.storyService.findCount({});
    const activeStories = await this.storyService.findCount({
      expireAt: { $gte: new Date() },
    });
    const expiredStories = await this.storyService.findCount({
      expireAt: { $lt: new Date() },
    });

    const typeStats = await this.storyService.aggregate([
      {
        $group: {
          _id: "$storyType",
          count: { $sum: 1 },
        },
      },
    ]);

    const viewsStats = await this.storyService.aggregate([
      {
        $project: {
          viewCount: { $size: { $ifNull: ["$views", []] } },
        },
      },
      {
        $group: {
          _id: null,
          totalViews: { $sum: "$viewCount" },
          avgViews: { $avg: "$viewCount" },
          maxViews: { $max: "$viewCount" },
        },
      },
    ]);

    return {
      totalStories,
      activeStories,
      expiredStories,
      typeStats,
      viewsStats: viewsStats[0] || { totalViews: 0, avgViews: 0, maxViews: 0 },
    };
  }

  /**
   * ADMIN NOTIFICATIONS MANAGEMENT
   */

  /**
   * Get admin notifications with pagination
   */
  async getAdminNotifications(filterDto: any) {
    const page = parseInt(filterDto.page || "1", 10);
    const limit = Math.min(parseInt(filterDto.limit || "20", 10), 100);
    const skip = (page - 1) * limit;

    const filter: any = {};

    if (filterDto.search) {
      filter.$or = [
        { title: { $regex: filterDto.search, $options: "i" } },
        { content: { $regex: filterDto.search, $options: "i" } },
      ];
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    const [notifications, totalCount] = await Promise.all([
      this.adminNotificationService.findAll(filter, null, {
        sort: { createdAt: -1 },
        skip,
        limit,
      }),
      this.adminNotificationService.findCount(filter),
    ]);

    return {
      notifications,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Create admin notification
   */
  async createAdminNotification(createDto: any) {
    return await this.adminNotificationService.create(createDto);
  }

  /**
   * Delete admin notification
   */
  async deleteAdminNotification(notificationId: string) {
    await this.adminNotificationService.findByIdAndDelete(notificationId);
    return { message: "Notification deleted successfully" };
  }

  /**
   * VERSIONS MANAGEMENT
   */

  /**
   * Get versions with pagination and filters
   */
  async getVersions(filterDto: any) {
    const page = parseInt(filterDto.page || "1", 10);
    const limit = Math.min(parseInt(filterDto.limit || "20", 10), 100);
    const skip = (page - 1) * limit;

    const filter: any = {};

    if (filterDto.platform) {
      filter.platform = filterDto.platform;
    }

    if (filterDto.critical !== undefined) {
      filter.critical = filterDto.critical === "true";
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    const [versions, totalCount] = await Promise.all([
      this.versionsService.findAll(filter, null, {
        sort: { createdAt: -1 },
        skip,
        limit,
      }),
      this.versionsService.findCount(filter),
    ]);

    return {
      versions,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Create new version
   */
  async createVersion(createDto: any) {
    return await this.versionsService.create(createDto);
  }

  /**
   * Update version
   */
  async updateVersion(versionId: string, updateDto: any) {
    return await this.versionsService.findByIdAndUpdate(versionId, updateDto);
  }

  /**
   * Delete version
   */
  async deleteVersion(versionId: string) {
    await this.versionsService.findByIdAndDelete(versionId);
    return { message: "Version deleted successfully" };
  }

  /**
   * Get version statistics
   */
  async getVersionStats() {
    const platformStats = await this.versionsService.aggregate([
      {
        $group: {
          _id: "$platform",
          count: { $sum: 1 },
          latestVersion: { $max: "$semVer" },
          criticalCount: {
            $sum: { $cond: [{ $eq: ["$critical", true] }, 1, 0] },
          },
        },
      },
    ]);

    const totalVersions = await this.versionsService.findCount({});
    const criticalVersions = await this.versionsService.findCount({
      critical: true,
    });

    return {
      totalVersions,
      criticalVersions,
      platformStats,
    };
  }

  /**
   * CALLS MANAGEMENT
   */

  /**
   * Get calls with pagination and filters
   */
  async getCalls(filterDto: any) {
    const page = parseInt(filterDto.page || "1", 10);
    const limit = Math.min(parseInt(filterDto.limit || "20", 10), 100);
    const skip = (page - 1) * limit;

    const filter: any = {};

    if (filterDto.callType) {
      filter.callType = filterDto.callType;
    }

    if (filterDto.callStatus) {
      filter.callStatus = filterDto.callStatus;
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    const pipeline: PipelineStage[] = [
      { $match: filter },
      {
        $lookup: {
          from: "users",
          localField: "callerId",
          foreignField: "_id",
          as: "caller",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "receiverId",
          foreignField: "_id",
          as: "receiver",
        },
      },
      {
        $project: {
          _id: 1,
          callType: 1,
          callStatus: 1,
          duration: 1,
          startTime: 1,
          endTime: 1,
          createdAt: 1,
          caller: {
            _id: 1,
            fullName: 1,
            email: 1,
            userImage: 1,
          },
          receiver: {
            _id: 1,
            fullName: 1,
            email: 1,
            userImage: 1,
          },
        },
      },
      {
        $addFields: {
          caller: { $arrayElemAt: ["$caller", 0] },
          receiver: { $arrayElemAt: ["$receiver", 0] },
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: skip },
      { $limit: limit },
    ];

    const [calls, totalCount] = await Promise.all([
      this.callHistoryService.aggregate(pipeline),
      this.callHistoryService.findCount(filter),
    ]);

    return {
      calls,
      totalCount,
      page,
      limit,
      totalPages: Math.ceil(totalCount / limit),
    };
  }

  /**
   * Get call statistics
   */
  async getCallStats() {
    const totalCalls = await this.callHistoryService.findCount({});

    const statusStats = await this.callHistoryService.aggregate([
      {
        $group: {
          _id: "$callStatus",
          count: { $sum: 1 },
        },
      },
    ]);

    const typeStats = await this.callHistoryService.aggregate([
      {
        $group: {
          _id: "$callType",
          count: { $sum: 1 },
          totalDuration: { $sum: "$duration" },
          avgDuration: { $avg: "$duration" },
        },
      },
    ]);

    const dailyStats = await this.callHistoryService.aggregate([
      {
        $group: {
          _id: {
            year: { $year: "$createdAt" },
            month: { $month: "$createdAt" },
            day: { $dayOfMonth: "$createdAt" },
          },
          count: { $sum: 1 },
          totalDuration: { $sum: "$duration" },
        },
      },
      { $sort: { "_id.year": -1, "_id.month": -1, "_id.day": -1 } },
      { $limit: 30 },
    ]);

    return {
      totalCalls,
      statusStats,
      typeStats,
      dailyStats,
    };
  }

  /**
   * REAL-TIME MONITORING
   */

  /**
   * Get online users
   */
  async getOnlineUsers() {
    const onlineCount = await this.socketIoService.getOnlineSocketsNumber();

    // Get recently active users as proxy for online users
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recentlyActiveUsers = await this.userService.findAll(
      {
        lastSeenAt: { $gte: oneHourAgo },
        deletedAt: { $eq: null },
      },
      "fullName email userImage lastSeenAt",
      { sort: { lastSeenAt: -1 }, limit: 100 }
    );

    return {
      onlineUsers: recentlyActiveUsers,
      count: onlineCount,
      estimatedOnlineUsers: recentlyActiveUsers.length,
    };
  }

  /**
   * Get real-time statistics
   */
  async getRealTimeStats() {
    const onlineCount = await this.socketIoService.getOnlineSocketsNumber();
    const totalUsers = await this.userService.findCount({});

    // Recent activity (last 24 hours)
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const recentMessages = await this.messageService.findCount({
      createdAt: { $gte: oneDayAgo },
    });

    const recentUsers = await this.userService.findCount({
      createdAt: { $gte: oneDayAgo },
    });

    const recentStories = await this.storyService.findCount({
      createdAt: { $gte: oneDayAgo },
    });

    // Platform distribution of online users
    const platformStats = await this.userDeviceService.aggregate([
      {
        $group: {
          _id: "$platform",
          count: { $sum: 1 },
        },
      },
    ]);

    return {
      onlineCount,
      totalUsers,
      onlinePercentage:
        totalUsers > 0 ? ((onlineCount / totalUsers) * 100).toFixed(2) : 0,
      recent24h: {
        messages: recentMessages,
        users: recentUsers,
        stories: recentStories,
      },
      platformStats,
    };
  }

  /**
   * Get activity feed
   */
  async getActivityFeed(limit = 50) {
    const activities = [];

    // Recent users
    const recentUsers = await this.userService.findAll(
      {},
      "fullName email createdAt",
      { sort: { createdAt: -1 }, limit: 10 }
    );

    recentUsers.forEach((user) => {
      activities.push({
        type: "user_registered",
        description: `${user.fullName} registered`,
        timestamp: user.createdAt,
        metadata: { userId: user._id, userEmail: user.email },
      });
    });

    // Recent stories
    const recentStories = await this.storyService.findAll(
      {},
      "userId content storyType createdAt",
      { sort: { createdAt: -1 }, limit: 10 }
    );

    for (const story of recentStories) {
      const user = await this.userService.findById(story.userId, "fullName");
      activities.push({
        type: "story_created",
        description: `${user?.fullName || "Unknown"} created a ${
          story.storyType
        } story`,
        timestamp: story.createdAt,
        metadata: { storyId: story._id, userId: story.userId },
      });
    }

    // Recent messages (sample)
    const recentMessages = await this.messageService.findAll(
      {},
      "sId mT createdAt",
      { sort: { createdAt: -1 }, limit: 10 }
    );

    for (const message of recentMessages) {
      const user = await this.userService.findById(message.sId, "fullName");
      activities.push({
        type: "message_sent",
        description: `${user?.fullName || "Unknown"} sent a ${
          message.mT
        } message`,
        timestamp: message.createdAt,
        metadata: { messageId: message._id, userId: message.sId },
      });
    }

    // Sort by timestamp and limit
    activities.sort(
      (a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    return activities.slice(0, limit);
  }

  /**
   * BROADCAST MANAGEMENT
   */

  /**
   * Get broadcasts with pagination and filters
   */
  async getBroadcasts(filterDto: any) {
    const page = parseInt(filterDto.page || "1", 10);
    const limit = Math.min(parseInt(filterDto.limit || "20", 10), 100);
    const skip = (page - 1) * limit;

    const filter: any = {};

    if (filterDto.search) {
      filter.gName = { $regex: filterDto.search, $options: "i" };
    }

    if (filterDto.minMembers) {
      filter.memberCount = { $gte: parseInt(filterDto.minMembers) };
    }

    if (filterDto.maxMembers) {
      if (filter.memberCount) {
        filter.memberCount.$lte = parseInt(filterDto.maxMembers);
      } else {
        filter.memberCount = { $lte: parseInt(filterDto.maxMembers) };
      }
    }

    if (filterDto.dateFrom || filterDto.dateTo) {
      filter.createdAt = {};
      if (filterDto.dateFrom) {
        filter.createdAt.$gte = new Date(filterDto.dateFrom);
      }
      if (filterDto.dateTo) {
        filter.createdAt.$lte = new Date(filterDto.dateTo);
      }
    }

    const pipeline:PipelineStage[] = [
      {
        $lookup: {
          from: "broadcast_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $addFields: {
          memberCount: { $size: "$members" },
        },
      },
      { $match: filter },
      {
        $lookup: {
          from: "users",
          localField: "gCreatorId",
          foreignField: "_id",
          as: "creator",
        },
      },
      {
        $project: {
          _id: 1,
          gName: 1,
          gImage: 1,
          gDescription: 1,
          createdAt: 1,
          memberCount: 1,
          creator: {
            _id: 1,
            fullName: 1,
            email: 1,
            userImage: 1,
          },
        },
      },
      {
        $addFields: {
          creator: { $arrayElemAt: ["$creator", 0] },
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: skip },
      { $limit: limit },
    ];

    const [broadcasts, totalCount] = await Promise.all([
      this.broadcastSettingsService.aggregate(pipeline),
      this.broadcastSettingsService.aggregate([
        {
          $lookup: {
            from: "broadcast_members",
            localField: "_id",
            foreignField: "rId",
            as: "members",
          },
        },
        {
          $addFields: {
            memberCount: { $size: "$members" },
          },
        },
        { $match: filter },
        { $count: "total" },
      ]),
    ]);

    return {
      broadcasts,
      totalCount: totalCount[0]?.total || 0,
      page,
      limit,
      totalPages: Math.ceil((totalCount[0]?.total || 0) / limit),
    };
  }

  /**
   * Get broadcast by ID with detailed info
   */
  async getBroadcastById(broadcastId: string) {
    const pipeline = [
      { $match: { _id: newMongoObjId(broadcastId) } },
      {
        $lookup: {
          from: "broadcast_members",
          localField: "_id",
          foreignField: "rId",
          as: "members",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "gCreatorId",
          foreignField: "_id",
          as: "creator",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "members.uId",
          foreignField: "_id",
          as: "memberDetails",
        },
      },
      {
        $project: {
          _id: 1,
          gName: 1,
          gImage: 1,
          gDescription: 1,
          createdAt: 1,
          memberCount: { $size: "$members" },
          creator: { $arrayElemAt: ["$creator", 0] },
          members: {
            $map: {
              input: "$memberDetails",
              as: "member",
              in: {
                _id: "$$member._id",
                fullName: "$$member.fullName",
                email: "$$member.email",
                userImage: "$$member.userImage",
                joinedAt: {
                  $arrayElemAt: [
                    {
                      $filter: {
                        input: "$members",
                        cond: { $eq: ["$$this.uId", "$$member._id"] },
                      },
                    },
                    0,
                  ],
                },
              },
            },
          },
        },
      },
    ];

    const result = await this.broadcastSettingsService.aggregate(pipeline);
    return result[0] || null;
  }

  /**
   * Delete broadcast
   */
  async deleteBroadcast(broadcastId: string) {
    await this.broadcastSettingsService.findByIdAndDelete(broadcastId);
    await this.broadcastMemberService.deleteMany({ rId: broadcastId });
    return { message: "Broadcast deleted successfully" };
  }

  /**
   * ENHANCED GLOBAL SEARCH
   */
  async enhancedGlobalSearch(query: string, type?: string, options: any = {}) {
    const page = parseInt(options.page || "1", 10);
    const limit = Math.min(parseInt(options.limit || "20", 10), 50);
    const skip = (page - 1) * limit;

    const results = {
      users: [],
      groups: [],
      broadcasts: [],
      stories: [],
      messages: [],
      calls: [],
      notifications: [],
    };

    if (!type || type === "users") {
      results.users = await this.userService.findAll(
        {
          $or: [
            { fullName: { $regex: query, $options: "i" } },
            { email: { $regex: query, $options: "i" } },
          ],
          deletedAt: { $eq: null },
        },
        "fullName email userImage registerStatus createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    if (!type || type === "groups") {
      results.groups = await this.groupSettingsService.findAll(
        {
          gName: { $regex: query, $options: "i" },
        },
        "gName gImage gDescription createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    if (!type || type === "broadcasts") {
      results.broadcasts = await this.broadcastSettingsService.findAll(
        {
          gName: { $regex: query, $options: "i" },
        },
        "gName gImage gDescription createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    if (!type || type === "stories") {
      results.stories = await this.storyService.findAll(
        {
          $or: [
            { content: { $regex: query, $options: "i" } },
            { caption: { $regex: query, $options: "i" } },
          ],
          expireAt: { $gte: new Date() },
        },
        "userId content caption storyType createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    if (!type || type === "messages") {
      results.messages = await this.messageService.findAll(
        {
          msgTxt: { $regex: query, $options: "i" },
        },
        "sId rId msgTxt mT createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    if (!type || type === "notifications") {
      results.notifications = await this.adminNotificationService.findAll(
        {
          $or: [
            { title: { $regex: query, $options: "i" } },
            { content: { $regex: query, $options: "i" } },
          ],
        },
        "title content createdAt",
        { sort: { createdAt: -1 }, skip, limit }
      );
    }

    return results;
  }
}
