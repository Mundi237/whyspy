/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {Injectable, NotFoundException} from "@nestjs/common";
import {IUserDevice} from "./entities/user_device.entity";
import {FilterQuery, Model, mongo, PipelineStage, QueryOptions, UpdateQuery} from "mongoose";
import {InjectModel} from "@nestjs/mongoose";
import {PushKeyAndProvider} from "../../../core/utils/interfaceces";
import {Platform, VPushProvider} from "../../../core/utils/enums";
import {BaseRepository} from "../../../core/common/base.service";
import {IUser} from "../user/entities/user.entity";

@Injectable()
export class UserDeviceService extends BaseRepository<IUserDevice> {
    constructor(
        @InjectModel("user_device")
        readonly model: Model<IUserDevice>
    ) {
        super(model);

    }





    async getUserPushTokens(peerId: string, platform?: Platform): Promise<PushKeyAndProvider> {
        let res = new PushKeyAndProvider([], [], []);
        let filter: object = {
            uId: peerId,
            pushKey: {$ne: null},
        }
        if (platform) {
            filter = {
                ...filter,
                platform: platform
            }
        }
        let devices = await this.findAll(filter, "pushKey pushProvider voipKey", {lean: true});
        for (let d of devices) {
            if (d.pushProvider == VPushProvider.fcm) {
                res.fcm.push(d.pushKey);
            }
            if (d.pushProvider == VPushProvider.onesignal) {
                res.oneSignal.push(d.pushKey);
            }
            if (d.voipKey) {
                res.voipKeys.push(d.voipKey);
            }
        }
        return res;
    }

    async getUsersPlatformAndPushKey(peerId: string) {
        return await this.findAll({
            uId: peerId,
            pushKey: {$ne: null}
        }, "pushKey platform", {lean: true});
    }


    async deleteFcmTokens(tokensToDelete: any[]) {
        await this.model.updateMany({
            pushKey: {$in: tokensToDelete}
        }, {
            pushKey: null
        });
    }



    async setLastSeenAt(_id: string) {
        await   this.model.findByIdAndUpdate(_id, {
            lastSeenAt: new Date()
        },);
    }
}
