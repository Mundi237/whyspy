import { Injectable, ExecutionContext, UnauthorizedException, ForbiddenException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Observable } from 'rxjs';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../../../core/decorators/public.decorator';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private reflector: Reflector) {
    super();
  }

  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    // Check if the route is marked as public
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    // If the route is public, skip authentication
    if (isPublic) {
      return true;
    }

    // Otherwise, proceed with authentication
    return super.canActivate(context);
  }

  /**
   * Handle exceptions thrown during authentication
   * @param err The error that was thrown
   * @param user The user object (if any)
   * @param info Additional information about the error
   */
  handleRequest(err: any, user: any, info: any): any {
    // If there was an error or no user was found, throw an appropriate exception
    if (err || !user) {
      if (err instanceof ForbiddenException) {
        throw err;
      }

      if (info && info.message === 'jwt expired') {
        throw new UnauthorizedException('Token has expired');
      }

      if (info && info.message === 'invalid signature') {
        throw new UnauthorizedException('Invalid token signature');
      }

      throw new UnauthorizedException('Unauthorized access');
    }

    return user;
  }
}