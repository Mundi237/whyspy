// import {Injectable, ExecutionContext, UnauthorizedException, ForbiddenException} from '@nestjs/common';
// import {AuthGuard} from '@nestjs/passport';
// import {Observable} from 'rxjs';
// import {WsException} from '@nestjs/websockets';
// import {Socket} from 'socket.io';
//
// /**
//  * WebSocket JWT Authentication Guard
//  *
//  * This guard is used to authenticate WebSocket connections using JWT tokens.
//  * It extends the AuthGuard from @nestjs/passport and adapts it for WebSocket context.
//  */
// @Injectable()
// export class WsJwtAuthGuard extends AuthGuard('ws-jwt') {
//     constructor() {
//         super();
//     }
//
//     /**
//      * Authenticate the WebSocket connection
//      * @param context The execution context
//      * @returns A boolean indicating if the connection is authenticated
//      */
//     async canActivate(context: ExecutionContext): Promise<boolean> {
//
//         // For WebSocket connections, we need to handle the context differently
//         if (context.getType() !== 'ws') {
//             const result = await super.canActivate(context);
//             return result as boolean;
//         }
//
//
//         const client: Socket = context.switchToWs().getClient();
//         const authToken = this.extractTokenFromSocket(client);
//
//         if (!authToken) {
//             throw new WsException('Authentication token not found');
//         }
//
//         // Create a new context with the token in the Authorization header
//         const newContext = this.createContextWithToken(context, authToken);
//
//         try {
//             // Use the parent class to validate the token
//             const result = await super.canActivate(newContext);
//
//             // If authentication was successful, get the user from the request
//             if (result) {
//                 const request = newContext.switchToHttp().getRequest();
//                 // Manually attach the user to the socket client
//                 client.user = request.user;
//             }
//
//             return result as boolean;
//         } catch (err) {
//             // Handle authentication errors
//             throw new WsException(err.message || 'Unauthorized');
//         }
//     }
//
//     /**
//      * Handle exceptions thrown during authentication
//      * @param err The error that was thrown
//      * @param user The user object (if any)
//      * @param info Additional information about the error
//      */
//     handleRequest(err: any, user: any, info: any, context?: ExecutionContext): any {
//         if (err || !user) {
//             if (err instanceof ForbiddenException) {
//                 throw new WsException(err.message);
//             }
//
//             if (info && info.message === 'jwt expired') {
//                 throw new WsException('Token has expired');
//             }
//
//             if (info && info.message === 'invalid signature') {
//                 throw new WsException('Invalid token signature');
//             }
//
//             throw new WsException('Unauthorized access');
//         }
//
//         // If we have a context and it's a WebSocket context, attach the user to the client
//         if (context && context.switchToWs) {
//             const client = context.switchToWs().getClient();
//             client.user = user;
//         }
//
//         return user;
//     }
//
//     /**
//      * Extract the JWT token from the socket connection
//      * @param client The socket client
//      * @returns The JWT token
//      */
//     private extractTokenFromSocket(client: Socket): string | null {
//         // Try to extract from headers
//         if (client.handshake.headers.authorization) {
//             const authHeader = client.handshake.headers.authorization;
//             if (authHeader.startsWith('Bearer ')) {
//                 return authHeader.substring(7);
//             }
//         }
//
//         // Try to extract from query parameters
//         if (client.handshake.query && client.handshake.query.auth) {
//             const authQuery = client.handshake.query.auth as string;
//             if (authQuery.startsWith('Bearer ')) {
//                 return authQuery.substring(7);
//             }
//         }
//
//         return null;
//     }
//
//     /**
//      * Create a new execution context with the token in the Authorization header
//      * @param context The original execution context
//      * @param token The JWT token
//      * @returns A new execution context with the token
//      */
//     private createContextWithToken(context: ExecutionContext, token: string): ExecutionContext {
//         // Create a new HTTP request with the token in the Authorization header
//         const request = {
//             headers: {
//                 authorization: `Bearer ${token}`,
//             },
//         };
//
//         // Create a new HTTP context with the request
//         return {
//             ...context,
//             switchToHttp: () => ({
//                 getRequest: () => request,
//             }),
//             getType: () => 'http',
//         } as ExecutionContext;
//     }
// }