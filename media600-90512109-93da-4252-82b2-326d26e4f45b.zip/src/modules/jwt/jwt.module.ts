import { Module } from "@nestjs/common";
import { PassportModule } from "@nestjs/passport";
import { JwtModule as NestJwtModule } from "@nestjs/jwt";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { MongooseModule } from "@nestjs/mongoose";
import { JwtStrategy } from "./strategies/jwt.strategy";
 import { JwtTokenService } from "./services/jwt.service";
import { JwtAuthGuard } from "./guards/jwt-auth.guard";


import { UserSchema } from "../../api/user_modules/user/entities/user.entity";
import { UserDeviceSchema } from "../../api/user_modules/user_device/entities/user_device.entity";

@Module({
  imports: [
    PassportModule.register({ defaultStrategy: "jwt" }),
    NestJwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => {
        return {
          secret: configService.getOrThrow("JWT_SECRET"),
          signOptions: {
            expiresIn: "999d",
            subject: "access",
            issuer: configService.getOrThrow("issuer"),
            algorithm: "HS256",
            audience: configService.getOrThrow("audience"),
          },
        };
      },
      inject: [ConfigService],
    }),
    MongooseModule.forFeature([
      { name: "user", schema: UserSchema },
      { name: "user_device", schema: UserDeviceSchema },
    ]),
  ],
  providers: [JwtStrategy,   JwtTokenService, JwtAuthGuard,  ],
  exports: [NestJwtModule, JwtStrategy,    JwtTokenService, JwtAuthGuard,  ],
})
export class JwtModule {}
