import {
  Injectable,
  UnauthorizedException,
  ForbiddenException,
} from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { ConfigService } from "@nestjs/config";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { JwtPayload } from "../interfaces/jwt-payload.interface";
import { IUser } from "../../../api/user_modules/user/entities/user.entity";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    private readonly configService: ConfigService,
    @InjectModel("user") private readonly userModel: Model<any>,
    @InjectModel("user_device") private readonly userDeviceModel: Model<any>
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.getOrThrow("JWT_SECRET"),
      issuer: configService.getOrThrow("issuer"),
      audience: configService.getOrThrow("audience"),
    });
  }

  /**
   * Validates the JWT payload and returns the user
   * @param payload The JWT payload
   * @returns The user object
   */
  async validate(payload: JwtPayload): Promise<IUser> {
    // Extract user ID and device ID from the payload
    const { id: userId, deviceId, roles } = payload;

    if (!userId || !deviceId) {
      throw new UnauthorizedException("Invalid token payload");
    }

    // Fetch user with more fields that might be needed throughout the application
    const user: any = await this.userModel
      .findById(
        userId,
        "fullName fullNameEn verifiedAt userImage roles banTo deletedAt registerStatus email uniqueCode"
      )
      .lean();

    if (!user) {
      throw new UnauthorizedException("User not found");
    }

    // Convert MongoDB ObjectId to string
    user._id = user._id.toString();
    user.id = user._id ;

    // Check if user is banned or deleted
    if (user.banTo) {
      throw new ForbiddenException("Your account is blocked");
    }

    if (user.deletedAt) {
      throw new ForbiddenException("Your account has been deleted");
    }

    // Fetch device information
    const device = await this.userDeviceModel
      .findById(deviceId, "_id platform")
      .lean();
    if (!device) {
      throw new UnauthorizedException("Device not found");
    }

    // Attach device and roles to user object
    user.currentDevice = device;

    return user;
  }
}
