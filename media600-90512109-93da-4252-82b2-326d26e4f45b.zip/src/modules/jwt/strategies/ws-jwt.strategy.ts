// import {Injectable} from '@nestjs/common';
// import {PassportStrategy} from '@nestjs/passport';
// import {ExtractJwt, Strategy} from 'passport-jwt';
// import {ConfigService} from '@nestjs/config';
// import {JwtPayload} from '../interfaces/jwt-payload.interface';
// import {WsException} from '@nestjs/websockets';
// import {JwtStrategy} from './jwt.strategy';
//
// /**
//  * WebSocket JWT Strategy
//  *
//  * This strategy is used to validate JWT tokens for WebSocket connections.
//  * It extends the PassportStrategy and uses the same configuration as the JwtStrategy.
//  */
// @Injectable()
// export class WsJwtStrategy extends PassportStrategy(Strategy, 'ws-jwt') {
//   private readonly jwtStrategy: JwtStrategy;
//
//   constructor(
//     private readonly configService: ConfigService,
//     jwtStrategy: JwtStrategy
//   ) {
//     super({
//       jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
//       ignoreExpiration: false,
//       secretOrKey:   configService.getOrThrow('JWT_SECRET'),
//       issuer: configService.getOrThrow('issuer'),
//       audience: configService.getOrThrow('audience'),
//     });
//     this.jwtStrategy = jwtStrategy;
//   }
//
//   /**
//    * Validate the JWT payload and return the user
//    * @param payload The JWT payload
//    * @returns The user object
//    */
//   async validate(payload: JwtPayload): Promise<any> {
//     try {
//       // Use the existing JwtStrategy to validate the payload
//       return  await this.jwtStrategy.validate(payload);
//     } catch (error) {
//       // Convert HTTP exceptions to WebSocket exceptions
//       throw new WsException(error.message || 'Unauthorized');
//     }
//   }
// }