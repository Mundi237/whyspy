import { Injectable, BadRequestException } from '@nestjs/common';
import { JwtService as NestJwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { JwtPayload } from '../interfaces/jwt-payload.interface';
import { JwtDecodeRes } from '../interfaces/jwt-decode-res.interface';

@Injectable()
export class JwtTokenService {
  constructor(
    private readonly jwtService: NestJwtService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Generate a JWT token with the given user ID, device ID, and roles
   * @param userId The user ID
   * @param deviceId The device ID
   * @param roles The user roles
   * @returns JWT token
   */
  signJwt(userId: string, deviceId: string, roles: string[] = []): string {
    const payload: JwtPayload = {
      id: userId,
      deviceId,
      roles,
    };
    return this.jwtService.sign(payload);
  }

  /**
   * Verify and decode a JWT token
   * @param token The JWT token to verify
   * @returns The decoded token payload
   * @throws BadRequestException if the token is invalid
   */
  verifyJwt(token: string): JwtDecodeRes {
    try {
      const payload = this.jwtService.verify(token);
      return {
        userId: payload.id,
        deviceId: payload.deviceId,
      };
    } catch (error) {
      throw new BadRequestException("JWT access token not valid " + token);
    }
  }
}