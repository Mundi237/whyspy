/**
 * Interface representing the decoded JWT token result
 */
export interface JwtDecodeRes {
  /**
   * User ID from the token
   */
  userId: string;
  
  /**
   * Device ID from the token
   */
  deviceId: string;
}