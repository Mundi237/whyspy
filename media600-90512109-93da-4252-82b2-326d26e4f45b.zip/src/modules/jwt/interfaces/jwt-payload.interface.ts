/**
 * Interface representing the payload of a JWT token
 */
export interface JwtPayload {
  /**
   * User ID
   */
  id: string;
  
  /**
   * Device ID
   */
  deviceId: string;
  
  /**
   * User roles
   */
  roles?: string[];
  
  /**
   * Token expiration timestamp
   */
  exp?: number;
  
  /**
   * Token issued at timestamp
   */
  iat?: number;
}