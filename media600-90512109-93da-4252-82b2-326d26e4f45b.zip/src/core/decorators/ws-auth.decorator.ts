// import { applyDecorators, UseGuards } from '@nestjs/common';
//
// /**
//  * WebSocket Auth decorator for protecting WebSocket routes with JWT authentication
//  * @returns Decorator
//  */
// export function WsAuth() {
//   return applyDecorators(
//     UseGuards(WsJwtAuthGuard)
//   );
// }