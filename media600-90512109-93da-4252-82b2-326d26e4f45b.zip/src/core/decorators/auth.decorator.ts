import { applyDecorators, SetMetadata, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../../modules/jwt/guards/jwt-auth.guard';
import { ApiBearerAuth, ApiUnauthorizedResponse, ApiForbiddenResponse } from '@nestjs/swagger';
import { RolesGuard } from '../guards/roles.guard';
import { Roles } from './roles.decorator';

/**
 * Auth decorator for protecting routes with JWT authentication and optional role-based access control
 * @param roles Optional roles that are allowed to access the route
 * @returns Decorator
 */
export function Auth(...roles: string[]) {
  const decorators = [
    UseGuards(JwtAuthGuard),
    ApiBearerAuth(),
    ApiUnauthorizedResponse({ description: 'Unauthorized' }),
  ];

  return applyDecorators(...decorators);
}
