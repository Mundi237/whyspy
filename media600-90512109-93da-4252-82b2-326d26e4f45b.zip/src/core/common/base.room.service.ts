/**
 * Copyright 2023, the hatemragab project author.
 * All rights reserved. Use of this source code is governed by a
 * MIT license that can be found in the LICENSE file.
 */

import {BaseRepository} from "./base.service";
import {
    FilterQuery,
    QueryOptions,
    UpdateQuery,
} from "mongoose";

export abstract class BaseRoomService<RM> extends BaseRepository<RM> {
    abstract findByRoomId(roomId: string, select?: string | null, options?: QueryOptions<RM> | null): Promise<any>

    abstract findByRoomIdAndUpdate(roomId: string, update: Partial<RM>, session?: undefined): Promise<any>

    abstract findByRoomIdAndDelete(roomId: string, filter: FilterQuery<RM>, session?: undefined): Promise<any>
}