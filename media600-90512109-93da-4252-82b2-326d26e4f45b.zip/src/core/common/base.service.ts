import {
    FilterQuery,
    UpdateQuery,
    QueryOptions,
    UpdateWithAggregationPipeline,
    UpdateWriteOpResult,
    DeleteResult,
    ClientSession,
    PipelineStage,
    PopulateOptions,
    ProjectionType,
    SortOrder,
    AnyBulkWriteOperation,
    Model,
    mongo,
} from "mongoose";

export interface PaginationOptions {
    page?: number;
    limit?: number;
    sort?: Record<string, SortOrder>;
}

export interface PaginatedResult<T> {
    data: T[];
    totalCount: number;
    totalPages: number;
    currentPage: number;
    hasNext: boolean;
    hasPrev: boolean;
}

export class BaseRepository<TDocument> {
    protected readonly model: Model<TDocument>;

    constructor(model: Model<TDocument>) {
        this.model = model;
    }

    async create(
        data: Partial<TDocument>,
        session?: ClientSession
    ): Promise<TDocument> {
        const result = await this.model.create([data], {session});
        if (!result || result.length === 0) {
            throw new Error('Failed to create document');
        }
        return this.findById(result[0]._id.toString(), null, {lean:true}, session);
    }

    async createMany(
        data: Partial<TDocument>[],
        session?: ClientSession
    ): Promise<TDocument[]> {
        return this.model.create(data, {session});
    }

    async findById(
        id: string,
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument | null> {
        return this.model.findById(id, projection, {...options, session}).exec();
    }

    async findOne(
        filter: FilterQuery<TDocument>,
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument | null> {
        return this.model
            .findOne(filter, projection, {...options, session})
            .exec();
    }

    async findByIdOrThrow(
        id: string,
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument> {
        const doc = await this.findById(id, projection, options, session);
        if (!doc) {
            throw new Error(`${this.model.modelName} with id '${id}' not found.`);
        }
        return doc;
    }
    async findCount(
        filter: FilterQuery<TDocument> = {},
        session?: ClientSession
    ): Promise<number> {
        return this.model.countDocuments(filter, {session}).exec();
    }

    async findOneOrThrow(
        filter: FilterQuery<TDocument>,
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument> {
        const doc = await this.findOne(filter, projection, options, session);
        if (!doc) {
            throw new Error(
                `${this.model.modelName} not found for the given filter.`
            );
        }
        return doc;
    }

    async findAll(
        filter: FilterQuery<TDocument> = {},
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument[]> {
        return this.model.find(filter, projection, {...options, session}).exec();
    }

    async findWithPagination(
        filter: FilterQuery<TDocument> = {},
        paginationOptions: PaginationOptions = {},
        projection?: ProjectionType<TDocument> | null,
        session?: ClientSession
    ): Promise<PaginatedResult<TDocument>> {
        const {page = 1, limit = 10, sort} = paginationOptions;
        const skip = (page - 1) * limit;
        if (page < 1) throw new Error('Page must be greater than 0');
        if (limit < 1 || limit > 100) throw new Error('Limit must be between 1 and 100');
        const [data, totalCount] = await Promise.all([
            this.model
                .find(filter, projection, {session})
                .sort(sort)
                .skip(skip)
                .limit(limit)
                .exec(),
            this.model.countDocuments(filter, {session}).exec(),
        ]);

        const totalPages = Math.ceil(totalCount / limit);

        return {
            data,
            totalCount,
            totalPages,
            currentPage: page,
            hasNext: page < totalPages,
            hasPrev: page > 1,
        };
    }

    async findWithPopulate(
        filter: FilterQuery<TDocument>,
        populate: PopulateOptions | PopulateOptions[],
        projection?: ProjectionType<TDocument> | null,
        options?: QueryOptions<TDocument>,
        session?: ClientSession
    ): Promise<TDocument[]> {
        return this.model
            .find(filter, projection, {...options, session})
            .populate(populate)
            .exec();
    }

    async findByIdAndUpdate(
        id: string,
        update: UpdateQuery<TDocument>,
        options: QueryOptions<TDocument> = {},
        session?: ClientSession
    ): Promise<TDocument | null> {
        return this.model
            .findByIdAndUpdate(id, update, {...options, new: true, session})
            .exec();
    }

    async findOneAndUpdate(
        filter: FilterQuery<TDocument>,
        update: UpdateQuery<TDocument>,
        options: QueryOptions<TDocument> = {},
        session?: ClientSession
    ): Promise<TDocument | null> {
        return this.model
            .findOneAndUpdate(filter, update, {...options, new: true, session})
            .exec();
    }

    async updateMany(
        filter: FilterQuery<TDocument>,
        update: UpdateQuery<TDocument> | UpdateWithAggregationPipeline,
        session?: ClientSession
    ): Promise<UpdateWriteOpResult> {
        return this.model.updateMany(filter, update, {session}).exec();
    }

    async findByIdAndDelete(
        id: string,
        session?: ClientSession
    ): Promise<TDocument | null> {
        return this.model.findByIdAndDelete(id, {session}).exec();
    }

    async deleteMany(
        filter: FilterQuery<TDocument>,
        session?: ClientSession
    ): Promise<DeleteResult> {
        return this.model.deleteMany(filter, {session}).exec();
    }

    async countDocuments(
        filter: FilterQuery<TDocument> = {},
        session?: ClientSession
    ): Promise<number> {
        return this.model.countDocuments(filter, {session}).exec();
    }

    async exists(filter: FilterQuery<TDocument>, session?: ClientSession): Promise<boolean> {
        try {
            const count = await this.model.countDocuments(filter, {session, limit: 1}).exec();
            return count > 0;
        } catch (error) {
            throw new Error(`Failed to check document existence: ${error.message}`);
        }
    }

    async aggregate<T = any>(
        pipeline: PipelineStage[],
        session?: ClientSession
    ): Promise<T[]> {
        return this.model.aggregate<T>(pipeline, {session}).exec();
    }

    async bulkWrite(
        operations: AnyBulkWriteOperation<any>[],
        session?: ClientSession
    ): Promise<mongo.BulkWriteResult> {
        const options = session ? {session} : {};
        return this.model.bulkWrite(operations, options);
    }
}