import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import xss from "xss";


@Injectable()
export class XssMiddleware implements NestMiddleware {
    use(req: Request, res: Response, next: NextFunction) {
        // Create a new sanitized query object
        if (req.query) {
            const sanitizedQuery = this.sanitizeObject(req.query);
            // Merge sanitized values back into query params individually
            Object.keys(sanitizedQuery).forEach(key => {
                req.query[key] = sanitizedQuery[key];
            });
        }

        // Handle body sanitization
        if (req.body) {
            req.body = this.sanitizeObject(req.body);
        }
        next();
    }

    private sanitizeObject(obj: any): any {
        if (Array.isArray(obj)) {
            return obj.map(item => this.sanitizeObject(item));
        }
        if (typeof obj === 'object' && obj !== null) {
            const sanitized = {};
            for (const key in obj) {
                if (Object.prototype.hasOwnProperty.call(obj, key)) {
                    sanitized[key] = this.sanitizeObject(obj[key]);
                }
            }
            return sanitized;
        }
        if (typeof obj === 'string') {
            return xss(obj);
        }
        return obj;
    }
}