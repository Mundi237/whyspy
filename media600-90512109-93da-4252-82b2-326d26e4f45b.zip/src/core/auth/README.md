# Improved Bearer Authentication System

This directory contains the improved Bearer Authentication system for the Super Up API, following NestJS best practices.

## Overview

The improved authentication system uses Passport.js with JWT strategy, which is the recommended approach by NestJS for implementing Bearer token authentication.

## Key Components

1. **JWT Strategy** (`/src/api/auth/strategies/jwt.strategy.ts`): Implements the Passport JWT strategy for validating JWT tokens.

2. **JWT Auth Guard** (`/src/core/guards/jwt-auth.guard.ts`): A guard that uses the JWT strategy to protect routes.

3. **Auth Decorator** (`/src/core/decorators/auth.decorator.ts`): A custom decorator that combines UseGuards, ApiBearerAuth, and ApiUnauthorizedResponse for easier use in controllers.

4. **Public Decorator** (`/src/core/decorators/public.decorator.ts`): A decorator to mark routes that don't require authentication.

## Required Dependencies

To use this improved authentication system, you need to install the following packages:

```bash
npm install --save @nestjs/passport passport passport-jwt
npm install --save-dev @types/passport-jwt
```

## Usage

### Protecting Controllers

To protect an entire controller:

```typescript
@Controller('example')
@Auth()
export class ExampleController {
  // All routes in this controller require authentication
}
```

### Public Routes

To make a specific route public:

```typescript
@Controller('example')
@Auth()
export class ExampleController {
  @Public()
  @Get('public-route')
  publicRoute() {
    // This route is public and doesn't require authentication
  }
}
```

### Accessing the Current User

The authenticated user is automatically set in the request object and can be accessed in any controller method:

```typescript
@Controller('example')
@Auth()
export class ExampleController {
  @Get('profile')
  getProfile(@Req() req) {
    const user = req.user;
    // Use the user object
    return user;
  }
}
```

## Implementation Details

The system works by:

1. Extracting the JWT token from the Authorization header
2. Validating the token using the JWT strategy
3. Fetching the user from the database with all necessary fields
4. Checking if the user is banned or deleted
5. Attaching the user to the request object
6. Allowing or denying access based on the validation result

The Public decorator can be used to mark routes that should be accessible without authentication.

## User Validation

The system automatically checks if a user is banned or deleted:

1. If a user is banned (`user.banTo` exists), they will receive a 403 Forbidden response
2. If a user's account is deleted (`user.deletedAt` exists), they will receive a 403 Forbidden response

This prevents banned or deleted users from accessing protected resources.

## Test Endpoint

A test endpoint has been added to verify the authentication system:

```
GET /api/v1/profile/me
```

This endpoint returns the current authenticated user's information, which can be used to verify that the authentication system is working correctly.
