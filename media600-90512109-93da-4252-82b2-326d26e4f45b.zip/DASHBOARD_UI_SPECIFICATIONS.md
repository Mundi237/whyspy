# Super Up Chat Platform - Dashboard UI Specifications

## Overview

This document outlines the comprehensive UI requirements for the Super Up Chat Platform dashboard, which provides real-time analytics, user management, and system monitoring capabilities. The dashboard should be built using Next.js with modern UI components and responsive design.

## Technology Stack Requirements

- **Framework**: Next.js 15 with App Router
- **Styling**: Tailwind CSS + Shadcn/ui components
- **Charts**: Recharts or Chart.js for data visualization
- **State Management**: Zustand or React Context
- **Data Fetching**: React Query (TanStack Query)
- **Icons**: Lucide React or Heroicons
- **Tables**: TanStack Table for data grids

## Dashboard Layout Structure

### Main Layout

```
┌─────────────────────────────────────────────────────────────┐
│ Header (Logo, Search, Notifications, Profile)              │
├─────────────┬───────────────────────────────────────────────┤
│ Sidebar     │ Main Content Area                             │
│ Navigation  │ (Dynamic based on selected page)             │
│             │                                               │
│ - Overview  │                                               │
│ - Analytics │                                               │
│ - Users     │                                               │
│ - Groups    │                                               │
│ - Stories   │                                               │
│ - Calls     │                                               │
│ - Reports   │                                               │
│ - System    │                                               │
└─────────────┴───────────────────────────────────────────────┘
```

---

## 📊 ANALYTICS SECTION

### 1. Dashboard Overview (`GET /dashboard/overview`)

**Page**: `/dashboard` (Homepage)

**Design Requirements**:

- **Layout**: 4-column grid of key metric cards
- **Cards Design**:
  - Material design cards with subtle shadows
  - Each card shows: Icon, Title, Main Number, Percentage change, Mini trend line
  - Color coding: Green for positive trends, Red for negative
- **Metrics to Display**:
  - Total Users (with growth %)
  - Total Groups (with activity indicator)
  - Total Broadcasts (with member count)
  - Total Calls (with audio/video breakdown)
  - Active Users Today (with online percentage)
  - New Users This Week (with comparison to last week)

**UI Components**:

```jsx
<StatsCard
  title="Total Users"
  value="12,345"
  change="+12.5%"
  trend="up"
  icon={UsersIcon}
  color="blue"
/>
```

### 2. User Growth Analytics (`GET /dashboard/analytics/user-growth`)

**Page**: `/dashboard/analytics/user-growth`

**Design Requirements**:

- **Header**: Title with date range picker and filter options
- **Filters**: Period (daily/weekly/monthly/yearly), Platform dropdown, Country selector
- **Main Chart**: Line chart showing user registration over time
- **Secondary Charts**:
  - Platform breakdown (pie chart)
  - Country distribution (horizontal bar chart)
- **Data Table**: Detailed breakdown below charts

**Chart Specifications**:

- Line chart with smooth curves
- Multiple data series for platform comparison
- Tooltip showing exact values and percentages
- Responsive design for mobile viewing

### 3. Country-wise Users (`GET /dashboard/analytics/country-wise-users`)

**Page**: `/dashboard/analytics/countries`

**Design Requirements**:

- **World Map**: Interactive SVG world map with country highlighting
- **Country List**: Sortable table with country flag, name, user count, percentage
- **Top Countries Card**: Top 5 countries with visual bars
- **Search**: Filter countries by name or code

### 4. Call Analytics (`GET /dashboard/analytics/calls`)

**Page**: `/dashboard/analytics/calls`

**Design Requirements**:

- **Filters**: Date range, Call type (audio/video), Call status
- **Charts**:
  - Time series line chart for call volume
  - Donut chart for call status distribution (completed, failed, etc.)
  - Bar chart comparing audio vs video calls
  - Heat map for call activity by hour of day
- **Summary Cards**: Success rate, Average duration, Peak hours

### 5. Platform Analytics (`GET /dashboard/analytics/platforms`)

**Page**: `/dashboard/analytics/platforms`

**Design Requirements**:

- **Platform Cards**: Android, iOS, Web with usage statistics
- **Charts**:
  - Stacked area chart showing platform activity over time
  - Device model breakdown for each platform
  - OS version distribution
- **Performance Metrics**: App crashes, response times by platform

### 6. Daily Active Users (`GET /dashboard/analytics/daily-active-users`)

**Page**: `/dashboard/analytics/active-users`

**Design Requirements**:

- **Main Chart**: Area chart showing DAU, WAU, MAU trends
- **Comparison View**: Side-by-side period comparison
- **Retention Metrics**: User retention cohort analysis
- **Activity Patterns**: Hourly activity heat map

### 7. Chat Statistics (`GET /dashboard/analytics/chat-statistics`)

**Page**: `/dashboard/analytics/chat-stats`

**Design Requirements**:

- **Message Volume**: Line chart showing messages over time
- **Message Types**: Pie chart breakdown (text, image, video, etc.)
- **Active Rooms**: Top groups and broadcasts by activity
- **Engagement Metrics**: Messages per user, response times

### 8. Detailed Analytics (`GET /dashboard/analytics/detailed`)

**Page**: `/dashboard/analytics/detailed`

**Design Requirements**:

- **Comprehensive Dashboard**: All analytics in one view
- **Tabbed Interface**: Switch between different analytics categories
- **Export Options**: Download reports as PDF/CSV
- **Customizable Layout**: Drag-and-drop chart arrangement

---

## 👥 USER MANAGEMENT SECTION

### 9. Users List (`GET /dashboard/users`)

**Page**: `/dashboard/users`

**Design Requirements**:

- **Advanced Filters**:
  - Search bar (name, email, phone)
  - Platform filter dropdown
  - Country selector
  - Registration status filter
  - Date range picker
- **Data Table Features**:
  - Sortable columns (Name, Email, Country, Registration Date, Status)
  - User avatar images
  - Status badges (Accepted/Pending/Rejected)
  - Pagination with page size options
  - Bulk selection for actions
- **User Cards View**: Toggle between table and card view
- **Quick Actions**: View details, Send notification, Ban/Unban

**Table Columns**:

- Avatar + Name
- Email
- Phone Number
- Country (with flag)
- Platform
- Registration Status
- Join Date
- Last Seen
- Actions dropdown

### 10. User Details (`GET /dashboard/users/:id`)

**Page**: `/dashboard/users/[id]`

**Design Requirements**:

- **User Profile Card**:
  - Large avatar, name, email, phone
  - Registration status and verification badges
  - Account creation date and last activity
- **Statistics Section**:
  - Total messages sent
  - Groups joined
  - Stories created
  - Calls made
- **Device Information**: List of devices with platform, model, last seen
- **Activity Timeline**: Recent actions and interactions
- **Action Buttons**: Edit, Ban, Send Notification, Delete Account

### 11. Recent Users (`GET /dashboard/users/recent`)

**Component**: Used in dashboard widgets

**Design Requirements**:

- **Widget Format**: Compact list for dashboard sidebar
- **User Item**: Small avatar, name, join date, status indicator
- **View All Link**: Navigate to full users page

---

## 👥 GROUP MANAGEMENT SECTION

### 12. Groups List (`GET /dashboard/groups`)

**Page**: `/dashboard/groups`

**Design Requirements**:

- **Filter Options**:
  - Search by group name
  - Member count range (min/max)
  - Creation date range
  - Activity level filter
- **Group Cards Layout**:
  - Grid of group cards with group image, name, description
  - Member count badge
  - Activity indicator (last message time)
  - Admin information
- **Table View Alternative**: Sortable table with key metrics
- **Analytics Overview**: Top groups by activity, member growth trends

### 13. Group Details (`GET /dashboard/groups/:id`)

**Page**: `/dashboard/groups/[id]`

**Design Requirements**:

- **Group Header**: Image, name, description, creation date
- **Statistics Cards**: Members, Messages, Last Activity
- **Members List**: Paginated table with member details and roles
- **Activity Chart**: Message volume over time
- **Recent Messages**: Sample of recent group activity
- **Moderation Tools**: Mute group, Delete group, Manage settings

---

## 📋 REPORTS SECTION

### 14. Reports List (`GET /dashboard/reports`)

**Page**: `/dashboard/reports`

**Design Requirements**:

- **Status Filter Tabs**: All, Pending, Resolved, Dismissed
- **Report Type Filter**: Harassment, Spam, Inappropriate Content, etc.
- **Report Cards**:
  - Reporter information
  - Reported content/user
  - Report reason and description
  - Status badge
  - Date submitted
  - Urgency indicator
- **Quick Actions**: View Details, Resolve, Dismiss, Escalate
- **Bulk Actions**: Mass resolve/dismiss selected reports

---

## ⚙️ SYSTEM MANAGEMENT SECTION

### 15. System Settings (`GET /dashboard/system/settings`)

**Page**: `/dashboard/settings`

**Design Requirements**:

- **Settings Categories**: Tabs for different setting groups
- **Setting Item Format**:
  - Setting name and description
  - Current value display
  - Edit button/input field
  - Save/Cancel actions
- **Setting Types**: Text inputs, number inputs, toggles, dropdowns
- **Validation**: Real-time validation with error messages

### 16. Update System Setting (`PUT /dashboard/system/settings/:id`)

**Feature**: Inline editing in settings page

### 17. Dashboard Stats (`GET /dashboard/stats`)

**Page**: Main dashboard components

**Design Requirements**:

- **Overview Section**: High-level platform statistics
- **Quick Stats Grid**: Key performance indicators
- **Recent Activity**: Latest platform activities
- **System Health**: Server status and performance metrics

### 18. Export Data (`POST /dashboard/export`)

**Feature**: Export modal/drawer

**Design Requirements**:

- **Export Configuration**:
  - Data type selector (users, groups, messages, etc.)
  - Format options (CSV, JSON, Excel)
  - Date range picker
  - Filter options
- **Progress Indicator**: Export progress bar
- **Download Link**: Generated file download

---

## 📖 STORIES MANAGEMENT SECTION

### 19. Stories List (`GET /dashboard/stories`)

**Page**: `/dashboard/stories`

**Design Requirements**:

- **Filter Panel**:
  - Search by content/caption
  - Story type filter (text, image, video)
  - Date range selector
  - Expiration status filter
- **Stories Grid**:
  - Masonry layout for different story types
  - Story preview thumbnails
  - Author information
  - View count and engagement metrics
  - Expiration countdown for active stories
- **Story Details Modal**: Full story view with analytics

### 20. Story Statistics (`GET /dashboard/stories/stats`)

**Page**: `/dashboard/stories/analytics`

**Design Requirements**:

- **Summary Cards**: Total, Active, Expired stories
- **Type Distribution**: Pie chart of story types
- **Engagement Metrics**: Views, likes, shares over time
- **Top Performers**: Most viewed/engaged stories
- **User Activity**: Most active story creators

### 21. Delete Story (`DELETE /dashboard/stories/:id`)

**Feature**: Delete action in stories list

---

## 📢 ADMIN NOTIFICATIONS SECTION

### 22. Admin Notifications (`GET /dashboard/admin-notifications`)

**Page**: `/dashboard/notifications`

**Design Requirements**:

- **Notification Cards**:
  - Title and content preview
  - Creation date and author
  - Priority indicator
  - Delivery status
  - Action buttons (Edit, Delete)
- **Create New Button**: Prominent create notification button
- **Filter Options**: Date range, priority level

### 23. Create Admin Notification (`POST /dashboard/admin-notifications`)

**Page**: `/dashboard/notifications/create`

**Design Requirements**:

- **Form Layout**:
  - Title input field
  - Rich text editor for content
  - Image upload for notification image
  - Priority selector
  - Target audience options
  - Schedule delivery options
- **Preview Section**: Live preview of notification
- **Validation**: Real-time form validation

### 24. Delete Admin Notification (`DELETE /dashboard/admin-notifications/:id`)

**Feature**: Delete action with confirmation modal

---

## 🔄 VERSION MANAGEMENT SECTION

### 25. Versions List (`GET /dashboard/versions`)

**Page**: `/dashboard/versions`

**Design Requirements**:

- **Platform Tabs**: Android, iOS, Web
- **Version Cards**:
  - Version number and name
  - Platform icon
  - Critical update badge
  - Release date
  - Download URL
  - Update/Delete actions
- **Version Timeline**: Visual timeline of version releases

### 26. Version Statistics (`GET /dashboard/versions/stats`)

**Component**: Stats widget in versions page

### 27. Create Version (`POST /dashboard/versions`)

**Page**: `/dashboard/versions/create`

**Design Requirements**:

- **Version Form**:
  - Version number input
  - Platform selector
  - Critical update toggle
  - Description text area
  - Download URL input
  - Release notes editor

### 28. Update Version (`PUT /dashboard/versions/:id`)

**Page**: `/dashboard/versions/[id]/edit`

### 29. Delete Version (`DELETE /dashboard/versions/:id`)

**Feature**: Delete confirmation modal

---

## 📞 CALLS MANAGEMENT SECTION

### 30. Calls List (`GET /dashboard/calls`)

**Page**: `/dashboard/calls`

**Design Requirements**:

- **Call Log Table**:
  - Caller and receiver information with avatars
  - Call type icon (audio/video)
  - Duration and status
  - Date/time
  - Status badge (completed, failed, etc.)
- **Filter Options**: Date range, call type, status
- **Quick Stats**: Success rate, average duration

### 31. Call Statistics (`GET /dashboard/calls/stats`)

**Page**: `/dashboard/calls/analytics`

**Design Requirements**:

- **Performance Metrics**: Success rate, failure reasons
- **Usage Patterns**: Peak calling hours, daily trends
- **Quality Metrics**: Average call duration, drop rates
- **Platform Comparison**: Call quality by platform

---

## 📡 BROADCAST MANAGEMENT SECTION

### 32. Broadcasts List (`GET /dashboard/broadcasts`)

**Page**: `/dashboard/broadcasts`

**Design Requirements**:

- **Broadcast Cards**:
  - Broadcast image and name
  - Creator information
  - Member count
  - Last activity
  - Management actions
- **Member Growth Chart**: Subscriber growth over time

### 33. Broadcast Details (`GET /dashboard/broadcasts/:id`)

**Page**: `/dashboard/broadcasts/[id]`

**Design Requirements**:

- **Broadcast Profile**: Image, name, description, stats
- **Member Management**: List of subscribers with management options
- **Message History**: Recent broadcast messages
- **Analytics**: Reach, engagement, growth metrics

### 34. Delete Broadcast (`DELETE /dashboard/broadcasts/:id`)

**Feature**: Delete confirmation with member notification options

---

## ⚡ REAL-TIME MONITORING SECTION

### 35. Online Users (`GET /dashboard/real-time/online-users`)

**Page**: `/dashboard/real-time`

**Design Requirements**:

- **Live Counter**: Real-time online user count
- **Active Users List**: Recently active users with status indicators
- **Activity Map**: Geographic distribution of online users
- **Platform Breakdown**: Online users by platform

### 36. Real-time Stats (`GET /dashboard/real-time/stats`)

**Component**: Live dashboard widgets

**Design Requirements**:

- **Live Metrics**: Auto-refreshing statistics
- **Activity Indicators**: Real-time activity pulse animations
- **Platform Status**: Server health indicators
- **Alert System**: Real-time alerts for system issues

### 37. Activity Feed (`GET /dashboard/activity-feed`)

**Component**: Real-time activity sidebar

**Design Requirements**:

- **Activity Stream**: Live feed of platform activities
- **Activity Types**: Different icons for user registrations, messages, stories
- **Timestamps**: Relative time display (e.g., "2 minutes ago")
- **Auto-refresh**: Real-time updates without page reload

---

## 🔍 SEARCH & UTILITIES SECTION

### 38. Global Search (`GET /dashboard/search`)

**Component**: Global search bar in header

**Design Requirements**:

- **Search Interface**:
  - Prominent search bar with autocomplete
  - Search type filters (users, groups, messages, etc.)
  - Advanced search options
- **Results Display**:
  - Categorized results tabs
  - Result previews with relevant information
  - Quick action buttons

### 39. Enhanced Global Search (`GET /dashboard/search/enhanced`)

**Page**: `/dashboard/search/advanced`

**Design Requirements**:

- **Advanced Filters**:
  - Multiple search criteria
  - Date range options
  - Status filters
  - Pagination for results
- **Export Results**: Option to export search results

---

## 🗂️ BULK OPERATIONS SECTION

### 40. Bulk Delete Stories (`POST /dashboard/bulk/delete-stories`)

**Feature**: Bulk action modal

**Design Requirements**:

- **Selection Interface**: Checkbox selection in stories grid
- **Confirmation Modal**:
  - Selected items count
  - Consequences warning
  - Progress indicator during operation
  - Success/failure results

### 41. Bulk Delete Notifications (`POST /dashboard/bulk/delete-notifications`)

**Feature**: Similar bulk action interface for notifications

---

## 🏥 SYSTEM HEALTH SECTION

### 42. System Health (`GET /dashboard/health`)

**Page**: `/dashboard/system-health`

**Design Requirements**:

- **Health Dashboard**:
  - Overall system status indicator
  - Key metrics gauges (CPU, memory, uptime)
  - Service status grid
  - Performance charts
- **Alert Center**: System alerts and warnings
- **Resource Usage**: Server resource utilization graphs

---

## ADDITIONAL UI REQUIREMENTS

### Common Components

1. **Loading States**: Skeleton loaders for all data tables and charts
2. **Error Handling**: User-friendly error messages with retry options
3. **Responsive Design**: Mobile-first approach with tablet and desktop optimizations
4. **Dark Mode**: Toggle between light and dark themes
5. **Accessibility**: WCAG 2.1 AA compliance
6. **Performance**: Lazy loading for large datasets, virtualized tables

### Navigation

- **Sidebar**: Collapsible sidebar with icons and labels
- **Breadcrumbs**: Clear navigation path for nested pages
- **Tab Navigation**: For related content sections
- **Search**: Global search functionality in header

### Data Visualization

- **Chart Library**: Consistent chart styling and interactions
- **Color Scheme**: Accessible color palette for data visualization
- **Tooltips**: Informative hover states for all interactive elements
- **Export Options**: Charts and data export functionality

### Authentication & Security

- **Super Admin Guard**: All pages protected with authentication
- **Permission Levels**: Different access levels for different admin roles
- **Session Management**: Auto-logout and session refresh

### Performance Considerations

- **Pagination**: All large datasets paginated (max 100 items per page)
- **Caching**: Smart caching for frequently accessed data
- **Real-time Updates**: WebSocket connections for live data
- **Optimistic Updates**: Immediate UI feedback for user actions

This comprehensive specification provides the foundation for creating a modern, scalable, and user-friendly dashboard interface for the Super Up Chat Platform.
